#pragma once
// =============================================================================
// WindowsHardening.hpp - Windows/MSVC Compatibility Layer
// =============================================================================
// Removes MSVC warnings, fixes 64-bit formatting, fixes SOCKET handling
// =============================================================================

#ifdef _WIN32

#ifndef WIN32_LEAN_AND_MEAN
#define WIN32_LEAN_AND_MEAN
#endif

#ifndef NOMINMAX
#define NOMINMAX
#endif

#ifndef _CRT_SECURE_NO_WARNINGS
#define _CRT_SECURE_NO_WARNINGS
#endif

#include <winsock2.h>
#include <ws2tcpip.h>
#include <windows.h>

#include <cstdio>
#include <cinttypes>
#include <string>
#include <sstream>

namespace Chimera {

// Convert SOCKET to string safely (Windows SOCKET is UINT_PTR)
inline std::string socketToString(SOCKET s) {
    std::ostringstream oss;
    oss << static_cast<unsigned long long>(s);
    return oss.str();
}

// Convert SOCKET to int64_t safely
inline int64_t socketToInt64(SOCKET s) {
    return static_cast<int64_t>(s);
}

// Format uint64_t with correct format specifier
inline const char* formatU64(uint64_t v, char* buffer, size_t sz) {
    snprintf(buffer, sz, "%" PRIu64, v);
    return buffer;
}

// Format int64_t with correct format specifier
inline const char* formatI64(int64_t v, char* buffer, size_t sz) {
    snprintf(buffer, sz, "%" PRId64, v);
    return buffer;
}

} // namespace Chimera

#endif // _WIN32
