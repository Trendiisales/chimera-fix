// =============================================================================
// TradeLeg.hpp - Individual Position Leg with AGGRESSIVE Trailing
// =============================================================================
// GUARANTEES:
//   ✅ Each leg tracks its OWN MAE/MFE
//   ✅ Stop FIXED at creation (can only TIGHTEN)
//   ✅ AGGRESSIVE trailing - starts immediately when in profit
//   ✅ No leg may modify another leg
// =============================================================================
#pragma once

#include <cstdint>
#include <cinttypes>
#include <cmath>
#include <algorithm>

namespace Chimera {

enum class LegSide { LONG, SHORT };
enum class LegState { PENDING, ACTIVE, STOPPED, TRAILED_OUT };

struct TradeLeg {
    // === IDENTITY ===
    uint32_t leg_id = 0;
    const char* symbol = nullptr;
    LegSide side = LegSide::LONG;
    LegState state = LegState::PENDING;
    
    // === SIZING ===
    double size = 0.0;
    
    // === PRICES (FIXED AT ENTRY) ===
    double entry_price = 0.0;
    double initial_stop = 0.0;
    double initial_risk = 0.0;
    
    // === DYNAMIC PRICES ===
    double current_stop = 0.0;
    double current_price = 0.0;
    double best_price = 0.0;      // Best price seen (for trailing)
    
    // === MAE/MFE TRACKING ===
    double mae = 0.0;
    double mfe = 0.0;
    double current_pnl = 0.0;
    
    // === TIMESTAMPS ===
    uint64_t entry_ts_ns = 0;
    uint64_t last_update_ts_ns = 0;
    
    // === TRAILING CONFIG ===
    double trail_distance = 0.0;
    
    // =========================================================================
    // INITIALIZATION
    // =========================================================================
    void init(uint32_t id, const char* sym, LegSide s, double sz,
              double entry, double stop, double trail_dist, uint64_t ts_ns) {
        leg_id = id;
        symbol = sym;
        side = s;
        size = sz;
        entry_price = entry;
        initial_stop = stop;
        current_stop = stop;
        current_price = entry;
        best_price = entry;
        trail_distance = trail_dist;
        
        initial_risk = std::fabs(entry - stop);
        
        mae = 0.0;
        mfe = 0.0;
        current_pnl = 0.0;
        
        entry_ts_ns = ts_ns;
        last_update_ts_ns = ts_ns;
        
        state = LegState::ACTIVE;
    }
    
    // =========================================================================
    // TICK UPDATE - AGGRESSIVE TRAILING
    // =========================================================================
    void onTick(double price, uint64_t ts_ns) {
        if (state != LegState::ACTIVE) return;
        
        current_price = price;
        last_update_ts_ns = ts_ns;
        
        // Calculate P&L
        if (side == LegSide::LONG) {
            current_pnl = price - entry_price;
        } else {
            current_pnl = entry_price - price;
        }
        
        // Update MAE
        if (current_pnl < 0) {
            mae = std::max(mae, std::fabs(current_pnl));
        }
        
        // Update MFE and best price
        if (current_pnl > 0) {
            mfe = std::max(mfe, current_pnl);
            
            // Track best price for trailing
            if (side == LegSide::LONG) {
                best_price = std::max(best_price, price);
            } else {
                best_price = std::min(best_price, price);
            }
        }
        
        // AGGRESSIVE TRAILING - trail IMMEDIATELY when in ANY profit
        if (current_pnl > 0 && trail_distance > 0) {
            trailStop();
        }
        
        // Check stop hit
        if (isStopHit(price)) {
            state = LegState::STOPPED;
        }
    }
    
    // =========================================================================
    // AGGRESSIVE TRAIL - Every tick when profitable
    // =========================================================================
    void trailStop() {
        double new_stop;
        
        if (side == LegSide::LONG) {
            // Trail below best price
            new_stop = best_price - trail_distance;
            // Stop can only TIGHTEN (move up for longs)
            if (new_stop > current_stop) {
                current_stop = new_stop;
            }
        } else {
            // Trail above best price
            new_stop = best_price + trail_distance;
            // Stop can only TIGHTEN (move down for shorts)
            if (new_stop < current_stop) {
                current_stop = new_stop;
            }
        }
    }
    
    // =========================================================================
    // STOP CHECK
    // =========================================================================
    bool isStopHit(double price) const {
        if (side == LegSide::LONG) {
            return price <= current_stop;
        } else {
            return price >= current_stop;
        }
    }
    
    // =========================================================================
    // PYRAMIDING ELIGIBILITY
    // =========================================================================
    // AGGRESSIVE: pyramid when ANY favorable excursion seen
    bool canPyramid(double min_mfe_for_pyramid = 0.0) const {
        if (state != LegState::ACTIVE) return false;
        
        // Must be in profit (MFE > 0) or above threshold
        // MAE check removed - price proving itself is enough
        return mfe > min_mfe_for_pyramid;
    }
    
    // =========================================================================
    // GETTERS
    // =========================================================================
    double getUnrealizedPnL() const { return current_pnl * size; }
    
    double getRealizedPnL(double exit_price) const {
        double pnl = (side == LegSide::LONG) 
                   ? exit_price - entry_price 
                   : entry_price - exit_price;
        return pnl * size;
    }
    
    double getCurrentR() const {
        if (initial_risk <= 0) return 0.0;
        return current_pnl / initial_risk;
    }
    
    bool isActive() const { return state == LegState::ACTIVE; }
    bool isClosed() const { return state == LegState::STOPPED || state == LegState::TRAILED_OUT; }
};

} // namespace Chimera
