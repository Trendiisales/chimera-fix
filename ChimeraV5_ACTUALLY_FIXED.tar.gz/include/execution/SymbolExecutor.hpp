// =============================================================================
// SymbolExecutor.hpp - Per-Symbol Execution Authority with Pyramiding
// =============================================================================
// ARCHITECTURE:
//   ✅ ONE executor per symbol
//   ✅ Engines ADVISE, executor DECIDES
//   ✅ Per-leg MAE/MFE tracking
//   ✅ Pyramiding based on exact spec below
//   ✅ Unified trailing stop
//   ✅ NO retroactive stop widening
//
// =============================================================================
// PYRAMIDING SPEC (FINAL, EXACT)
// =============================================================================
// max_pyramids = 3                    (4 total positions)
// pyramid_trigger_R = 0.5             (price must move 0.5R from last entry)
// pyramid_sizes = [1.0, 0.7, 0.5, 0.3]
// trail_min_R = 0.3
// pyramid_cooldown_ticks = 20
// require_all_BE_before_add = true    (all stops at breakeven before pyramid)
// unified_trailing_stop = true        (all legs share trailing stop)
// =============================================================================
#pragma once

#include "TradeLeg.hpp"
#include <cstdint>
#include <cinttypes>
#include <cstdio>
#include <cmath>
#include <functional>
#include <array>
#include <algorithm>

namespace Chimera {

// =============================================================================
// ENGINE INTENT (what engines publish)
// =============================================================================
struct EngineIntent {
    const char* engine_name = nullptr;
    const char* symbol = nullptr;
    int direction = 0;           // +1 = long, -1 = short, 0 = flat
    double confidence = 0.0;     // 0.0 - 1.0
    double suggested_size = 0.0; // Suggested position size
    double suggested_stop = 0.0; // Suggested stop distance
    double trail_hint = 0.0;     // Suggested trail distance (0 = no trail)
    uint64_t ts_ns = 0;
    bool valid = false;
};

// =============================================================================
// ORDER REQUEST (what executor sends to broker)
// =============================================================================
struct OrderRequest {
    const char* symbol = nullptr;
    LegSide side = LegSide::LONG;
    double size = 0.0;
    double price = 0.0;
    double stop_price = 0.0;
    const char* reason = nullptr;
    uint32_t leg_id = 0;
    uint64_t ts_ns = 0;
};

using OrderCallback = std::function<void(const OrderRequest&)>;

// =============================================================================
// SYMBOL EXECUTOR CONFIGURATION
// =============================================================================
struct ExecutorConfig {
    // Symbol
    const char* symbol = "XAUUSD";
    
    // === PYRAMIDING SPEC (LOCKED) ===
    int max_pyramids = 3;                // 3 adds = 4 total positions
    double pyramid_trigger_R = 0.5;      // Price must move 0.5R from last entry
    double pyramid_sizes[4] = {1.0, 0.7, 0.5, 0.3};  // Decaying size multipliers
    int pyramid_cooldown_ticks = 20;     // Ticks between pyramid evaluations
    bool require_all_BE_before_add = true;  // All stops at breakeven before pyramid
    
    // === TRAILING (UNIFIED) ===
    double trail_min_R = 0.3;            // Minimum trailing distance in R
    
    // === POSITION SIZING ===
    double base_size = 0.01;             // Base lot size
    double max_total_size = 0.10;        // Max total position size
    
    // === RISK ===
    double default_stop_distance = 1.20; // Default stop distance in price units (R)
    double max_daily_loss = 200.0;       // Daily loss limit (absolute)
};

// =============================================================================
// SYMBOL EXECUTOR
// =============================================================================
class SymbolExecutor {
public:
    static constexpr int MAX_LEGS = 4;  // Base + 3 pyramids
    
    SymbolExecutor() = default;
    
    void init(const ExecutorConfig& cfg) {
        config_ = cfg;
        reset();
    }
    
    void setOrderCallback(OrderCallback cb) { order_cb_ = std::move(cb); }
    
    // =========================================================================
    // MAIN TICK HANDLER
    // =========================================================================
    void onTick(double bid, double ask, uint64_t ts_ns) {
        double mid = (bid + ask) / 2.0;
        current_bid_ = bid;
        current_ask_ = ask;
        current_mid_ = mid;
        last_tick_ts_ = ts_ns;
        tick_count_++;
        
        // Update all active legs
        for (int i = 0; i < MAX_LEGS; i++) {
            if (legs_[i].isActive()) {
                legs_[i].onTick(mid, ts_ns);
            }
        }
        
        // Check for stops hit (unified trailing stop)
        checkUnifiedTrailingStop();
        
        // Process pending intent
        if (pending_intent_.valid) {
            processIntent(ts_ns);
        }
        
        // Check pyramiding opportunity (with cooldown)
        if (pyramid_enabled_ && tick_count_ >= last_pyramid_tick_ + config_.pyramid_cooldown_ticks) {
            checkPyramidOpportunity(ts_ns);
        }
        
        // Update unified trailing stop position
        updateUnifiedTrail();
    }
    
    // =========================================================================
    // RECEIVE ENGINE INTENT
    // =========================================================================
    void onIntent(const EngineIntent& intent) {
        if (!intent.valid) return;
        pending_intent_ = intent;
    }
    
    // =========================================================================
    // STATE GETTERS
    // =========================================================================
    int getActiveLegCount() const {
        int count = 0;
        for (int i = 0; i < MAX_LEGS; i++) {
            if (legs_[i].isActive()) count++;
        }
        return count;
    }
    
    double getTotalSize() const {
        double total = 0.0;
        for (int i = 0; i < MAX_LEGS; i++) {
            if (legs_[i].isActive()) {
                total += legs_[i].size;
            }
        }
        return total;
    }
    
    double getTotalUnrealizedPnL() const {
        double total = 0.0;
        for (int i = 0; i < MAX_LEGS; i++) {
            if (legs_[i].isActive()) {
                total += legs_[i].getUnrealizedPnL();
            }
        }
        return total;
    }
    
    double getAverageEntryPrice() const {
        double weighted_sum = 0.0;
        double total_size = 0.0;
        for (int i = 0; i < MAX_LEGS; i++) {
            if (legs_[i].isActive()) {
                weighted_sum += legs_[i].entry_price * legs_[i].size;
                total_size += legs_[i].size;
            }
        }
        return total_size > 0 ? weighted_sum / total_size : 0.0;
    }
    
    LegSide getCurrentBias() const { return current_bias_; }
    bool hasPosition() const { return getActiveLegCount() > 0; }
    double getDailyPnL() const { return daily_realized_pnl_ + getTotalUnrealizedPnL(); }
    double getUnifiedStop() const { return unified_stop_; }
    bool isPyramidEnabled() const { return pyramid_enabled_; }
    double getBaseR() const { return base_R_; }
    
    const TradeLeg& getLeg(int idx) const { return legs_[idx]; }
    
    // =========================================================================
    // DAILY RESET
    // =========================================================================
    void resetDaily() {
        daily_realized_pnl_ = 0.0;
        trades_today_ = 0;
    }
    
    void reset() {
        for (int i = 0; i < MAX_LEGS; i++) {
            legs_[i] = TradeLeg{};
        }
        active_leg_count_ = 0;
        next_leg_id_ = 1;
        current_bias_ = LegSide::LONG;
        last_entry_price_ = 0.0;
        base_R_ = 0.0;
        unified_stop_ = 0.0;
        pyramid_enabled_ = true;
        pending_intent_ = EngineIntent{};
        daily_realized_pnl_ = 0.0;
        trades_today_ = 0;
        tick_count_ = 0;
        last_pyramid_tick_ = 0;
    }

private:
    ExecutorConfig config_;
    OrderCallback order_cb_;
    
    // Legs
    std::array<TradeLeg, MAX_LEGS> legs_;
    int active_leg_count_ = 0;
    uint32_t next_leg_id_ = 1;
    
    // State
    LegSide current_bias_ = LegSide::LONG;
    double last_entry_price_ = 0.0;   // Price of last entry (for pyramid trigger)
    double base_R_ = 0.0;             // Initial stop distance (defines R)
    double unified_stop_ = 0.0;       // Single trailing stop for all legs
    bool pyramid_enabled_ = true;     // Disabled permanently if any stop hit
    EngineIntent pending_intent_;
    
    // Current prices
    double current_bid_ = 0.0;
    double current_ask_ = 0.0;
    double current_mid_ = 0.0;
    uint64_t last_tick_ts_ = 0;
    
    // Tick counting for cooldown
    uint64_t tick_count_ = 0;
    uint64_t last_pyramid_tick_ = 0;
    
    // Daily tracking
    double daily_realized_pnl_ = 0.0;
    int trades_today_ = 0;
    
    // =========================================================================
    // PROCESS ENGINE INTENT
    // =========================================================================
    void processIntent(uint64_t ts_ns) {
        if (!pending_intent_.valid) return;
        
        // Check daily loss limit
        if (getDailyPnL() <= -config_.max_daily_loss) {
            std::printf("[%s_EXEC] Daily loss limit hit (%.2f), no new trades\n",
                       config_.symbol, getDailyPnL());
            pending_intent_.valid = false;
            return;
        }
        
        // If flat, consider new entry
        if (!hasPosition() && pending_intent_.direction != 0) {
            enterBasePosition(ts_ns);
        }
        
        // If position exists but direction flipped, close and reverse
        if (hasPosition()) {
            bool is_long = (current_bias_ == LegSide::LONG);
            bool want_long = (pending_intent_.direction > 0);
            
            if (is_long != want_long && pending_intent_.direction != 0) {
                // Direction reversal - close all and enter new
                closeAllLegs(ts_ns, "direction_reversal");
                enterBasePosition(ts_ns);
            }
        }
        
        pending_intent_.valid = false;
    }
    
    // =========================================================================
    // BASE POSITION ENTRY (Leg 0)
    // =========================================================================
    void enterBasePosition(uint64_t ts_ns) {
        if (pending_intent_.direction == 0) return;
        if (hasPosition()) return;
        
        LegSide side = (pending_intent_.direction > 0) ? LegSide::LONG : LegSide::SHORT;
        double entry_price = (side == LegSide::LONG) ? current_ask_ : current_bid_;
        
        // Calculate stop (this defines R for the entire campaign)
        double stop_distance = (pending_intent_.suggested_stop > 0) 
                             ? pending_intent_.suggested_stop 
                             : config_.default_stop_distance;
        
        double stop_price = (side == LegSide::LONG) 
                          ? entry_price - stop_distance 
                          : entry_price + stop_distance;
        
        // Base size (multiplier = 1.0)
        double size = config_.base_size * config_.pyramid_sizes[0];
        size = std::min(size, config_.max_total_size);
        
        // Create base leg
        TradeLeg& leg = legs_[0];
        double trail_dist = config_.trail_min_R * stop_distance;
        leg.init(next_leg_id_++, config_.symbol, side, size, entry_price, stop_price, trail_dist, ts_ns);
        
        // Store campaign parameters
        current_bias_ = side;
        last_entry_price_ = entry_price;
        base_R_ = stop_distance;
        unified_stop_ = stop_price;
        pyramid_enabled_ = true;
        active_leg_count_ = 1;
        trades_today_++;
        last_pyramid_tick_ = tick_count_;
        
        // Send order
        sendOrder(leg, "base_entry", ts_ns);
        
        std::printf("[%s_EXEC] BASE ENTRY #%d: %s %.2f lots @ %.2f stop=%.2f R=%.2f\n",
                   config_.symbol, leg.leg_id,
                   (side == LegSide::LONG) ? "LONG" : "SHORT",
                   size, entry_price, stop_price, base_R_);
    }
    
    // =========================================================================
    // PYRAMIDING CHECK (EXACT SPEC)
    // =========================================================================
    void checkPyramidOpportunity(uint64_t ts_ns) {
        if (!hasPosition()) return;
        if (!pyramid_enabled_) return;
        
        int current_adds = getActiveLegCount() - 1;  // Subtract base position
        if (current_adds >= config_.max_pyramids) return;
        
        if (getTotalSize() >= config_.max_total_size) return;
        
        // Check daily loss limit
        if (getDailyPnL() <= -config_.max_daily_loss) return;
        
        // === PYRAMID TRIGGER A: Price Progression ===
        // Price must move >= +0.5R from last entry price
        double price_move = (current_bias_ == LegSide::LONG)
                          ? current_mid_ - last_entry_price_
                          : last_entry_price_ - current_mid_;
        
        double required_move = config_.pyramid_trigger_R * base_R_;
        
        if (price_move < required_move) {
            return;  // Not enough price progression
        }
        
        // === PYRAMID TRIGGER B: Position State ===
        // All existing positions must not be in drawdown
        for (int i = 0; i < MAX_LEGS; i++) {
            if (legs_[i].isActive()) {
                if (legs_[i].current_pnl < 0) {
                    return;  // A leg is in drawdown
                }
            }
        }
        
        // === PYRAMID TRIGGER C: Risk Lock-In ===
        // All stops must be at breakeven or better
        if (config_.require_all_BE_before_add) {
            for (int i = 0; i < MAX_LEGS; i++) {
                if (legs_[i].isActive()) {
                    double be_price = legs_[i].entry_price;
                    if (current_bias_ == LegSide::LONG) {
                        if (unified_stop_ < be_price) {
                            return;  // Stop is below breakeven
                        }
                    } else {
                        if (unified_stop_ > be_price) {
                            return;  // Stop is above breakeven
                        }
                    }
                }
            }
        }
        
        // === ALL CONDITIONS MET - ADD PYRAMID ===
        addPyramidLeg(ts_ns, current_adds + 1);  // +1 because we're adding the next one
    }
    
    // =========================================================================
    // ADD PYRAMID LEG
    // =========================================================================
    void addPyramidLeg(uint64_t ts_ns, int pyramid_number) {
        if (pyramid_number > config_.max_pyramids) return;
        
        // Find free slot
        int leg_idx = -1;
        for (int i = 0; i < MAX_LEGS; i++) {
            if (!legs_[i].isActive() && legs_[i].leg_id == 0) {
                leg_idx = i;
                break;
            }
        }
        if (leg_idx < 0) return;
        
        double entry_price = (current_bias_ == LegSide::LONG) ? current_ask_ : current_bid_;
        
        // Pyramid size uses decaying multiplier
        double size_mult = config_.pyramid_sizes[pyramid_number];
        double size = config_.base_size * size_mult;
        double remaining = config_.max_total_size - getTotalSize();
        size = std::min(size, remaining);
        
        if (size < 0.001) return;
        
        // Stop is unified (will be set by updateUnifiedTrail)
        double stop_price = unified_stop_;
        
        TradeLeg& leg = legs_[leg_idx];
        double trail_dist = config_.trail_min_R * base_R_;
        leg.init(next_leg_id_++, config_.symbol, current_bias_, size, entry_price, stop_price, trail_dist, ts_ns);
        
        // Update last entry for next pyramid trigger
        last_entry_price_ = entry_price;
        last_pyramid_tick_ = tick_count_;
        active_leg_count_ = std::max(active_leg_count_, leg_idx + 1);
        trades_today_++;
        
        // Immediately move all stops to new unified level (tighter)
        tightenUnifiedStop();
        
        // Send order
        sendOrder(leg, "pyramid", ts_ns);
        
        std::printf("[%s_EXEC] PYRAMID #%d (add %d): %s %.2f lots @ %.2f (size_mult=%.1f)\n",
                   config_.symbol, leg.leg_id, pyramid_number,
                   (current_bias_ == LegSide::LONG) ? "LONG" : "SHORT",
                   size, entry_price, size_mult);
        std::printf("  → unified_stop now: %.2f | total_size: %.2f | legs: %d\n",
                   unified_stop_, getTotalSize(), getActiveLegCount());
    }
    
    // =========================================================================
    // UNIFIED TRAILING STOP (CRITICAL)
    // =========================================================================
    void updateUnifiedTrail() {
        if (!hasPosition()) return;
        
        double trail_distance = config_.trail_min_R * base_R_;
        double new_stop;
        
        if (current_bias_ == LegSide::LONG) {
            new_stop = current_mid_ - trail_distance;
            // Stop can only tighten (move up for longs)
            if (new_stop > unified_stop_) {
                unified_stop_ = new_stop;
                // Update all legs
                for (int i = 0; i < MAX_LEGS; i++) {
                    if (legs_[i].isActive()) {
                        legs_[i].current_stop = unified_stop_;
                    }
                }
            }
        } else {
            new_stop = current_mid_ + trail_distance;
            // Stop can only tighten (move down for shorts)
            if (new_stop < unified_stop_) {
                unified_stop_ = new_stop;
                for (int i = 0; i < MAX_LEGS; i++) {
                    if (legs_[i].isActive()) {
                        legs_[i].current_stop = unified_stop_;
                    }
                }
            }
        }
    }
    
    void tightenUnifiedStop() {
        // Called after pyramid add - tighten stop
        double trail_distance = config_.trail_min_R * base_R_;
        double new_stop;
        
        if (current_bias_ == LegSide::LONG) {
            new_stop = current_mid_ - trail_distance;
            if (new_stop > unified_stop_) {
                unified_stop_ = new_stop;
            }
        } else {
            new_stop = current_mid_ + trail_distance;
            if (new_stop < unified_stop_) {
                unified_stop_ = new_stop;
            }
        }
        
        // Apply to all legs
        for (int i = 0; i < MAX_LEGS; i++) {
            if (legs_[i].isActive()) {
                legs_[i].current_stop = unified_stop_;
            }
        }
    }
    
    // =========================================================================
    // CHECK UNIFIED STOP HIT
    // =========================================================================
    void checkUnifiedTrailingStop() {
        if (!hasPosition()) return;
        
        bool stop_hit = false;
        if (current_bias_ == LegSide::LONG) {
            stop_hit = current_mid_ <= unified_stop_;
        } else {
            stop_hit = current_mid_ >= unified_stop_;
        }
        
        if (stop_hit) {
            // PYRAMID TERMINATION: Any stop hit disables pyramiding
            pyramid_enabled_ = false;
            
            std::printf("[%s_EXEC] UNIFIED STOP HIT @ %.2f (stop=%.2f)\n",
                       config_.symbol, current_mid_, unified_stop_);
            
            // Close ALL legs together (preserves convexity)
            closeAllLegs(last_tick_ts_, "unified_stop");
        }
    }
    
    // =========================================================================
    // CLOSE ALL LEGS (EXIT TOGETHER)
    // =========================================================================
    void closeAllLegs(uint64_t ts_ns, const char* reason) {
        double total_pnl = 0.0;
        
        for (int i = 0; i < MAX_LEGS; i++) {
            if (legs_[i].isActive()) {
                // Send close order
                OrderRequest req;
                req.symbol = config_.symbol;
                req.side = (current_bias_ == LegSide::LONG) ? LegSide::SHORT : LegSide::LONG;
                req.size = legs_[i].size;
                req.price = current_mid_;
                req.stop_price = 0.0;
                req.reason = reason;
                req.leg_id = legs_[i].leg_id;
                req.ts_ns = ts_ns;
                
                if (order_cb_) order_cb_(req);
                
                double realized = legs_[i].getRealizedPnL(current_mid_);
                total_pnl += realized;
                legs_[i].state = LegState::STOPPED;
                
                std::printf("  → CLOSE leg#%d: %.2f lots @ %.2f (entry=%.2f) PnL=%.2f\n",
                           legs_[i].leg_id, legs_[i].size, current_mid_, 
                           legs_[i].entry_price, realized);
            }
        }
        
        daily_realized_pnl_ += total_pnl;
        
        std::printf("[%s_EXEC] ALL LEGS CLOSED (%s). Campaign PnL: %.2f | Daily: %.2f\n",
                   config_.symbol, reason, total_pnl, daily_realized_pnl_);
        
        // Reset for next campaign
        for (int i = 0; i < MAX_LEGS; i++) {
            legs_[i] = TradeLeg{};
        }
        active_leg_count_ = 0;
        last_entry_price_ = 0.0;
        unified_stop_ = 0.0;
        // pyramid_enabled_ stays disabled until explicitly reset (new campaign)
    }
    
    // =========================================================================
    // HELPERS
    // =========================================================================
    void sendOrder(const TradeLeg& leg, const char* reason, uint64_t ts_ns) {
        if (!order_cb_) return;
        
        OrderRequest req;
        req.symbol = config_.symbol;
        req.side = leg.side;
        req.size = leg.size;
        req.price = leg.entry_price;
        req.stop_price = unified_stop_;
        req.reason = reason;
        req.leg_id = leg.leg_id;
        req.ts_ns = ts_ns;
        
        order_cb_(req);
    }
};

} // namespace Chimera
