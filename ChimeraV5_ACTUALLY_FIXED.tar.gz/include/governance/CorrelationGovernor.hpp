#pragma once
#include "EngineId.hpp"

namespace Chimera {

class CorrelationGovernor {
public:
    double scale(EngineId id, double xau_pos, double xag_pos) const {
        // If both metals same direction (both long or both short), reduce exposure
        if (xau_pos > 0 && xag_pos > 0) return 0.7;  // Both long
        if (xau_pos < 0 && xag_pos < 0) return 0.7;  // Both short

        // Opposite directions or one flat - normal exposure
        return 1.0;
    }
};

} // namespace Chimera
