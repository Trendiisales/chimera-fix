// =============================================================================
// DependencyGraph.cpp - Chimera Dependency Graph Generator
// =============================================================================
// Generates compile-time dependency graph in DOT format
// Usage: depgraph <root_dir>
// Output: chimera_dependency_graph.dot
// =============================================================================

#include <filesystem>
#include <fstream>
#include <iostream>
#include <regex>
#include <set>
#include <map>
#include <string>

namespace fs = std::filesystem;

int main(int argc, char** argv) {
    if (argc < 2) {
        std::cout << "Usage: depgraph <root_dir>\n";
        std::cout << "\nGenerates dependency graph for all .hpp/.cpp files\n";
        std::cout << "Output: chimera_dependency_graph.dot\n";
        std::cout << "\nVisualize with:\n";
        std::cout << "  dot -Tpng chimera_dependency_graph.dot -o graph.png\n";
        return 1;
    }

    fs::path root = argv[1];
    
    if (!fs::exists(root)) {
        std::cerr << "Error: Directory not found: " << root << "\n";
        return 1;
    }

    std::regex include_regex(R"(#include\s+"([^"]+)")");
    std::map<std::string, std::set<std::string>> graph;
    int file_count = 0;

    std::cout << "Scanning directory: " << root << "\n";

    for (auto& p : fs::recursive_directory_iterator(root)) {
        if (!p.is_regular_file())
            continue;

        auto ext = p.path().extension();
        if (ext != ".hpp" && ext != ".cpp")
            continue;

        std::ifstream file(p.path());
        if (!file.is_open())
            continue;

        std::string line;
        std::string file_node = p.path().filename().string();

        while (std::getline(file, line)) {
            std::smatch match;
            if (std::regex_search(line, match, include_regex)) {
                std::string dep = match[1].str();
                // Extract just the filename
                size_t last_slash = dep.find_last_of("/\\");
                if (last_slash != std::string::npos) {
                    dep = dep.substr(last_slash + 1);
                }
                graph[file_node].insert(dep);
            }
        }
        
        file_count++;
    }

    std::cout << "Scanned " << file_count << " files\n";
    std::cout << "Found " << graph.size() << " nodes with dependencies\n";

    std::ofstream out("chimera_dependency_graph.dot");
    if (!out.is_open()) {
        std::cerr << "Error: Cannot write chimera_dependency_graph.dot\n";
        return 1;
    }

    out << "digraph Chimera {\n";
    out << "  rankdir=LR;\n";
    out << "  node [shape=box, style=rounded];\n\n";

    int edge_count = 0;
    for (auto& [src, deps] : graph) {
        for (auto& dep : deps) {
            out << "  \"" << src << "\" -> \"" << dep << "\";\n";
            edge_count++;
        }
    }

    out << "}\n";
    out.close();

    std::cout << "Wrote " << edge_count << " edges to chimera_dependency_graph.dot\n";
    std::cout << "\nVisualize with:\n";
    std::cout << "  dot -Tpng chimera_dependency_graph.dot -o chimera_graph.png\n";

    return 0;
}
