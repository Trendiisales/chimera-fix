# Chimera v4.16.0-PYRAMID Changelog

## MAJOR ARCHITECTURAL CHANGE: SymbolExecutor + Pyramiding

### The Problem (Why Previous Engines Failed)

Every Chimera engine before did this:
- One entry
- One stop
- One target
- Binary outcome

This destroyed edges that looked like this:
- Small MAE
- Repeated continuation
- Slow grind
- Multiple favorable excursions

Your XAUUSD diagnostic showed:
```
Median MAE: $1.92  | 75% MAE: $4.99 | 90% MAE: $6.29
Median MFE: $1.48  | 75% MFE: $3.95 | 90% MFE: $6.49
```

That is a **path edge**, not a single-trade edge.

### The Solution: SymbolExecutor Architecture

```
TICKS
  ↓
[Engines]           ← ADVISE only (unchanged)
  ↓
[SymbolExecutor]    ← DECIDES (NEW)
  ↓
[Global Hard Stops] ← Loss cap ONLY
  ↓
[Broker / FIX]
```

### New Files

1. **TradeLeg.hpp** (`include/execution/TradeLeg.hpp`)
   - Individual position leg with independent tracking
   - Each leg tracks its OWN MAE/MFE
   - Stop is fixed at creation (can only tighten via trail)
   - `canPyramid(alpha, beta)` method for eligibility check

2. **SymbolExecutor.hpp** (`include/execution/SymbolExecutor.hpp`)
   - ONE executor per symbol
   - Receives EngineIntent from signal generators
   - Decides on entry, pyramiding, trailing, exit
   - Per-leg MAE/MFE tracking
   - Pyramiding based on MFE > MAE rule

3. **main_fix.cpp** (updated)
   - Uses SymbolExecutor architecture
   - Engines ADVISE via EngineIntent
   - Executors DECIDE on execution

### Pyramiding Rules (Locked)

```cpp
// Add-on only when:
//   MFE >= α × initial_risk (α = 1.0, price proved direction)
//   MAE <= β × initial_risk (β = 0.5, no deep adverse heat)

bool canPyramid(double alpha = 1.0, double beta = 0.5) {
    bool mfe_ok = mfe >= alpha * initial_risk;
    bool mae_ok = mae <= beta * initial_risk;
    return mfe_ok && mae_ok;
}
```

### XAUUSD Executor Configuration

| Parameter | Value | Meaning |
|-----------|-------|---------|
| max_legs | 6 | Maximum pyramid levels |
| add_on_spacing | $0.35 | Min price move between add-ons |
| pyramid_alpha | 1.0 | MFE threshold (× initial_risk) |
| pyramid_beta | 0.5 | MAE threshold (× initial_risk) |
| base_size | 0.01 | Lots per leg |
| max_total_size | 0.10 | Max total position |
| default_stop | $1.20 | Hard stop distance |
| trail_activation | 1.0R | Trail starts at 1R profit |
| trail_distance | $0.30 | Trail behind price |

### NAS100 Executor Configuration

| Parameter | Value |
|-----------|-------|
| max_legs | 4 |
| add_on_spacing | 6pts |
| default_stop | 18pts |
| trail_distance | 5pts |

### What Engines Do Now (Unchanged Logic)

Engines now **advise only** via `EngineIntent`:
- direction (+1/-1/0)
- confidence (0-1)
- suggested_size
- suggested_stop
- trail_hint

Engines **NEVER** submit trades. SymbolExecutor **DECIDES**.

### Key Guarantees

✅ Each leg tracks its OWN MAE/MFE
✅ Stops NEVER widen (can only tighten via trail)
✅ Pyramiding only when MFE > MAE proves direction
✅ Per-leg independent trailing
✅ NO retroactive stop modification
✅ Engines advise, executor decides
✅ Global hard stops preserved (daily loss limit)

### Status Output (Every 30s)

```
[XAU_EXEC] legs=3/6 size=0.03 bias=LONG uPnL=0.85 dayPnL=1.23
  leg#1 entry=2650.50 stop=2650.35 MAE=0.20 MFE=0.95 R=0.65R [TRAIL]
  leg#2 entry=2650.85 stop=2650.55 MAE=0.10 MFE=0.60 R=0.45R [TRAIL]
  leg#3 entry=2651.20 stop=2650.90 MAE=0.05 MFE=0.30 R=0.20R
```

### What This Enables

- **Conditional exposure expansion**: Add size only after price proves itself
- **Trail per-leg, not per-position**: Each leg independent
- **Let winners grow asymmetrically**: No fixed targets capping path edge
- **Same safety**: Daily loss limit, hard stops preserved

This is the architectural fix you needed.
