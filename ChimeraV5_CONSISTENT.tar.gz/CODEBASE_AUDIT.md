# CHIMERA CODEBASE AUDIT - 2026-01-09
## Version: v4.14.22

---

## EXECUTIVE SUMMARY

**TOTAL FILES:** 201
**ACTUALLY USED:** 14 (7%)
**DEAD CODE:** 187 files (93%)

The codebase is MASSIVELY bloated with dead code from previous iterations.

---

## DEPENDENCY TREE (WHAT'S ACTUALLY USED)

```
src/main.cpp (ENTRY POINT)
├── include/engines/ChimeraUnifiedEngine.hpp      ← TRADING LOGIC
├── cfd_engine/include/openapi/CTraderOpenAPIClient.hpp  ← PRICE FEED + ORDERS
│   └── cfd_engine/include/CTraderTypes.hpp
├── include/gui/GUIBroadcaster.hpp                ← DASHBOARD SERVER
│   ├── include/shared/TradingConfig.hpp
│   ├── include/shared/MarketState.hpp
│   ├── include/shared/SymbolEnabledManager.hpp
│   ├── include/shared/GlobalRiskGovernor.hpp
│   ├── include/shared/GlobalKill.hpp
│   ├── include/shared/DailyLossGuard.hpp
│   ├── include/bringup/BringUpSystem.hpp
│   └── include/core/EngineOwnership.hpp
└── config.ini                                    ← CONFIGURATION
```

**That's it. Everything else is DEAD CODE.**

---

## DEAD CODE BREAKDOWN

### 1. FIX PROTOCOL (COMPLETELY DEAD - 10 files)
**Status:** NOT USED - OpenAPI replaced FIX
**Location:** `cfd_engine/include/fix/`
**Action:** TOMBSTONE OR DELETE

| File | Lines | Purpose |
|------|-------|---------|
| CTraderFIXClient.hpp | ~2000 | FIX protocol client |
| FIXConfig.hpp | ~200 | FIX configuration |
| FIXFastParse.hpp | ~300 | FIX message parser |
| FIXFieldView.hpp | ~100 | FIX field accessor |
| FIXMessage.hpp | ~500 | FIX message builder |
| FIXResendRing.hpp | ~150 | FIX resend buffer |
| FIXSSLTransport.hpp | ~400 | FIX SSL transport |
| FIXSession.hpp | ~600 | FIX session manager |
| FixDegradedState.hpp | ~100 | FIX degraded state |
| include/diag/FIXDebugLogger.hpp | ~200 | FIX debug logging |

### 2. OLD CfdEngine (COMPLETELY DEAD - 3 files)
**Status:** Replaced by direct OpenAPI + ChimeraUnifiedEngine
**Action:** DELETE

| File | Purpose |
|------|---------|
| cfd_engine/include/CfdEngine.hpp | Old monolithic engine |
| cfd_engine/include/CfdEngine_backup_v4.6.0.hpp | Backup of above |
| include/integration/CfdEngineIntegration.hpp | Integration layer |

### 3. OLD STRATEGIES (DEAD - 3 files)
**Location:** `cfd_engine/include/strategy/`
**Status:** Replaced by ChimeraUnifiedEngine CRTP strategies

| File | Purpose |
|------|---------|
| Strategies_Bucket.hpp | Old bucket voting |
| PureScalper.hpp | Old scalper |
| MicroStateMachine.hpp | Old state machine |

### 4. OLD MICRO ENGINES (DEAD - 10 files)
**Location:** `cfd_engine/include/micro/`
**Status:** Replaced by ChimeraUnifiedEngine

All files in this directory are DEAD:
- CentralMicroEngine.hpp
- MicroEngineBase.hpp
- MicroEngineBreakout.hpp
- MicroEngineMomentum.hpp
- MicroEngineReversion.hpp
- MicroEngineTrend.hpp
- MicroEngineVolumeShock.hpp
- MicroEngines_CRTP.hpp
- MicroState.hpp
- MicroStructureState.hpp

### 5. UNUSED ALPHA MODULES (DEAD - 11 files)
**Location:** `include/alpha/`
**Status:** Not linked to main.cpp

### 6. UNUSED AUDIT MODULES (DEAD - 18 files)
**Location:** `include/audit/`
**Status:** Not linked to main.cpp
**Note:** Some .cpp files exist in src/audit/ but not compiled

### 7. UNUSED EXECUTION MODULES (DEAD - 17 files)
**Location:** `include/execution/`
**Status:** Not linked to main.cpp

### 8. UNUSED ML MODULES (DEAD - 16 files)
**Location:** `include/ml/`
**Status:** Not linked to main.cpp

### 9. UNUSED RISK MODULES (DEAD - 9 files)
**Location:** `include/risk/`
**Status:** GlobalRiskGovernor used, rest dead

### 10. UNUSED PROFILE MODULES (DEAD - 11 files)
**Location:** `include/profile/`
**Status:** Not linked to main.cpp
**Note:** .cpp files exist but not compiled

### 11. OTHER DEAD DIRECTORIES
- `include/backtest/` - Not compiled
- `include/bootstrap/` - Not used
- `include/core/` - Only EngineOwnership.hpp used
- `include/diag/` - Not used
- `include/engines/` - Other engines not used
- `include/http/` - Not used
- `include/latency/` - Not used
- `include/metrics/` - Not used
- `include/micro/` - Not used
- `include/microscalp/` - Not used
- `include/microstructure/` - Not used
- `include/portfolio/` - Not used
- `include/quality/` - Not used
- `include/runtime/` - Not used
- `include/speed/` - Not used
- `include/symbol/` - Not used
- `include/system/` - Not used

---

## FIX ARTIFACTS IN ACTIVE CODE

### GUIBroadcaster.hpp
Line 202: `uint32_t fix_reconnects = 0;`
Line 743: `void updateConnections(bool ctrader, uint32_t fix_reconnects = 0)`
Line 1145: JSON includes `fix_reconnects`

**Action:** Remove fix_reconnects parameter, it's never used

---

## WHAT SHOULD EXIST (CLEAN ARCHITECTURE)

```
Chimera/
├── src/
│   └── main.cpp
├── include/
│   ├── engines/
│   │   └── ChimeraUnifiedEngine.hpp  (GOLD + NAS100 + US30)
│   ├── openapi/
│   │   ├── CTraderOpenAPIClient.hpp
│   │   └── CTraderTypes.hpp
│   ├── gui/
│   │   └── GUIBroadcaster.hpp
│   └── shared/
│       ├── TradingConfig.hpp
│       ├── GlobalRiskGovernor.hpp
│       └── DailyLossGuard.hpp
├── config.ini
├── chimera_dashboard.html
├── chimera_logo.png
└── CMakeLists.txt
```

**That's 10 files total, not 201.**

---

## WHY PRICES AREN'T SHOWING

### Problem Chain:
1. Dashboard connects to WebSocket (port 7777) ✓
2. WebSocket receives JSON from GUIBroadcaster ✓
3. JSON contains `symbols` array with prices
4. BUT `symbols` array is empty because...
5. `gui.updateTick()` is only called when ticks arrive
6. Ticks only arrive if OpenAPI subscription works
7. OpenAPI shows "Disconnected" in dashboard

### Root Cause Investigation:
- `isConnected()` returns `connected_ && appAuthed_ && accountAuthed_`
- If any of these are false, OpenAPI shows disconnected
- Need to check console logs on VPS for auth failures

### Possible Issues:
1. Token expired (access_token from config.ini)
2. Wrong host/port
3. Symbol names don't match broker (NAS100 vs USTEC)
4. SSL handshake failure
5. Account not authorized for OpenAPI

---

## RECOMMENDED ACTIONS

### IMMEDIATE (Fix Prices):
1. Check VPS console output for authentication errors
2. Verify access_token is valid
3. Check what symbol names broker actually uses
4. Add debug logging to processSymbolsList()

### SHORT TERM (Clean Up):
1. Delete all FIX code (10 files)
2. Delete old CfdEngine (3 files)
3. Delete unused directories (150+ files)

### MEDIUM TERM (Restructure):
1. Flatten to clean 10-file architecture
2. Single CMakeLists.txt with clear dependencies
3. Proper namespace organization

---

## ENGINES IN ChimeraUnifiedEngine.hpp

### Currently Implemented:
1. **XAUUSD_MeanRevert** - Gold mean reversion
2. **XAUUSD_StopFade** - Gold stop hunt fade
3. **XAUUSD_AcceptanceBreakout** - Gold acceptance breakout
4. **NAS100_OpenRangeSweep** - NAS100 OR sweep
5. **US30_OpenRangeSweep** - US30 OR sweep

### All Use CRTP Pattern:
```cpp
template<typename Derived>
class EngineCRTP {
    inline void on_tick(const Tick& t) {
        static_cast<Derived*>(this)->on_tick_impl(t);
    }
};
```

---

## END OF AUDIT
