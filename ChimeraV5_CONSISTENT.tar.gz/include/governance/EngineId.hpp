#pragma once
#include <string>

namespace Chimera {

enum class EngineId {
    XAUUSD,
    XAGUSD
};

inline const char* toString(EngineId id) {
    switch (id) {
        case EngineId::XAUUSD: return "XAUUSD";
        case EngineId::XAGUSD: return "XAGUSD";
        default: return "UNKNOWN";
    }
}

} // namespace Chimera
