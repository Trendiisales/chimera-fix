#pragma once

namespace Chimera {

enum class ExecutionMode {
    FULL,
    DEGRADED,
    DEFENSIVE,
    BLOCK
};

} // namespace Chimera
