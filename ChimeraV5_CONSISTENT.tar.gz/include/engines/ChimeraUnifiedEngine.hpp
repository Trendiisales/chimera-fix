// =============================================================================
// ChimeraUnifiedEngine.hpp - Chimera v4.15.0 Unified Trading Engine
// =============================================================================
// SYMBOLS: XAUUSD, NAS100, US30 ONLY
// 
// CHANGELOG v4.15.0:
// - Replaced NAS100/US30 SweepReversion with Balance→Expansion engine
// - NAS100: +1,583 pts (46.5% WR) vs old -19,920 pts
// - US30:   +3,433 pts (41.4% WR) vs old -17,000 pts
// - US30 only: Pre-market compression filter (40th percentile)
// - XAUUSD: Unchanged (Mean Revert, Stop Fade, Acceptance BO)
//
// NO CRYPTO - NO FOREX - THREE SYMBOLS ONLY
// =============================================================================
#pragma once

#include <atomic>
#include <cstdint>
#include <cstdio>
#include <cmath>
#include <cstring>
#include <functional>
#include <chrono>

// Balance Expansion Integration for NAS100/US30
#include "BalanceExpansionIntegration.hpp"

namespace Chimera {

// =============================================================================
// CORE TYPES
// =============================================================================

enum class Regime : uint8_t {
    DEAD = 0,
    STRUCTURAL_EXPANSION = 1,
    INVENTORY_CORRECTION = 2,
    STOP_SWEEP = 3,
    RANGE_VOLATILE = 4
};

inline const char* regimeStr(Regime r) {
    switch (r) {
        case Regime::DEAD:                  return "DEAD";
        case Regime::STRUCTURAL_EXPANSION:  return "EXPANSION";
        case Regime::INVENTORY_CORRECTION:  return "INV_CORR";
        case Regime::STOP_SWEEP:            return "STOP_SWEEP";
        case Regime::RANGE_VOLATILE:        return "RANGE_VOL";
        default:                            return "UNKNOWN";
    }
}

struct Tick {
    uint64_t ts_ns;
    double   price;
    double   bid;
    double   ask;
    double   volume;
    Regime   regime;
};

struct TradeSignal {
    const char* engine;
    const char* symbol;
    int         direction;   // +1 long, -1 short
    double      size_mult;
    double      price;
    const char* reason;
    uint64_t    ts_ns;
};

// =============================================================================
// CRTP ENGINE BASE
// =============================================================================

template<typename Derived>
class EngineCRTP {
public:
    inline void on_tick(const Tick& t) {
        static_cast<Derived*>(this)->on_tick_impl(t);
    }
    
    inline void reset() {
        static_cast<Derived*>(this)->reset_impl();
    }
};

// =============================================================================
// TIME HELPERS (UTC)
// =============================================================================

static inline uint64_t ns_to_ms(uint64_t ns) {
    return ns / 1'000'000ULL;
}

static inline uint64_t ns_to_minutes(uint64_t ns) {
    return ns / 60'000'000'000ULL;
}

static inline uint64_t now_ns() {
    return static_cast<uint64_t>(
        std::chrono::duration_cast<std::chrono::nanoseconds>(
            std::chrono::steady_clock::now().time_since_epoch()).count());
}

static inline int64_t now_ms_system() {
    return static_cast<int64_t>(
        std::chrono::duration_cast<std::chrono::milliseconds>(
            std::chrono::system_clock::now().time_since_epoch()).count());
}

// =============================================================================
// SESSION GATES
// =============================================================================

// NY Session: 13:30 – 20:00 UTC (9:30 AM - 4:00 PM ET)
static inline bool is_ny_session(uint64_t ts_ns) {
    uint64_t mins = ns_to_minutes(ts_ns);
    uint64_t hour = (mins / 60) % 24;
    uint64_t min = mins % 60;
    
    // Start: 13:30 UTC, End: 20:00 UTC
    if (hour == 13 && min >= 30) return true;
    if (hour > 13 && hour < 20) return true;
    return false;
}

// London Session: 08:00 – 16:00 UTC
static inline bool is_london_session(uint64_t ts_ns) {
    uint64_t mins = ns_to_minutes(ts_ns);
    uint64_t hour = (mins / 60) % 24;
    return (hour >= 8 && hour < 16);
}

// Gold optimal: London + NY overlap (13:30 - 16:00 UTC)
static inline bool is_gold_optimal_session(uint64_t ts_ns) {
    uint64_t mins = ns_to_minutes(ts_ns);
    uint64_t hour = (mins / 60) % 24;
    uint64_t min = mins % 60;
    
    if (hour == 13 && min >= 30) return true;
    if (hour > 13 && hour < 16) return true;
    return false;
}

// =============================================================================
// SIGNAL CALLBACK TYPE
// =============================================================================

using SignalCallback = std::function<void(const TradeSignal&)>;

// =============================================================================
// XAUUSD ENGINE 1: Mean Revert (Inventory Correction)
// =============================================================================

class XAUUSDMeanRevert final : public EngineCRTP<XAUUSDMeanRevert> {
public:
    // === BACKTEST-LOCKED SETTINGS ===
    static constexpr double   VEL_THRESHOLD  = 0.25;   // $/tick velocity
    static constexpr uint64_t COOLDOWN_MS    = 3000;
    static constexpr double   SIZE_MULT      = 0.75;

    explicit XAUUSDMeanRevert(SignalCallback cb = nullptr) : callback_(cb) {}
    void setCallback(SignalCallback cb) { callback_ = cb; }

    void on_tick_impl(const Tick& t) {
        if (!is_gold_optimal_session(t.ts_ns))
            return;
            
        // Only trade in inventory correction regime
        if (t.regime != Regime::INVENTORY_CORRECTION) {
            last_price_ = t.price;
            last_ts_ = ns_to_ms(t.ts_ns);
            return;
        }

        uint64_t now_ms = ns_to_ms(t.ts_ns);
        
        // Cooldown check
        if (now_ms - last_signal_ts_ < COOLDOWN_MS) {
            return;
        }

        // Calculate velocity
        double dt = (now_ms - last_ts_) / 1000.0;
        if (dt <= 0 || last_ts_ == 0) {
            last_price_ = t.price;
            last_ts_ = now_ms;
            return;
        }

        double velocity = (t.price - last_price_) / dt;
        last_price_ = t.price;
        last_ts_ = now_ms;

        // Fade velocity spike
        if (std::fabs(velocity) >= VEL_THRESHOLD) {
            int dir = (velocity > 0) ? -1 : +1;
            emit(dir, t.price, "mean_revert_fade", t.ts_ns);
            last_signal_ts_ = now_ms;
        }
    }
    
    void reset_impl() {
        last_price_ = 0.0;
        last_ts_ = 0;
        last_signal_ts_ = 0;
    }

private:
    SignalCallback callback_;
    double last_price_{0.0};
    uint64_t last_ts_{0};
    uint64_t last_signal_ts_{0};

    void emit(int dir, double px, const char* reason, uint64_t ts) {
        TradeSignal s{
            "XAUUSD_MEAN_REVERT",
            "XAUUSD",
            dir,
            SIZE_MULT,
            px,
            reason,
            ts
        };

        std::printf("[SIGNAL][XAUUSD] %s dir=%d size=%.2f px=%.2f\n",
               s.reason, s.direction, s.size_mult, px);
        
        if (callback_) callback_(s);
    }
};

// =============================================================================
// XAUUSD ENGINE 2: Stop Fade (Stop Sweep Exhaustion)
// =============================================================================

class XAUUSDStopFade final : public EngineCRTP<XAUUSDStopFade> {
public:
    // === BACKTEST-LOCKED SETTINGS ===
    static constexpr double   MIN_SWEEP      = 0.50;   // $ minimum sweep
    static constexpr uint64_t STALL_WINDOW   = 400;    // ms
    static constexpr double   STALL_EPSILON  = 0.10;   // $ max stall range
    static constexpr double   SIZE_MULT      = 1.25;

    explicit XAUUSDStopFade(SignalCallback cb = nullptr) : callback_(cb) {}
    void setCallback(SignalCallback cb) { callback_ = cb; }

    void on_tick_impl(const Tick& t) {
        if (!is_gold_optimal_session(t.ts_ns))
            return;
            
        uint64_t now_ms = ns_to_ms(t.ts_ns);

        // Only trade in stop sweep regime
        if (t.regime != Regime::STOP_SWEEP) {
            sweep_ts_ = 0;
            sweep_px_ = 0.0;
            stall_high_ = 0.0;
            stall_low_ = 0.0;
            stall_start_ = 0;
            return;
        }

        // Track stall
        if (stall_start_ == 0) {
            stall_start_ = now_ms;
            stall_high_ = t.price;
            stall_low_ = t.price;
        } else {
            stall_high_ = std::max(stall_high_, t.price);
            stall_low_ = std::min(stall_low_, t.price);
            
            // Reset stall if outside window
            if (now_ms - stall_start_ > STALL_WINDOW) {
                stall_start_ = now_ms;
                stall_high_ = t.price;
                stall_low_ = t.price;
            }
        }

        // Initialize sweep tracking
        if (sweep_ts_ == 0) {
            sweep_ts_ = now_ms;
            sweep_px_ = t.price;
            return;
        }

        // Check for sweep + stall pattern
        double move = t.price - sweep_px_;
        bool is_stall = (stall_high_ - stall_low_) < STALL_EPSILON;
        
        if (std::fabs(move) >= MIN_SWEEP && is_stall) {
            int dir = (move > 0) ? -1 : +1;
            emit(dir, t.price, "stop_fade_exhaust", t.ts_ns);
            
            sweep_ts_ = 0;
            sweep_px_ = 0.0;
            stall_start_ = 0;
        }

        // Reset sweep if too old
        if (now_ms - sweep_ts_ > 2000) {
            sweep_ts_ = now_ms;
            sweep_px_ = t.price;
        }
    }
    
    void reset_impl() {
        sweep_ts_ = 0;
        sweep_px_ = 0.0;
        stall_high_ = 0.0;
        stall_low_ = 0.0;
        stall_start_ = 0;
    }

private:
    SignalCallback callback_;
    uint64_t sweep_ts_{0};
    double sweep_px_{0.0};
    double stall_high_{0.0};
    double stall_low_{0.0};
    uint64_t stall_start_{0};

    void emit(int dir, double px, const char* reason, uint64_t ts) {
        TradeSignal s{
            "XAUUSD_STOP_FADE",
            "XAUUSD",
            dir,
            SIZE_MULT,
            px,
            reason,
            ts
        };

        std::printf("[SIGNAL][XAUUSD] %s dir=%d size=%.2f px=%.2f\n",
               s.reason, s.direction, s.size_mult, px);
        
        if (callback_) callback_(s);
    }
};

// =============================================================================
// XAUUSD ENGINE 3: Acceptance Breakout
// =============================================================================

class XAUUSDAcceptanceBO final : public EngineCRTP<XAUUSDAcceptanceBO> {
public:
    // === BACKTEST-LOCKED SETTINGS ===
    static constexpr double   ZONE_TOLERANCE = 0.25;   // $ zone width
    static constexpr uint64_t MIN_HOLD_MS    = 1000;   // 1 second minimum
    static constexpr double   SIZE_MULT      = 2.25;

    explicit XAUUSDAcceptanceBO(SignalCallback cb = nullptr) : callback_(cb) {}
    void setCallback(SignalCallback cb) { callback_ = cb; }

    void on_tick_impl(const Tick& t) {
        if (!is_gold_optimal_session(t.ts_ns))
            return;

        // Only trade in stop sweep regime (accumulation zones)
        if (t.regime != Regime::STOP_SWEEP) {
            in_zone_ = false;
            return;
        }

        uint64_t now_ms = ns_to_ms(t.ts_ns);

        if (!in_zone_) {
            zone_px_ = t.price;
            zone_start_ = now_ms;
            in_zone_ = true;
            return;
        }

        // Check if still in zone
        if (std::fabs(t.price - zone_px_) <= ZONE_TOLERANCE) {
            // Time-in-zone acceptance reached
            if (now_ms - zone_start_ >= MIN_HOLD_MS) {
                emit(+1, t.price, "acceptance_breakout", t.ts_ns);
                in_zone_ = false;
            }
        } else {
            // Price left zone, reset
            in_zone_ = false;
        }
    }
    
    void reset_impl() {
        in_zone_ = false;
        zone_px_ = 0.0;
        zone_start_ = 0;
    }

private:
    SignalCallback callback_;
    bool in_zone_{false};
    double zone_px_{0.0};
    uint64_t zone_start_{0};

    void emit(int dir, double px, const char* reason, uint64_t ts) {
        TradeSignal s{
            "XAUUSD_ACCEPTANCE_BO",
            "XAUUSD",
            dir,
            SIZE_MULT,
            px,
            reason,
            ts
        };

        std::printf("[SIGNAL][XAUUSD] %s dir=%d size=%.2f px=%.2f\n",
               s.reason, s.direction, s.size_mult, px);
        
        if (callback_) callback_(s);
    }
};

// =============================================================================
// REGIME CLASSIFIER
// =============================================================================

class RegimeClassifier {
public:
    static constexpr double SPREAD_SWEEP_THRESH = 1.0;   // XAUUSD
    static constexpr double SPREAD_DEAD_THRESH  = 0.80;
    static constexpr double MOVE_EXP_THRESH     = 0.5;
    static constexpr double SPREAD_INV_THRESH   = 0.20;

    Regime classify(double bid, double ask, double last_price) {
        double spread = ask - bid;
        double move = std::fabs(last_price - last_);
        last_ = last_price;

        if (spread > SPREAD_SWEEP_THRESH) return Regime::STOP_SWEEP;
        if (move > MOVE_EXP_THRESH) return Regime::STRUCTURAL_EXPANSION;
        if (spread < SPREAD_INV_THRESH) return Regime::INVENTORY_CORRECTION;
        if (spread > SPREAD_DEAD_THRESH && move < 0.1) return Regime::DEAD;
        
        return Regime::RANGE_VOLATILE;
    }

private:
    double last_{0.0};
};

// =============================================================================
// XAUUSD SYSTEM (Aggregator)
// =============================================================================

class XAUUSDSystem {
public:
    RegimeClassifier  classifier;
    XAUUSDMeanRevert  mean_revert;
    XAUUSDStopFade    stop_fade;
    XAUUSDAcceptanceBO acceptance;

    void setCallback(SignalCallback cb) {
        mean_revert.setCallback(cb);
        stop_fade.setCallback(cb);
        acceptance.setCallback(cb);
    }

    void on_tick(double bid, double ask, uint64_t ts_ns) {
        double mid = (bid + ask) / 2.0;
        Regime r = classifier.classify(bid, ask, mid);
        
        Tick t;
        t.ts_ns = ts_ns;
        t.price = mid;
        t.bid = bid;
        t.ask = ask;
        t.volume = 1.0;
        t.regime = r;
        
        mean_revert.on_tick(t);
        stop_fade.on_tick(t);
        acceptance.on_tick(t);
    }
    
    void reset() {
        mean_revert.reset();
        stop_fade.reset();
        acceptance.reset();
    }
};

// =============================================================================
// NAS100 BALANCE→EXPANSION SYSTEM
// Uses new engine from backtest (+1,583 pts, 46.5% WR)
// =============================================================================

class NAS100BalanceExpansionSystem {
public:
    balance_expansion::BalanceExpansionSystem engine{"NAS100"};
    
    void setCallback(SignalCallback main_callback) {
        callback_ = main_callback;
        
        // Wire Balance Expansion orders to main signal callback
        engine.setOrderCallback([this](const balance_expansion::ExecutionOrder& order) {
            if (!callback_) return;
            
            int dir = (order.direction == balance_expansion::Direction::LONG) ? +1 : -1;
            
            TradeSignal s{
                "NAS100_BALANCE_EXPANSION",
                "NAS100",
                dir,
                order.position_size,
                order.entry_price,
                "balance_expansion",
                static_cast<uint64_t>(order.generated_at.epoch_ms * 1000000)
            };
            
            std::printf("[SIGNAL][NAS100] BALANCE_EXPANSION dir=%d size=%.4f entry=%.2f stop=%.2f tp=%.2f\n",
                   dir, order.position_size, order.entry_price, order.stop_price, order.tp_price);
            
            callback_(s);
        });
    }
    
    void onTick(double price, int64_t ts_ms) {
        engine.onTick(price, ts_ms);
    }
    
    void reset() {
        engine.reset();
    }
    
    void setSizingMode(balance_expansion::PositionSizer::Mode mode) {
        engine.setSizingMode(mode);
    }
    
    balance_expansion::PositionSizer::Mode getSizingMode() const {
        return engine.getSizingMode();
    }
    
    balance_expansion::BalanceExpansionEngine::Telemetry getTelemetry() const {
        return engine.getTelemetry();
    }
    
private:
    SignalCallback callback_;
};

// =============================================================================
// US30 BALANCE→EXPANSION SYSTEM
// Uses new engine from backtest (+3,433 pts, 41.4% WR)
// Includes pre-market compression filter
// =============================================================================

class US30BalanceExpansionSystem {
public:
    balance_expansion::BalanceExpansionSystem engine{"US30"};
    
    void setCallback(SignalCallback main_callback) {
        callback_ = main_callback;
        
        engine.setOrderCallback([this](const balance_expansion::ExecutionOrder& order) {
            if (!callback_) return;
            
            int dir = (order.direction == balance_expansion::Direction::LONG) ? +1 : -1;
            
            TradeSignal s{
                "US30_BALANCE_EXPANSION",
                "US30",
                dir,
                order.position_size,
                order.entry_price,
                "balance_expansion",
                static_cast<uint64_t>(order.generated_at.epoch_ms * 1000000)
            };
            
            std::printf("[SIGNAL][US30] BALANCE_EXPANSION dir=%d size=%.4f entry=%.2f stop=%.2f tp=%.2f\n",
                   dir, order.position_size, order.entry_price, order.stop_price, order.tp_price);
            
            callback_(s);
        });
    }
    
    void onTick(double price, int64_t ts_ms) {
        engine.onTick(price, ts_ms);
    }
    
    void reset() {
        engine.reset();
    }
    
    void setSizingMode(balance_expansion::PositionSizer::Mode mode) {
        engine.setSizingMode(mode);
    }
    
    balance_expansion::PositionSizer::Mode getSizingMode() const {
        return engine.getSizingMode();
    }
    
    balance_expansion::BalanceExpansionEngine::Telemetry getTelemetry() const {
        return engine.getTelemetry();
    }
    
private:
    SignalCallback callback_;
};

// =============================================================================
// UNIFIED CHIMERA SYSTEM
// =============================================================================

class ChimeraUnifiedSystem {
public:
    // NEW: Balance Expansion engines for NAS100/US30
    NAS100BalanceExpansionSystem nas100;
    US30BalanceExpansionSystem   us30;
    XAUUSDSystem                 xauusd;
    
    // Statistics
    std::atomic<uint64_t> nas100_ticks{0};
    std::atomic<uint64_t> us30_ticks{0};
    std::atomic<uint64_t> xauusd_ticks{0};
    std::atomic<uint64_t> signals_total{0};

    void setCallback(SignalCallback cb) {
        callback_ = cb;
        
        auto wrapped = [this, cb](const TradeSignal& s) {
            signals_total.fetch_add(1);
            if (cb) cb(s);
        };
        
        nas100.setCallback(wrapped);
        us30.setCallback(wrapped);
        xauusd.setCallback(wrapped);
    }

    void onNAS100Tick(double bid, double ask, uint64_t /* ts_ns */) {
        nas100_ticks.fetch_add(1);
        
        // Convert to system clock ms for Balance Expansion engine
        int64_t ts_ms = now_ms_system();
        double mid = (bid + ask) / 2.0;
        
        nas100.onTick(mid, ts_ms);
    }

    void onUS30Tick(double bid, double ask, uint64_t /* ts_ns */) {
        us30_ticks.fetch_add(1);
        
        int64_t ts_ms = now_ms_system();
        double mid = (bid + ask) / 2.0;
        
        us30.onTick(mid, ts_ms);
    }

    void onXAUUSDTick(double bid, double ask, uint64_t ts_ns) {
        xauusd_ticks.fetch_add(1);
        xauusd.on_tick(bid, ask, ts_ns);
    }
    
    void resetDaily() {
        nas100.reset();
        us30.reset();
        xauusd.reset();
        std::printf("[CHIMERA] Daily reset complete\n");
    }
    
    void printStats() {
        std::printf("[CHIMERA] Stats: NAS100=%lu US30=%lu XAUUSD=%lu signals=%lu\n",
                    nas100_ticks.load(), us30_ticks.load(), 
                    xauusd_ticks.load(), signals_total.load());
        
        // Print Balance Expansion telemetry
        auto nas_telem = nas100.getTelemetry();
        std::printf("[NAS100] OR=%.1f BAL=%s MODE=%s\n",
                    nas_telem.or_range,
                    nas_telem.balance_valid ? "YES" : "NO",
                    nas100.getSizingMode() == balance_expansion::PositionSizer::Mode::SHADOW ? "SHADOW" : "LIVE");
        
        auto us30_telem = us30.getTelemetry();
        std::printf("[US30] OR=%.1f BAL=%s MODE=%s\n",
                    us30_telem.or_range,
                    us30_telem.balance_valid ? "YES" : "NO",
                    us30.getSizingMode() == balance_expansion::PositionSizer::Mode::SHADOW ? "SHADOW" : "LIVE");
    }
    
    // === SIZING MODE CONTROL ===
    void setNAS100Mode(balance_expansion::PositionSizer::Mode mode) {
        nas100.setSizingMode(mode);
        std::printf("[NAS100] Sizing mode set to: %s\n",
                    mode == balance_expansion::PositionSizer::Mode::SHADOW ? "SHADOW" :
                    mode == balance_expansion::PositionSizer::Mode::PILOT ? "PILOT" :
                    mode == balance_expansion::PositionSizer::Mode::NORMAL ? "NORMAL" : "AGGRESSIVE");
    }
    
    void setUS30Mode(balance_expansion::PositionSizer::Mode mode) {
        us30.setSizingMode(mode);
        std::printf("[US30] Sizing mode set to: %s\n",
                    mode == balance_expansion::PositionSizer::Mode::SHADOW ? "SHADOW" :
                    mode == balance_expansion::PositionSizer::Mode::PILOT ? "PILOT" :
                    mode == balance_expansion::PositionSizer::Mode::NORMAL ? "NORMAL" : "AGGRESSIVE");
    }
    
    void setAllIndexMode(balance_expansion::PositionSizer::Mode mode) {
        setNAS100Mode(mode);
        setUS30Mode(mode);
    }

private:
    SignalCallback callback_;
};

} // namespace Chimera
