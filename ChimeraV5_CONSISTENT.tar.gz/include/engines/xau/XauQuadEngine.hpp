// =============================================================================
// XauQuadEngine.hpp - ORCHESTRATOR FOR 4 VALIDATED XAU ENGINES
// =============================================================================
//
// MANAGES:
//   1. XauMicroAlphaEngine  (Tick)  - PF 1.50 stress - 45 trades
//   2. XauFadeLowEngine     (4H)    - PF 1.94 stress - 41 trades
//   3. XauRangeBreakEngine  (4H)    - PF 1.49 stress - 161 trades
//   4. XauVolBreakEngine    (1H)    - PF 1.43 stress - 52 trades
//
// ARCHITECTURE:
//   - Each engine has OWN position (no shared state)
//   - Each engine has OWN kill switch
//   - Each engine has OWN stats
//   - Bar aggregation from tick feed
//   - Unified order routing
//
// TOTAL POTENTIAL: 299 trades / 10 months across 4 strategies
// =============================================================================
#pragma once

#include "XauMicroAlphaEngine.hpp"
#include "XauFadeLowEngine.hpp"
#include "XauRangeBreakEngine.hpp"
#include "XauVolBreakEngine.hpp"

#include <cstdint>
#include <cstdio>
#include <functional>
#include <atomic>
#include <chrono>
#include <ctime>

namespace xau {

// =============================================================================
// UNIFIED TRADE RECORD (for callbacks)
// =============================================================================
struct XauUnifiedTradeRecord {
    char   engine[32]       = {0};
    double entry_price      = 0.0;
    double exit_price       = 0.0;
    double size             = 0.0;
    double pnl_dollars      = 0.0;
    double pnl_points       = 0.0;
    char   exit_reason[32]  = {0};
    uint64_t entry_ts       = 0;
    uint64_t exit_ts        = 0;
};

// =============================================================================
// QUAD ENGINE STATUS
// =============================================================================
struct QuadEngineStatus {
    // Per-engine status
    bool micro_alpha_enabled  = true;
    bool micro_alpha_killed   = false;
    bool micro_alpha_in_pos   = false;
    double micro_alpha_pnl    = 0.0;
    int micro_alpha_trades    = 0;
    
    bool fade_low_enabled     = true;
    bool fade_low_killed      = false;
    bool fade_low_in_pos      = false;
    double fade_low_pnl       = 0.0;
    int fade_low_trades       = 0;
    
    bool range_break_enabled  = true;
    bool range_break_killed   = false;
    bool range_break_in_pos   = false;
    double range_break_pnl    = 0.0;
    int range_break_trades    = 0;
    
    bool vol_break_enabled    = true;
    bool vol_break_killed     = false;
    bool vol_break_in_pos     = false;
    double vol_break_pnl      = 0.0;
    int vol_break_trades      = 0;
    
    // Aggregate
    int total_positions       = 0;
    double total_pnl          = 0.0;
    int total_trades          = 0;
    bool master_killed        = false;
};

// =============================================================================
// XAU QUAD ENGINE
// =============================================================================
class XauQuadEngine {
public:
    // =========================================================================
    // CALLBACK TYPES
    // =========================================================================
    using OrderCallback = std::function<void(const char* symbol, bool is_buy, double qty)>;
    using TradeCallback = std::function<void(const XauUnifiedTradeRecord& trade)>;

    // =========================================================================
    // CONSTRUCTOR
    // =========================================================================
    XauQuadEngine() {
        initializeBarState();
        wireInternalCallbacks();
    }

    // =========================================================================
    // CONFIGURATION
    // =========================================================================
    void setOrderCallback(OrderCallback cb) { 
        order_callback_ = std::move(cb);
        // Wire to all engines
        micro_alpha_.setOrderCallback([this](const char* sym, bool buy, double qty) {
            if (order_callback_) order_callback_(sym, buy, qty);
        });
        fade_low_.setOrderCallback([this](const char* sym, bool buy, double qty) {
            if (order_callback_) order_callback_(sym, buy, qty);
        });
        range_break_.setOrderCallback([this](const char* sym, bool buy, double qty) {
            if (order_callback_) order_callback_(sym, buy, qty);
        });
        vol_break_.setOrderCallback([this](const char* sym, bool buy, double qty) {
            if (order_callback_) order_callback_(sym, buy, qty);
        });
    }
    
    void setTradeCallback(TradeCallback cb) { 
        trade_callback_ = std::move(cb); 
    }
    
    void setEquity(double equity) {
        equity_ = equity;
        micro_alpha_.setEquity(equity);
        fade_low_.setEquity(equity);
        range_break_.setEquity(equity);
        vol_break_.setEquity(equity);
    }
    
    void setRiskPercent(double pct) {
        micro_alpha_.setRiskPercent(pct);
        fade_low_.setRiskPercent(pct);
        range_break_.setRiskPercent(pct);
        vol_break_.setRiskPercent(pct);
    }
    
    void setMaxSpread(double spread) {
        max_spread_ = spread;
        micro_alpha_.setMaxSpread(spread);
        // Bar strategies have wider tolerance
        fade_low_.setMaxSpread(spread * 2.0);
        range_break_.setMaxSpread(spread * 2.0);
        vol_break_.setMaxSpread(spread * 2.0);
    }
    
    void setDefaultSize(double size) {
        default_size_ = size;
        micro_alpha_.setDefaultSize(size);
        fade_low_.setDefaultSize(size);
        range_break_.setDefaultSize(size);
        vol_break_.setDefaultSize(size);
    }

    // =========================================================================
    // ENABLE/DISABLE INDIVIDUAL ENGINES
    // =========================================================================
    void enableMicroAlpha(bool e) { micro_alpha_.enable(e); }
    void enableFadeLow(bool e)    { fade_low_.enable(e); }
    void enableRangeBreak(bool e) { range_break_.enable(e); }
    void enableVolBreak(bool e)   { vol_break_.enable(e); }

    // =========================================================================
    // KILL SWITCHES
    // =========================================================================
    
    // Master kill - kills ALL engines
    void killAll() {
        master_killed_.store(true);
        micro_alpha_.kill();
        fade_low_.kill();
        range_break_.kill();
        vol_break_.kill();
        printf("[XAU_QUAD] MASTER KILL - All engines killed\n");
    }
    
    void unkillAll() {
        master_killed_.store(false);
        micro_alpha_.unkill();
        fade_low_.unkill();
        range_break_.unkill();
        vol_break_.unkill();
        printf("[XAU_QUAD] MASTER UNKILL - All engines restored\n");
    }
    
    // Individual engine kills
    void killMicroAlpha()  { micro_alpha_.kill(); }
    void killFadeLow()     { fade_low_.kill(); }
    void killRangeBreak()  { range_break_.kill(); }
    void killVolBreak()    { vol_break_.kill(); }
    
    void unkillMicroAlpha()  { micro_alpha_.unkill(); }
    void unkillFadeLow()     { fade_low_.unkill(); }
    void unkillRangeBreak()  { range_break_.unkill(); }
    void unkillVolBreak()    { vol_break_.unkill(); }
    
    bool isMasterKilled() const { return master_killed_.load(); }

    // =========================================================================
    // TICK FEED (Routes to all engines + bar aggregation)
    // =========================================================================
    void onTick(double bid, double ask, uint64_t ts_ns = 0) {
        if (master_killed_.load()) return;
        
        uint64_t now = ts_ns > 0 ? ts_ns : nowNs();
        double mid = (bid + ask) * 0.5;
        double spread = ask - bid;
        
        // Update spread for bar engines
        fade_low_.updateSpread(spread);
        range_break_.updateSpread(spread);
        vol_break_.updateSpread(spread);
        
        // Route to tick-based engine
        micro_alpha_.onTick(bid, ask, ts_ns);
        
        // Aggregate bars
        aggregateBars(mid, now);
        
        total_ticks_++;
    }

    // =========================================================================
    // DIRECT BAR FEEDS (if external bar source available)
    // =========================================================================
    void on1HBar(double o, double h, double l, double c, uint64_t ts = 0) {
        vol_break_.on1HBar(o, h, l, c, ts);
    }
    
    void on4HBar(double o, double h, double l, double c, uint64_t ts = 0) {
        fade_low_.on4HBar(o, h, l, c, ts);
        range_break_.on4HBar(o, h, l, c, ts);
    }

    // =========================================================================
    // STATE QUERIES
    // =========================================================================
    QuadEngineStatus getStatus() const {
        QuadEngineStatus s;
        
        s.micro_alpha_enabled = micro_alpha_.isEnabled();
        s.micro_alpha_killed = micro_alpha_.isKilled();
        s.micro_alpha_in_pos = micro_alpha_.hasPosition();
        s.micro_alpha_pnl = micro_alpha_.getTotalPnL();
        s.micro_alpha_trades = micro_alpha_.getTotalTrades();
        
        s.fade_low_enabled = fade_low_.isEnabled();
        s.fade_low_killed = fade_low_.isKilled();
        s.fade_low_in_pos = fade_low_.hasPosition();
        s.fade_low_pnl = fade_low_.getTotalPnL();
        s.fade_low_trades = fade_low_.getTotalTrades();
        
        s.range_break_enabled = range_break_.isEnabled();
        s.range_break_killed = range_break_.isKilled();
        s.range_break_in_pos = range_break_.hasPosition();
        s.range_break_pnl = range_break_.getTotalPnL();
        s.range_break_trades = range_break_.getTotalTrades();
        
        s.vol_break_enabled = vol_break_.isEnabled();
        s.vol_break_killed = vol_break_.isKilled();
        s.vol_break_in_pos = vol_break_.hasPosition();
        s.vol_break_pnl = vol_break_.getTotalPnL();
        s.vol_break_trades = vol_break_.getTotalTrades();
        
        s.total_positions = (s.micro_alpha_in_pos ? 1 : 0) + 
                           (s.fade_low_in_pos ? 1 : 0) +
                           (s.range_break_in_pos ? 1 : 0) +
                           (s.vol_break_in_pos ? 1 : 0);
        s.total_pnl = s.micro_alpha_pnl + s.fade_low_pnl + 
                      s.range_break_pnl + s.vol_break_pnl;
        s.total_trades = s.micro_alpha_trades + s.fade_low_trades + 
                         s.range_break_trades + s.vol_break_trades;
        s.master_killed = master_killed_.load();
        
        return s;
    }
    
    double getTotalPnL() const {
        return micro_alpha_.getTotalPnL() + fade_low_.getTotalPnL() + 
               range_break_.getTotalPnL() + vol_break_.getTotalPnL();
    }
    
    int getTotalTrades() const {
        return micro_alpha_.getTotalTrades() + fade_low_.getTotalTrades() + 
               range_break_.getTotalTrades() + vol_break_.getTotalTrades();
    }
    
    int getTotalPositions() const {
        return (micro_alpha_.hasPosition() ? 1 : 0) + 
               (fade_low_.hasPosition() ? 1 : 0) +
               (range_break_.hasPosition() ? 1 : 0) +
               (vol_break_.hasPosition() ? 1 : 0);
    }

    // =========================================================================
    // RESET
    // =========================================================================
    void reset() {
        micro_alpha_.reset();
        fade_low_.reset();
        range_break_.reset();
        vol_break_.reset();
        initializeBarState();
    }
    
    void resetStats() {
        micro_alpha_.resetStats();
        fade_low_.resetStats();
        range_break_.resetStats();
        vol_break_.resetStats();
        total_ticks_ = 0;
    }
    
    void resetDaily() {
        // Just reset stats, not positions
        resetStats();
        printf("[XAU_QUAD] Daily reset complete\n");
    }

    // =========================================================================
    // DEBUG
    // =========================================================================
    void printStats() const {
        printf("\n========================================\n");
        printf("XAU QUAD ENGINE - STATUS\n");
        printf("========================================\n");
        
        auto s = getStatus();
        
        printf("MICRO_ALPHA (Tick): %s %s | Trades: %d | PnL: $%.2f\n",
               s.micro_alpha_enabled ? "ON" : "OFF",
               s.micro_alpha_killed ? "[KILLED]" : "",
               s.micro_alpha_trades, s.micro_alpha_pnl);
        
        printf("FADE_LOW    (4H):   %s %s | Trades: %d | PnL: $%.2f\n",
               s.fade_low_enabled ? "ON" : "OFF",
               s.fade_low_killed ? "[KILLED]" : "",
               s.fade_low_trades, s.fade_low_pnl);
        
        printf("RANGE_BREAK (4H):   %s %s | Trades: %d | PnL: $%.2f\n",
               s.range_break_enabled ? "ON" : "OFF",
               s.range_break_killed ? "[KILLED]" : "",
               s.range_break_trades, s.range_break_pnl);
        
        printf("VOL_BREAK   (1H):   %s %s | Trades: %d | PnL: $%.2f\n",
               s.vol_break_enabled ? "ON" : "OFF",
               s.vol_break_killed ? "[KILLED]" : "",
               s.vol_break_trades, s.vol_break_pnl);
        
        printf("----------------------------------------\n");
        printf("TOTAL: Positions=%d Trades=%d PnL=$%.2f\n",
               s.total_positions, s.total_trades, s.total_pnl);
        printf("Master Kill: %s\n", s.master_killed ? "YES" : "NO");
        printf("========================================\n\n");
    }

    // =========================================================================
    // DIRECT ENGINE ACCESS (for advanced control)
    // =========================================================================
    XauMicroAlphaEngine& getMicroAlpha() { return micro_alpha_; }
    XauFadeLowEngine& getFadeLow() { return fade_low_; }
    XauRangeBreakEngine& getRangeBreak() { return range_break_; }
    XauVolBreakEngine& getVolBreak() { return vol_break_; }

private:
    // =========================================================================
    // INTERNAL CALLBACKS
    // =========================================================================
    void wireInternalCallbacks() {
        // Wire trade callbacks to unified format
        micro_alpha_.setTradeCallback([this](const MicroAlphaTradeRecord& t) {
            if (trade_callback_) {
                XauUnifiedTradeRecord u;
                std::strncpy(u.engine, "MICRO_ALPHA", sizeof(u.engine) - 1);
                u.entry_price = t.entry_price;
                u.exit_price = t.exit_price;
                u.size = t.size;
                u.pnl_dollars = t.pnl_dollars;
                u.pnl_points = t.pnl_points;
                std::strncpy(u.exit_reason, t.exit_reason, sizeof(u.exit_reason) - 1);
                u.entry_ts = t.entry_ts;
                u.exit_ts = t.exit_ts;
                trade_callback_(u);
            }
        });
        
        fade_low_.setTradeCallback([this](const FadeLowTradeRecord& t) {
            if (trade_callback_) {
                XauUnifiedTradeRecord u;
                std::strncpy(u.engine, "FADE_LOW", sizeof(u.engine) - 1);
                u.entry_price = t.entry_price;
                u.exit_price = t.exit_price;
                u.size = t.size;
                u.pnl_dollars = t.pnl_dollars;
                u.pnl_points = t.pnl_points;
                std::strncpy(u.exit_reason, t.exit_reason, sizeof(u.exit_reason) - 1);
                u.entry_ts = t.entry_ts;
                u.exit_ts = t.exit_ts;
                trade_callback_(u);
            }
        });
        
        range_break_.setTradeCallback([this](const RangeBreakTradeRecord& t) {
            if (trade_callback_) {
                XauUnifiedTradeRecord u;
                std::strncpy(u.engine, "RANGE_BREAK", sizeof(u.engine) - 1);
                u.entry_price = t.entry_price;
                u.exit_price = t.exit_price;
                u.size = t.size;
                u.pnl_dollars = t.pnl_dollars;
                u.pnl_points = t.pnl_points;
                std::strncpy(u.exit_reason, t.exit_reason, sizeof(u.exit_reason) - 1);
                u.entry_ts = t.entry_ts;
                u.exit_ts = t.exit_ts;
                trade_callback_(u);
            }
        });
        
        vol_break_.setTradeCallback([this](const VolBreakTradeRecord& t) {
            if (trade_callback_) {
                XauUnifiedTradeRecord u;
                std::strncpy(u.engine, "VOL_BREAK", sizeof(u.engine) - 1);
                u.entry_price = t.entry_price;
                u.exit_price = t.exit_price;
                u.size = t.size;
                u.pnl_dollars = t.pnl_dollars;
                u.pnl_points = t.pnl_points;
                std::strncpy(u.exit_reason, t.exit_reason, sizeof(u.exit_reason) - 1);
                u.entry_ts = t.entry_ts;
                u.exit_ts = t.exit_ts;
                trade_callback_(u);
            }
        });
    }

    // =========================================================================
    // BAR AGGREGATION
    // =========================================================================
    void initializeBarState() {
        // Initialize bar tracking
        bar_1h_open_ = 0.0;
        bar_1h_high_ = -1e9;
        bar_1h_low_ = 1e9;
        bar_1h_close_ = 0.0;
        bar_1h_ts_ = 0;
        bar_1h_count_ = 0;
        
        bar_4h_open_ = 0.0;
        bar_4h_high_ = -1e9;
        bar_4h_low_ = 1e9;
        bar_4h_close_ = 0.0;
        bar_4h_ts_ = 0;
        bar_4h_count_ = 0;
        
        last_1h_hour_ = -1;
        last_4h_slot_ = -1;
    }
    
    void aggregateBars(double price, uint64_t ts_ns) {
        // Convert to wall-clock hour (UTC)
        uint64_t ts_ms = ts_ns / 1'000'000ULL;
        int64_t ts_sec = static_cast<int64_t>(ts_ms / 1000);
        std::tm tm = *std::gmtime(&ts_sec);
        int hour = tm.tm_hour;
        int day = tm.tm_yday;
        
        // 1H Bar aggregation
        if (last_1h_hour_ < 0) {
            // First tick - initialize
            bar_1h_open_ = price;
            bar_1h_high_ = price;
            bar_1h_low_ = price;
            bar_1h_ts_ = ts_ns;
            last_1h_hour_ = hour;
            last_1h_day_ = day;
        } else if (hour != last_1h_hour_ || day != last_1h_day_) {
            // New hour - emit bar and reset
            if (bar_1h_count_ > 0) {
                vol_break_.on1HBar(bar_1h_open_, bar_1h_high_, bar_1h_low_, 
                                   bar_1h_close_, bar_1h_ts_);
            }
            
            bar_1h_open_ = price;
            bar_1h_high_ = price;
            bar_1h_low_ = price;
            bar_1h_ts_ = ts_ns;
            bar_1h_count_ = 0;
            last_1h_hour_ = hour;
            last_1h_day_ = day;
        }
        
        // Update 1H bar
        bar_1h_high_ = std::max(bar_1h_high_, price);
        bar_1h_low_ = std::min(bar_1h_low_, price);
        bar_1h_close_ = price;
        bar_1h_count_++;
        
        // 4H Bar aggregation (slots: 0-3, 4-7, 8-11, 12-15, 16-19, 20-23)
        int slot_4h = hour / 4;
        
        if (last_4h_slot_ < 0) {
            // First tick - initialize
            bar_4h_open_ = price;
            bar_4h_high_ = price;
            bar_4h_low_ = price;
            bar_4h_ts_ = ts_ns;
            last_4h_slot_ = slot_4h;
            last_4h_day_ = day;
        } else if (slot_4h != last_4h_slot_ || day != last_4h_day_) {
            // New 4H slot - emit bar and reset
            if (bar_4h_count_ > 0) {
                fade_low_.on4HBar(bar_4h_open_, bar_4h_high_, bar_4h_low_, 
                                  bar_4h_close_, bar_4h_ts_);
                range_break_.on4HBar(bar_4h_open_, bar_4h_high_, bar_4h_low_, 
                                     bar_4h_close_, bar_4h_ts_);
            }
            
            bar_4h_open_ = price;
            bar_4h_high_ = price;
            bar_4h_low_ = price;
            bar_4h_ts_ = ts_ns;
            bar_4h_count_ = 0;
            last_4h_slot_ = slot_4h;
            last_4h_day_ = day;
        }
        
        // Update 4H bar
        bar_4h_high_ = std::max(bar_4h_high_, price);
        bar_4h_low_ = std::min(bar_4h_low_, price);
        bar_4h_close_ = price;
        bar_4h_count_++;
    }

    // =========================================================================
    // TIME HELPERS
    // =========================================================================
    static uint64_t nowNs() {
        return static_cast<uint64_t>(
            std::chrono::duration_cast<std::chrono::nanoseconds>(
                std::chrono::steady_clock::now().time_since_epoch()).count());
    }

    // =========================================================================
    // ENGINES
    // =========================================================================
    XauMicroAlphaEngine micro_alpha_;
    XauFadeLowEngine fade_low_;
    XauRangeBreakEngine range_break_;
    XauVolBreakEngine vol_break_;

    // =========================================================================
    // CALLBACKS
    // =========================================================================
    OrderCallback order_callback_;
    TradeCallback trade_callback_;

    // =========================================================================
    // CONFIG
    // =========================================================================
    double equity_ = 10000.0;
    double max_spread_ = 5.0;
    double default_size_ = 0.0;
    std::atomic<bool> master_killed_{false};

    // =========================================================================
    // BAR AGGREGATION STATE
    // =========================================================================
    
    // 1H bar
    double bar_1h_open_;
    double bar_1h_high_;
    double bar_1h_low_;
    double bar_1h_close_;
    uint64_t bar_1h_ts_;
    int bar_1h_count_;
    int last_1h_hour_;
    int last_1h_day_;
    
    // 4H bar
    double bar_4h_open_;
    double bar_4h_high_;
    double bar_4h_low_;
    double bar_4h_close_;
    uint64_t bar_4h_ts_;
    int bar_4h_count_;
    int last_4h_slot_;
    int last_4h_day_;

    // =========================================================================
    // STATS
    // =========================================================================
    uint64_t total_ticks_ = 0;
};

} // namespace xau
