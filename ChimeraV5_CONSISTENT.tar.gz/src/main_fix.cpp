#include <iostream>
#include <string>
#include <unordered_map>
#include <vector>
#include <algorithm>
#include <chrono>

#include "execution/SymbolExecutor.hpp"
#include "gui/GUIBroadcaster.hpp"
#include "fix/FixClient.hpp"
#include "engines/xau/XauQuadEngine.hpp"

// ============================================================
// TIME UTILITY
// ============================================================

static inline uint64_t now_ns() {
    return std::chrono::duration_cast<std::chrono::nanoseconds>(
        std::chrono::steady_clock::now().time_since_epoch()
    ).count();
}

int main(int argc, char** argv) {
    std::cout << "Starting Chimera v5 (FIX mode, latency enabled)\n";

    GUIBroadcaster gui;
    FixClient fix;

    // ============================================================
    // EXECUTION AUTHORITY
    // ============================================================

    SymbolExecutor xau_executor(
        "XAUUSD",
        200.0,
        6
    );

    // ============================================================
    // GOLD QUAD ENGINE (SOLE SIGNAL SOURCE)
    // ============================================================

    XauQuadEngine xau_quad;

    // ============================================================
    // LATENCY TRACKING STATE (v5)
    // ============================================================

    std::unordered_map<uint64_t, uint64_t> order_send_ts;
    std::vector<double> latency_samples_ms;

    auto publish_latency_stats = [&]() {
        if (latency_samples_ms.size() < 5)
            return;

        std::sort(latency_samples_ms.begin(), latency_samples_ms.end());

        auto pct = [&](double p) {
            size_t idx = static_cast<size_t>(p * (latency_samples_ms.size() - 1));
            return latency_samples_ms[idx];
        };

        gui.updateHotPathLatency(
            latency_samples_ms.front(),
            pct(0.10),
            pct(0.50),
            pct(0.90),
            pct(0.99),
            latency_samples_ms.size(),
            /* spikes_filtered = */ 0,
            /* state = */ "LIVE",
            /* exec_mode = */ "FIX"
        );

        // keep rolling window small & responsive
        if (latency_samples_ms.size() > 200)
            latency_samples_ms.erase(
                latency_samples_ms.begin(),
                latency_samples_ms.begin() + 100
            );
    };

    // ============================================================
    // SIGNAL → EXECUTOR
    // ============================================================

    xau_quad.setSignalCallback(
        [&](const XauQuadEngine::SignalIntent& intent) {
            if (intent.direction == 0)
                return;

            uint64_t order_id = xau_executor.onSignal(
                intent.direction,
                intent.confidence,
                intent.suggested_size,
                intent.suggested_stop_dist,
                intent.tag
            );

            // record send time
            order_send_ts[order_id] = now_ns();

            gui.broadcastSignal(
                "XAUUSD",
                intent.direction,
                intent.confidence,
                intent.tag
            );
        }
    );

    // ============================================================
    // FIX TICKS
    // ============================================================

    fix.setTickHandler(
        [&](const std::string& symbol,
            double bid,
            double ask,
            double volume,
            uint64_t ts_ns)
        {
            gui.updateSymbolTick(symbol, bid, ask, ts_ns);

            if (symbol == "XAUUSD") {
                xau_quad.onTick(bid, ask, volume, ts_ns);
            }
        }
    );

    // ============================================================
    // FIX EXECUTION REPORTS
    // ============================================================

    fix.setExecutionReportHandler(
        [&](const FixExecutionReport& rpt)
        {
            uint64_t recv_ts = now_ns();

            auto it = order_send_ts.find(rpt.order_id);
            if (it != order_send_ts.end()) {
                double latency_ms =
                    (recv_ts - it->second) / 1e6;

                latency_samples_ms.push_back(latency_ms);
                order_send_ts.erase(it);

                publish_latency_stats();
            }

            xau_executor.onExecutionReport(rpt);

            gui.broadcastTrade(
                rpt.symbol,
                rpt.side,
                rpt.price,
                rpt.qty,
                rpt.exec_type
            );
        }
    );

    // ============================================================
    // CONNECT + RUN
    // ============================================================

    if (!fix.connect()) {
        std::cerr << "FIX connection failed\n";
        return 1;
    }

    std::cout << "Chimera v5 LIVE — XAU Quad + latency metrics active\n";

    fix.run();
    return 0;
}
