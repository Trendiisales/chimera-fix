# CLEAN GOVERNANCE ARCHITECTURE

**Metals-Only | Single Source of Truth | Anti-Paralysis**

═══════════════════════════════════════════════════════════════

## 🎯 DESIGN PRINCIPLES

**1. Single Governance Layer**
- ALL risk decisions in ExecutionAuthority
- NO governance inside FIX layer
- NO duplicate risk checks

**2. Metals Only**
- XAUUSD + XAGUSD
- NO NAS100, NO US30, NO CFD

**3. Anti-Paralysis Protection**
- Minimum trade size clamp
- Tiered scaling (not binary blocking)
- Smoothed indicators (no oscillation)

**4. Clean Architecture**
```
Strategy
    ↓
ExecutionAuthority
    ↓
FIX Session
    ↓
Transport
```

═══════════════════════════════════════════════════════════════

## 📂 GOVERNANCE FILES

### **include/governance/**

```
EngineId.hpp                 - XAUUSD + XAGUSD only
ExecutionMode.hpp            - FULL/DEGRADED/DEFENSIVE/BLOCK
LatencyGovernor.hpp          - Tiered latency scaling with smoothing
VolatilityGovernor.hpp       - Smoothed volatility scaling
PositionGovernor.hpp         - Cross-metal exposure check
CorrelationGovernor.hpp      - Directional correlation scaling
ExecutionAuthority.hpp       - Unified controller with min size clamp
```

═══════════════════════════════════════════════════════════════

## 🔧 KEY IMPROVEMENTS

### **1. Tiered Latency Scaling (Not Binary)**

**Previous (Binary):**
```
if (latency > 7ms) → BLOCK
```

**Current (Tiered):**
```
< 5ms  → 1.0   (Full)
< 10ms → 0.75  (Slightly degraded)
< 20ms → 0.5   (Degraded)
< 50ms → 0.25  (Defensive)
> 50ms → BLOCK (Connection unstable)
```

### **2. Smoothed Volatility (No Oscillation)**

**With smoothing:**
```cpp
smoothed_vol = 0.1 * new_vol + 0.9 * old_vol
```

**Prevents rapid FULL ↔ DEGRADED thrashing**

### **3. Minimum Size Clamp (Anti-Paralysis)**

**Without clamp:**
```
0.5 × 0.5 × 0.7 × 0.25 = 0.044 lots (microscopic)
```

**With clamp:**
```cpp
if (final_size < min_trade_size) {
    final_size = min_trade_size;
}
```

**Prevents hidden paralysis from compound scaling**

### **4. Cross-Metal Exposure Check**

**Position Governor:**
```cpp
// Check combined XAU + XAG exposure
total = |xau_pos + new_xau| + |xag_pos|
return total <= max_exposure
```

**Prevents imbalanced exposure**

### **5. Directional Correlation Scaling**

**Both same direction:**
```cpp
if (xau_pos > 0 && xag_pos > 0) return 0.7  // Both long
if (xau_pos < 0 && xag_pos < 0) return 0.7  // Both short
```

**Opposite or flat:**
```cpp
return 1.0  // Normal exposure
```

═══════════════════════════════════════════════════════════════

## ✅ WHAT WAS REMOVED

### **Ghost References Eliminated:**
- ❌ GlobalRiskGovernor
- ❌ ExecBlockReason
- ❌ EngineId::CFD
- ❌ canTradeNAS100()
- ❌ NAS100/US30 logic
- ❌ Governance inside FIXSession

### **Architectural Violations Fixed:**
- ❌ FIX layer checking latency
- ❌ FIX layer checking volatility
- ❌ FIX layer checking exposure
- ❌ Duplicate risk gates
- ❌ Recursive blocking

═══════════════════════════════════════════════════════════════

## 🔄 EXECUTION FLOW

```
1. Market update received
        ↓
2. authority.updateLatency(rtt)
   authority.updateVolatility(vol)
        ↓
3. strategy.generateSignal()
        ↓
4. authority.shouldSend(id, size)  [Check hard blocks]
        ↓
5. authority.adjustSize(id, size, xau_pos, xag_pos)  [Apply scaling]
        ↓
6. if (adjusted_size < min) → adjusted_size = min  [Clamp]
        ↓
7. fix_client.submit(symbol, adjusted_size)  [Execute]
```

**NO governance checks inside FIX layer**

═══════════════════════════════════════════════════════════════

## 📊 SCALING EXAMPLE

**Input:**
- Requested size: 2.0 lots
- Latency: 8ms → scale 0.75
- Volatility: 1.5 → scale 0.7
- Correlation: both long → scale 0.7
- Min trade size: 0.01

**Calculation:**
```
2.0 × 0.75 × 0.7 × 0.7 = 0.735 lots
```

**Without clamp:** 0.735 lots (OK)

**If conditions worse:**
```
2.0 × 0.25 × 0.4 × 0.7 = 0.14 lots
```

**Still economically viable**

**Worst case without clamp:**
```
0.5 × 0.25 × 0.4 × 0.7 = 0.035 lots
```

**With clamp → 0.01 minimum (prevents microscopic sizes)**

═══════════════════════════════════════════════════════════════

## 🧪 USAGE

```cpp
#include "governance/ExecutionAuthority.hpp"
#include "governance/EngineId.hpp"

// Initialize
ExecutionAuthority authority;
authority.setMinTradeSize(0.01);

// Update market conditions
authority.updateLatency(current_rtt_ms);
authority.updateVolatility(current_atr);
authority.setPosition(EngineId::XAUUSD, xau_position);
authority.setPosition(EngineId::XAGUSD, xag_position);

// Before sending order
EngineId id = EngineId::XAUUSD;
double requested_size = 2.0;

if (!authority.shouldSend(id, requested_size)) {
    // Hard blocked (latency >50ms or vol >4.0 or position limit)
    return false;
}

double final_size = authority.adjustSize(
    id,
    requested_size,
    xau_position,
    xag_position
);

// Send order
fix_client.submit(symbol, final_size);
```

═══════════════════════════════════════════════════════════════

## ✅ ARCHITECTURAL GUARANTEES

1. ✅ **Single Source of Truth** - All decisions in ExecutionAuthority
2. ✅ **No Ghost References** - No NAS/US30/CFD anywhere
3. ✅ **No Duplicate Checks** - FIX layer is pure transport
4. ✅ **Anti-Paralysis** - Minimum size clamp prevents microscopic trades
5. ✅ **Smooth Indicators** - No oscillation thrashing
6. ✅ **Tiered Scaling** - Graceful degradation, not binary blocking
7. ✅ **Cross-Metal Aware** - Tracks combined XAU+XAG exposure
8. ✅ **Directional Correlation** - Scales based on position alignment

═══════════════════════════════════════════════════════════════

## 🚨 WHAT NOT TO DO

**DON'T:**
- ❌ Add risk checks to FIXSession
- ❌ Create second ExecutionAuthority
- ❌ Add NAS100/US30 back to EngineId
- ❌ Remove minimum size clamp
- ❌ Use instant volatility (always smooth)
- ❌ Allow position checks to bypass governance

**DO:**
- ✅ All risk decisions through ExecutionAuthority
- ✅ Keep FIX layer pure transport
- ✅ Metals only (XAU+XAG)
- ✅ Maintain minimum size clamp
- ✅ Update latency/vol continuously
- ✅ Track positions accurately

═══════════════════════════════════════════════════════════════

**Generated:** February 14, 2026  
**Architecture:** Clean Governance | Metals Only | Anti-Paralysis  
**Status:** Production-Grade
