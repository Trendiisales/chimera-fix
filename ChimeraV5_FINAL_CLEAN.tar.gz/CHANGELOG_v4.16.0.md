# Chimera v4.16.0 Changelog

## Release Date: 2026-01-09

## Summary
Added two new **Liquidity Pyramid Scalper** engines based on live EA analysis targeting $500-600/day returns. These engines focus on **position management over signal accuracy** - using tight trailing stops and pyramid entries to create small losers and compounding winners.

---

## New Engines

### 1. GoldLiquidityScalper (XAUUSD)
**File:** `include/engines/GoldLiquidityScalper.hpp`

**Strategy:**
- Detect directional bias via delta volume + price change
- Enter on bias confirmation
- Pyramid on continuation ($0.35 steps, max 6 levels)
- Tight trailing stops ($0.30)
- Hard stop at $1.20 adverse

**Parameters (LOCKED):**
```cpp
ENTRY_STEP  = 0.35    // $ between pyramids
TRAIL_STEP  = 0.30    // $ trailing stop distance  
HARD_STOP   = 1.20    // $ max adverse excursion
BASE_SIZE   = 0.01    // lots per level
MAX_PYRAMIDS = 6      // max pyramid levels
```

**Edge:**
- Losers are tiny (tight trail + hard stop)
- Winners compound (6 pyramids max)
- Most days do nothing
- Good days stack size fast

---

### 2. NASLiquidityScalper (NAS100)
**File:** `include/engines/NASLiquidityScalper.hpp`

**Strategy:**
- Long-only bias (indices trend up long-term)
- Enter on pullback from session high (3 pt trigger)
- Pyramid on continuation (6 pt steps, max 4 levels)
- Tight trailing stops (5 pts)
- Hard stop at 18 pts adverse
- NY session only (13:30-20:00 UTC)

**Parameters (LOCKED):**
```cpp
ENTRY_STEP  = 6.0     // pts between pyramids
TRAIL_STEP  = 5.0     // pts trailing stop distance
HARD_STOP   = 18.0    // pts max adverse excursion
BASE_SIZE   = 0.01    // lots per level
MAX_ADDS    = 4       // max pyramid levels
```

---

## Integration

### Files Added
- `include/engines/GoldLiquidityScalper.hpp`
- `include/engines/NASLiquidityScalper.hpp`
- `include/engines/LiquidityScalperIntegration.hpp`

### Wiring into main.cpp

**Option 1: Use Extended System (Recommended)**

Replace in main.cpp:
```cpp
// OLD
chimera::ChimeraUnifiedSystem engine;

// NEW
#include "engines/LiquidityScalperIntegration.hpp"
chimera::ChimeraExtendedSystem engine;
```

The `ChimeraExtendedSystem` includes all existing engines PLUS the new liquidity scalpers.

**Option 2: Wire Individually**

Add to existing XAUUSDSystem or call directly:
```cpp
#include "engines/GoldLiquidityScalper.hpp"
#include "engines/NASLiquidityScalper.hpp"

chimera::GoldLiquidityScalper gold_liq;
chimera::NASLiquidityScalper nas_liq;

gold_liq.setCallback([&exec_mgr](const chimera::TradeSignal& s) {
    exec_mgr.executeSignal(s);
});

// In tick handler:
gold_liq.on_tick(bid, ask, ts_ns);
nas_liq.on_tick(bid, ask, ts_ns);
```

---

## Engine Control

The extended system provides runtime toggles:

```cpp
// Disable existing XAUUSD engines, enable only liquidity scalper
engine.setXAUUSDMeanRevert(false);
engine.setXAUUSDStopFade(false);
engine.setXAUUSDAcceptance(false);
engine.setXAUUSDLiquidity(true);

// Disable Balance Expansion, enable only liquidity scalper
engine.setNAS100Balance(false);
engine.setNAS100Liquidity(true);
```

---

## Testing Recommendations

1. **Start with liquidity scalpers ONLY** (disable existing engines)
2. Run micro-size live (0.01 lots)
3. Monitor:
   - Average trade duration
   - Pyramid frequency
   - Stop tightening behavior
   - Win rate vs. profit factor
4. If profitable, consider enabling alongside existing engines

---

## Risk Notes

- These engines manage their own internal position state
- They emit TradeSignals like existing engines
- Multiple engines can fire simultaneously - ensure GlobalRiskGovernor limits are respected
- Hard stops are enforced at engine level AND execution level

---

## Unchanged from v4.15.0

- XAUUSD Mean Revert engine
- XAUUSD Stop Fade engine  
- XAUUSD Acceptance Breakout engine
- NAS100 Balance Expansion engine
- US30 Balance Expansion engine
- All risk parameters
- GUI/WebSocket server
- OpenAPI client
