# CHIMERA GOVERNANCE ARCHITECTURE

**XAU/XAG Metals-Only | Tiered Degradation | Non-Paralyzing**

═══════════════════════════════════════════════════════════════

## 🎯 DESIGN PRINCIPLE

**Protection without paralysis.**

The system uses **tiered degradation** instead of binary blocking:
- **FULL** → Normal operation (100% size)
- **DEGRADED** → Reduced size (50%)
- **DEFENSIVE** → Minimal size (25%)
- **BLOCK** → No trading (0%)

═══════════════════════════════════════════════════════════════

## 📋 GOVERNANCE LAYERS

### **1. EngineId (Metals-Only)**
```
include/core/EngineId.hpp
```

**Assets:**
- `EngineId::XAU` (XAUUSD - Gold)
- `EngineId::XAG` (XAGUSD - Silver)

**NO NAS100. NO US30. NO CFD.**

### **2. LatencyGovernor (Per-Metal)**
```
include/latency/LatencyGovernor.hpp
```

**Defaults:**
- XAU: 7ms max RTT
- XAG: 7ms max RTT

**Methods:**
- `setMaxLatencyMs(EngineId, double)`
- `updateRTT(EngineId, double)`
- `withinLatency(EngineId) -> bool`

### **3. VolatilityGovernor (ATR-Style)**
```
include/risk/VolatilityGovernor.hpp
```

**Defaults:**
- XAU: 15.0 ATR
- XAG: 0.8 ATR

**Methods:**
- `setMaxVolatility(EngineId, double)`
- `updateVolatility(EngineId, double)`
- `withinVolatility(EngineId) -> bool`

### **4. PositionGovernor (Independent Caps)**
```
include/risk/PositionGovernor.hpp
```

**Defaults:**
- XAU: 10.0 lots
- XAG: 50.0 lots

**Methods:**
- `setMaxPosition(EngineId, double)`
- `updatePosition(EngineId, double)`
- `withinLimit(EngineId) -> bool`

### **5. CorrelationGovernor (XAU/XAG)**
```
include/risk/CorrelationGovernor.hpp
```

**Scaling:**
- Correlation < 0.7:  100% size
- Correlation < 0.85: 80% size
- Correlation ≥ 0.85: 60% size

**Methods:**
- `updateCorrelation(double)`
- `exposureScale(EngineId) -> double`

### **6. RegimeStabilityGovernor (Anti-Churn)**
```
include/risk/RegimeStabilityGovernor.hpp
```

**Purpose:** Prevent mode oscillation

**Logic:** Requires 2 seconds before accepting mode change

**Methods:**
- `stableMode(EngineId, ExecutionMode) -> ExecutionMode`

### **7. ExecutionAuthority (Unified Controller)**
```
include/risk/ExecutionAuthority.hpp
```

**Main Logic:**
```cpp
ExecutionMode evaluate(EngineId id):
  - Position breach? → BLOCK
  - Latency + Vol bad? → DEFENSIVE
  - Latency OR Vol bad? → DEGRADED
  - All good? → FULL
```

**Methods:**
- `evaluate(EngineId) -> ExecutionMode`
- `adjustSize(EngineId, double) -> double`
- `shouldSend(EngineId) -> bool`

═══════════════════════════════════════════════════════════════

## 🔄 EXECUTION FLOW

```
Strategy requests trade
        ↓
ExecutionAuthority::shouldSend(id)
        ↓
    Evaluates:
      - Position limits (HARD BLOCK if exceeded)
      - Latency (degraded if high)
      - Volatility (degraded if high)
        ↓
    Returns ExecutionMode
        ↓
RegimeStabilityGovernor (prevents oscillation)
        ↓
ExecutionAuthority::adjustSize(id, base_size)
        ↓
    Applies:
      - Correlation scaling
      - Mode scaling (1.0 / 0.5 / 0.25 / 0.0)
        ↓
    Returns final_size
        ↓
FIX Session sends order
```

═══════════════════════════════════════════════════════════════

## 🎯 DEGRADATION LOGIC

### **Scenario 1: High Latency Only**
- Mode: DEGRADED
- Size: 50% * correlation_scale

### **Scenario 2: High Volatility Only**
- Mode: DEGRADED
- Size: 50% * correlation_scale

### **Scenario 3: High Latency + High Volatility**
- Mode: DEFENSIVE
- Size: 25% * correlation_scale

### **Scenario 4: Position Limit Exceeded**
- Mode: BLOCK
- Size: 0%

### **Scenario 5: High XAU/XAG Correlation**
- Correlation 0.9
- Correlation scale: 0.6
- Final size: base * 0.6 * mode_scale

═══════════════════════════════════════════════════════════════

## ✅ ADVANTAGES

### **vs Binary Blocking:**
- ❌ Binary: Latency spike → no trading
- ✅ Tiered: Latency spike → half size

### **vs No Protection:**
- ❌ No protection: Unlimited risk
- ✅ Tiered: Scaled exposure

### **vs Analysis Paralysis:**
- ❌ Paralysis: Perfect conditions required
- ✅ Tiered: Always trying to trade

═══════════════════════════════════════════════════════════════

## 🧪 USAGE EXAMPLE

```cpp
#include "risk/ExecutionAuthority.hpp"
#include "core/EngineId.hpp"

// In FIX session before sending order
EngineId id = EngineId::XAU;
double requested_size = 2.0;

// Check if should send
if (!ExecutionAuthority::instance().shouldSend(id)) {
    return false;  // Hard blocked (position limit)
}

// Get adjusted size
double final_size = ExecutionAuthority::instance().adjustSize(id, requested_size);

if (final_size <= 0.0) {
    return false;
}

// Send order with final_size
sendOrder(symbol, final_size);
```

═══════════════════════════════════════════════════════════════

## 🔧 CONFIGURATION

### **Latency Tuning:**
```cpp
LatencyGovernor::instance().setMaxLatencyMs(EngineId::XAU, 5.0);  // Stricter
```

### **Volatility Tuning:**
```cpp
VolatilityGovernor::instance().setMaxVolatility(EngineId::XAG, 1.0);  // Looser
```

### **Position Tuning:**
```cpp
PositionGovernor::instance().setMaxPosition(EngineId::XAU, 15.0);  // More capacity
```

### **Correlation Updates:**
```cpp
CorrelationGovernor::instance().updateCorrelation(0.92);  // High correlation
```

═══════════════════════════════════════════════════════════════

## 🚨 CRITICAL NOTES

1. **Metals-Only:** No NAS100/US30 in enum
2. **Per-Metal:** Each metal has independent limits
3. **Non-Paralyzing:** System always tries to trade
4. **Correlation-Aware:** Reduces exposure when XAU/XAG aligned
5. **Regime Stability:** 2-second hysteresis prevents mode churn

═══════════════════════════════════════════════════════════════

**Generated:** February 14, 2026  
**Architecture:** Tiered Degradation Governance  
**Assets:** XAU + XAG Only  
**Status:** Production-Grade Institutional
