# CHIMERA V5 - FIX PROTOCOL ONLY

**NO OPENAPI. ONLY FIX.**

## What Gets Built

**ONE executable:** `chimera_fix`
- FIX 4.4 protocol
- Integrated with full engine
- Uses CTraderFIXClient
- All governance layers available

## What's NOT Included

- ❌ NO OpenAPI code
- ❌ NO profile .cpp files compiled
- ❌ NO separate OpenAPI executable

## Build

### Windows:
```powershell
mkdir build && cd build
cmake .. -G "Visual Studio 17 2022" -A x64
cmake --build . --config Release
.\bin\Release\chimera_fix.exe
```

### Linux:
```bash
mkdir build && cd build
cmake ..
make -j4
./bin/chimera_fix
```

## What's Inside

- src/main.cpp - FIX client ONLY
- All FIX headers (9 files)
- All engine headers (191 files)
- CMakeLists.txt - Builds ONLY chimera_fix

**NO OpenAPI anywhere.**
