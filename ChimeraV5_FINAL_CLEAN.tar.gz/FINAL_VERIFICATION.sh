#!/bin/bash
echo "================================================================"
echo "CHIMERA V5 - FINAL VERIFICATION"
echo "================================================================"
echo ""

ERRORS=0

echo "[1] Architecture: Single governance layer"
echo "    Checking FIXSession is clean..."
GHOST_COUNT=$(grep -c "GlobalRiskGovernor\|ExecBlockReason\|canTradeNAS100" cfd_engine/include/fix/FIXSession.hpp 2>/dev/null || echo "0")
if [ "$GHOST_COUNT" -eq 0 ]; then
    echo "    ✅ FIXSession has NO governance logic"
else
    echo "    ❌ FIXSession has $GHOST_COUNT governance references"
    ERRORS=$((ERRORS + 1))
fi

echo ""
echo "[2] Metals-only scope"
echo "    Checking EngineId..."
XAU_COUNT=$(grep -c "XAUUSD" include/governance/EngineId.hpp 2>/dev/null || echo "0")
XAG_COUNT=$(grep -c "XAGUSD" include/governance/EngineId.hpp 2>/dev/null || echo "0")
NAS_COUNT=$(grep -c "NAS100\|US30\|CFD" include/governance/EngineId.hpp 2>/dev/null || echo "0")
if [ "$XAU_COUNT" -gt 0 ] && [ "$XAG_COUNT" -gt 0 ] && [ "$NAS_COUNT" -eq 0 ]; then
    echo "    ✅ EngineId has XAU+XAG, no NAS/US30/CFD"
else
    echo "    ❌ EngineId scope incorrect"
    ERRORS=$((ERRORS + 1))
fi

echo ""
echo "[3] Anti-paralysis protection"
echo "    Checking minimum size clamp..."
if grep -q "min_trade_size" include/governance/ExecutionAuthority.hpp 2>/dev/null; then
    echo "    ✅ Minimum size clamp present"
else
    echo "    ❌ Minimum size clamp missing"
    ERRORS=$((ERRORS + 1))
fi

echo ""
echo "[4] Tiered latency scaling"
echo "    Checking LatencyGovernor..."
if grep -q "smoothing_" include/governance/LatencyGovernor.hpp 2>/dev/null; then
    echo "    ✅ Smoothing implemented"
else
    echo "    ❌ Smoothing missing"
    ERRORS=$((ERRORS + 1))
fi

echo ""
echo "[5] Config validation"
echo "    Checking TradingConfig safety..."
if grep -q "try\|catch" include/shared/TradingConfig.hpp 2>/dev/null; then
    echo "    ✅ Exception handling present"
else
    echo "    ❌ Exception handling missing"
    ERRORS=$((ERRORS + 1))
fi

echo ""
echo "[6] Cross-metal exposure check"
echo "    Checking PositionGovernor..."
if grep -q "xau_pos_\|xag_pos_" include/governance/PositionGovernor.hpp 2>/dev/null; then
    echo "    ✅ Cross-metal tracking present"
else
    echo "    ❌ Cross-metal tracking missing"
    ERRORS=$((ERRORS + 1))
fi

echo ""
echo "[7] File structure"
REQUIRED_FILES=(
    "include/governance/EngineId.hpp"
    "include/governance/ExecutionAuthority.hpp"
    "include/governance/ExecutionMode.hpp"
    "include/governance/LatencyGovernor.hpp"
    "include/governance/VolatilityGovernor.hpp"
    "include/governance/PositionGovernor.hpp"
    "include/governance/CorrelationGovernor.hpp"
    "include/shared/TradingConfig.hpp"
    "include/platform/WindowsHardening.hpp"
    "cfd_engine/include/fix/FIXSession.hpp"
    "src/main.cpp"
    "CMakeLists.txt"
)

echo "    Checking required files..."
for f in "${REQUIRED_FILES[@]}"; do
    if [ -f "$f" ]; then
        echo "      ✅ $f"
    else
        echo "      ❌ $f MISSING"
        ERRORS=$((ERRORS + 1))
    fi
done

echo ""
echo "================================================================"
if [ "$ERRORS" -eq 0 ]; then
    echo "✅ ALL VERIFICATION PASSED"
    echo ""
    echo "System is ready for controlled metals deployment."
    echo ""
    echo "Architecture:"
    echo "  - Single governance layer (ExecutionAuthority)"
    echo "  - Clean FIX transport (no governance)"
    echo "  - Metals only (XAU + XAG)"
    echo "  - Anti-paralysis (min size clamp)"
    echo "  - Tiered scaling (smoothed indicators)"
    echo "  - Safe config parsing"
    echo ""
    echo "Build:"
    echo "  mkdir build && cd build"
    echo "  cmake .. -G \"Visual Studio 17 2022\" -A x64"
    echo "  cmake --build . --config Release"
else
    echo "❌ VERIFICATION FAILED: $ERRORS errors"
    echo ""
    echo "Fix errors before deployment."
fi
echo "================================================================"

exit $ERRORS
