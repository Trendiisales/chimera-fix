#pragma once
#include "EngineId.hpp"
#include <cmath>

namespace Chimera {

class PositionGovernor {
public:
    PositionGovernor()
        : xau_pos_(0.0)
        , xag_pos_(0.0)
        , max_exposure_(10.0)
    {}

    void setPosition(EngineId id, double pos) {
        if (id == EngineId::XAUUSD) xau_pos_ = pos;
        if (id == EngineId::XAGUSD) xag_pos_ = pos;
    }

    double getPosition(EngineId id) const {
        if (id == EngineId::XAUUSD) return xau_pos_;
        if (id == EngineId::XAGUSD) return xag_pos_;
        return 0.0;
    }

    bool withinLimit(EngineId id, double new_size) const {
        // Check cross-metal exposure
        double total = 0.0;
        if (id == EngineId::XAUUSD)
            total = std::abs(xau_pos_ + new_size) + std::abs(xag_pos_);
        else
            total = std::abs(xag_pos_ + new_size) + std::abs(xau_pos_);

        return total <= max_exposure_;
    }

    void setMaxExposure(double max) {
        max_exposure_ = max;
    }

private:
    double xau_pos_;
    double xag_pos_;
    double max_exposure_;
};

} // namespace Chimera
