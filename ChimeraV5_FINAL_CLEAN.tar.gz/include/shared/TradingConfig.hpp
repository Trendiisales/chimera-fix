#pragma once
#include <string>
#include <fstream>
#include <sstream>
#include <unordered_map>
#include <iostream>
#include <stdexcept>

namespace Chimera {

class TradingConfig {
public:
    // FIX Protocol
    std::string fix_host;
    int fix_port;
    std::string sender_comp_id;
    std::string target_comp_id;
    std::string username;
    std::string password;

    // Metals Risk Limits
    double max_xau_exposure;
    double max_xag_exposure;
    double min_trade_size;
    double max_trade_size;

    TradingConfig()
        : fix_port(5212)
        , max_xau_exposure(10.0)
        , max_xag_exposure(50.0)
        , min_trade_size(0.01)
        , max_trade_size(10.0)
    {}

    bool load(const std::string& path) {
        std::ifstream file(path);
        if (!file.is_open()) {
            std::cerr << "[TradingConfig] Cannot open " << path << "\n";
            return false;
        }

        std::unordered_map<std::string, std::string> kv;
        std::string line;

        while (std::getline(file, line)) {
            // Skip empty lines and comments
            if (line.empty() || line[0] == '#' || line[0] == ';' || line[0] == '[')
                continue;

            std::istringstream iss(line);
            std::string key, value;

            if (std::getline(iss, key, '=') && std::getline(iss, value)) {
                // Trim whitespace
                key.erase(0, key.find_first_not_of(" \t"));
                key.erase(key.find_last_not_of(" \t") + 1);
                value.erase(0, value.find_first_not_of(" \t"));
                value.erase(value.find_last_not_of(" \t") + 1);
                kv[key] = value;
            }
        }

        // Load with exception safety
        try {
            // FIX fields
            if (kv.count("host")) fix_host = kv["host"];
            if (kv.count("trade_port")) fix_port = std::stoi(kv["trade_port"]);
            if (kv.count("sender_comp_id")) sender_comp_id = kv["sender_comp_id"];
            if (kv.count("target_comp_id")) target_comp_id = kv["target_comp_id"];
            if (kv.count("username")) username = kv["username"];
            if (kv.count("password")) password = kv["password"];

            // Metals risk limits
            if (kv.count("max_xau_exposure")) max_xau_exposure = std::stod(kv["max_xau_exposure"]);
            if (kv.count("max_xag_exposure")) max_xag_exposure = std::stod(kv["max_xag_exposure"]);
            if (kv.count("min_trade_size")) min_trade_size = std::stod(kv["min_trade_size"]);
            if (kv.count("max_trade_size")) max_trade_size = std::stod(kv["max_trade_size"]);

        } catch (const std::exception& e) {
            std::cerr << "[TradingConfig] Parse error: " << e.what() << "\n";
            return false;
        }

        return isValid();
    }

    bool isValid() const {
        if (fix_host.empty()) {
            std::cerr << "[TradingConfig] Missing: fix_host\n";
            return false;
        }
        if (sender_comp_id.empty()) {
            std::cerr << "[TradingConfig] Missing: sender_comp_id\n";
            return false;
        }
        if (username.empty()) {
            std::cerr << "[TradingConfig] Missing: username\n";
            return false;
        }
        if (password.empty()) {
            std::cerr << "[TradingConfig] Missing: password\n";
            return false;
        }
        if (fix_port <= 0 || fix_port > 65535) {
            std::cerr << "[TradingConfig] Invalid: fix_port=" << fix_port << "\n";
            return false;
        }
        if (min_trade_size <= 0.0) {
            std::cerr << "[TradingConfig] Invalid: min_trade_size=" << min_trade_size << "\n";
            return false;
        }
        if (max_trade_size < min_trade_size) {
            std::cerr << "[TradingConfig] Invalid: max_trade_size < min_trade_size\n";
            return false;
        }

        return true;
    }

    void print() const {
        std::cout << "[TradingConfig - Metals Only]\n";
        std::cout << "  FIX Host:        " << fix_host << ":" << fix_port << "\n";
        std::cout << "  SenderID:        " << sender_comp_id << "\n";
        std::cout << "  TargetID:        " << target_comp_id << "\n";
        std::cout << "  Username:        " << username << "\n";
        std::cout << "  Max XAU:         " << max_xau_exposure << " lots\n";
        std::cout << "  Max XAG:         " << max_xag_exposure << " lots\n";
        std::cout << "  Min Trade Size:  " << min_trade_size << "\n";
        std::cout << "  Max Trade Size:  " << max_trade_size << "\n";
    }
};

} // namespace Chimera
