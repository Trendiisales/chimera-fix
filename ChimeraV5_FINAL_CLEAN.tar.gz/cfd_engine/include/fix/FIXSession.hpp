#pragma once

#include <string>
#include <functional>
#include <atomic>
#include "FIXConfig.hpp"
#include "FIXSSLTransport.hpp"
#include "FIXMessage.hpp"

namespace Chimera {

class FIXSession {
public:
    using OnLogonCallback  = std::function<void()>;
    using OnLogoutCallback = std::function<void()>;
    using OnMessageCallback = std::function<void(const FIXMessage&)>;

    explicit FIXSession(const FIXConfig& config)
        : config_(config),
          outSeqNum_(1),
          connected_(false) {}

    bool connect() {
        // Use tradePort from config (pricePort for quote session handled by caller)
        bool ok = transport_.connect(config_.host, config_.tradePort);
        connected_ = ok;
        return ok;
    }

    void disconnect() {
        transport_.disconnect();
        connected_ = false;
    }

    void start() {
        sendLogon();
    }

    void stop() {
        sendLogout();
    }

    void sendLogon() {
        FIXMessage msg;
        msg.setMsgType('A');  // Logon
        msg.setField(98, "0");  // EncryptMethod = None
        msg.setField(108, static_cast<int>(config_.heartbeatIntervalSec));  // HeartBtInt
        msg.setField(553, config_.username);  // Username
        msg.setField(554, config_.password);  // Password
        msg.setField(141, "Y");  // ResetSeqNumFlag
        
        std::string raw = msg.encode(config_.senderCompID, config_.targetCompID, outSeqNum_++, "");
        transport_.sendRaw(raw);
        
        if (onLogon_) {
            onLogon_();
        }
    }

    void sendLogout() {
        FIXMessage msg;
        msg.setMsgType('5');  // Logout
        
        std::string raw = msg.encode(config_.senderCompID, config_.targetCompID, outSeqNum_++, "");
        transport_.sendRaw(raw);
        
        if (onLogout_) {
            onLogout_();
        }
    }

    void sendNewOrder(const std::string& clOrdID, const std::string& symbol,
                      char side, double qty, char ordType = '1', double price = 0.0) {
        FIXMessage msg;
        msg.setMsgType('D');  // NewOrderSingle
        msg.setField(11, clOrdID);  // ClOrdID
        msg.setField(55, symbol);  // Symbol
        msg.setField(54, std::string(1, side));  // Side
        msg.setField(38, qty);  // OrderQty
        msg.setField(40, std::string(1, ordType));  // OrdType
        
        if (ordType == '2' && price > 0.0) {  // Limit order
            msg.setField(44, price);  // Price
        }
        
        msg.setField(59, "1");  // TimeInForce = GTC
        
        std::string raw = msg.encode(config_.senderCompID, config_.targetCompID, outSeqNum_++, "");
        transport_.sendRaw(raw);
    }

    void sendMarketDataRequest(const std::string& reqID, const std::string& symbol) {
        FIXMessage msg;
        msg.setMsgType('V');  // MarketDataRequest
        msg.setField(262, reqID);  // MDReqID
        msg.setField(263, "1");  // SubscriptionRequestType = Snapshot+Updates
        msg.setField(264, "1");  // MarketDepth
        msg.setField(55, symbol);  // Symbol
        
        std::string raw = msg.encode(config_.senderCompID, config_.targetCompID, outSeqNum_++, "");
        transport_.sendRaw(raw);
    }

    void sendSecurityListRequest(const std::string& reqID) {
        FIXMessage msg;
        msg.setMsgType('x');  // SecurityListRequest
        msg.setField(320, reqID);  // SecurityReqID
        msg.setField(559, "0");  // SecurityListRequestType = Symbol
        
        std::string raw = msg.encode(config_.senderCompID, config_.targetCompID, outSeqNum_++, "");
        transport_.sendRaw(raw);
    }

    void setOnLogon(OnLogonCallback cb) {
        onLogon_ = cb;
    }

    void setOnLogout(OnLogoutCallback cb) {
        onLogout_ = cb;
    }

    void setOnMessage(OnMessageCallback cb) {
        onMessage_ = cb;
    }

    bool isConnected() const {
        return connected_;
    }

    const FIXSSLTransport& getTransport() const {
        return transport_;
    }

private:
    FIXConfig config_;
    FIXSSLTransport transport_;
    std::atomic<uint32_t> outSeqNum_;
    std::atomic<bool> connected_;

    OnLogonCallback onLogon_;
    OnLogoutCallback onLogout_;
    OnMessageCallback onMessage_;
};

} // namespace Chimera
