#pragma once

#include <string>
#include <functional>
#include <atomic>

#ifdef _WIN32
#include <winsock2.h>
#include <ws2tcpip.h>
#include <windows.h>
#pragma comment(lib, "ws2_32.lib")
#else
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <unistd.h>
#define SOCKET int
#define INVALID_SOCKET (-1)
#define SOCKET_ERROR (-1)
#define closesocket close
#endif

#include <openssl/ssl.h>
#include <openssl/err.h>

namespace Chimera {

class FIXSSLTransport {
public:
    using ReceiveCallback = std::function<void(const std::string&)>;

    FIXSSLTransport()
        : socket_(INVALID_SOCKET),
          ctx_(nullptr),
          ssl_(nullptr),
          connected_(false) 
    {
#ifdef _WIN32
        WSADATA wsaData;
        WSAStartup(MAKEWORD(2,2), &wsaData);
#endif
    }

    ~FIXSSLTransport() {
        disconnect();
#ifdef _WIN32
        WSACleanup();
#endif
    }

    bool connect(const std::string& host, uint16_t port) {
        if (connected_) return true;

        socket_ = ::socket(AF_INET, SOCK_STREAM, IPPROTO_TCP);
        if (socket_ == INVALID_SOCKET)
            return false;

        sockaddr_in serverAddr{};
        serverAddr.sin_family = AF_INET;
        serverAddr.sin_port = htons(port);

        if (inet_pton(AF_INET, host.c_str(), &serverAddr.sin_addr) <= 0)
            return false;

        if (::connect(socket_, (sockaddr*)&serverAddr, sizeof(serverAddr)) == SOCKET_ERROR)
            return false;

        SSL_library_init();
        OpenSSL_add_all_algorithms();
        SSL_load_error_strings();

        ctx_ = SSL_CTX_new(TLS_client_method());
        if (!ctx_) return false;

        ssl_ = SSL_new(ctx_);
#ifdef _WIN32
        SSL_set_fd(ssl_, (int)socket_);
#else
        SSL_set_fd(ssl_, socket_);
#endif

        if (SSL_connect(ssl_) <= 0)
            return false;

        connected_ = true;
        return true;
    }

    void disconnect() {
        if (!connected_) return;

        if (ssl_) {
            SSL_shutdown(ssl_);
            SSL_free(ssl_);
            ssl_ = nullptr;
        }

        if (ctx_) {
            SSL_CTX_free(ctx_);
            ctx_ = nullptr;
        }

        if (socket_ != INVALID_SOCKET) {
            closesocket(socket_);
            socket_ = INVALID_SOCKET;
        }

        connected_ = false;
    }

    bool sendRaw(const std::string& data) {
        if (!connected_) return false;

        int sent = SSL_write(ssl_, data.c_str(), (int)data.size());
        return sent == (int)data.size();
    }

    void setReceiveCallback(ReceiveCallback cb) {
        receiveCallback_ = cb;
    }

    bool isConnected() const {
        return connected_;
    }

private:
    SOCKET socket_;
    SSL_CTX* ctx_;
    SSL* ssl_;
    std::atomic<bool> connected_;
    ReceiveCallback receiveCallback_;
};

} // namespace Chimera
