#pragma once

#ifdef _WIN32
#include "../../include/platform/WindowsHardening.hpp"
#endif

#include <string>
#include <thread>
#include <atomic>
#include <functional>
#include <mutex>
#include <queue>
#include <condition_variable>
#include <chrono>
#include <cstring>
#include <iostream>

// Platform-specific includes
#ifdef _WIN32
    #include <winsock2.h>
    #include <ws2tcpip.h>
    #pragma comment(lib, "ws2_32.lib")
    #pragma comment(lib, "crypt32.lib")
    typedef int socklen_t;
    #define SOCKET_ERROR_CODE WSAGetLastError()
    #define CLOSE_SOCKET(s) closesocket(s)
    #define INVALID_SOCKET_VAL INVALID_SOCKET
#else
    #include <sys/socket.h>
    #include <netinet/in.h>
    #include <netinet/tcp.h>
    #include <arpa/inet.h>
    #include <unistd.h>
    #include <netdb.h>
    #include <fcntl.h>
    #include <errno.h>
    #define SOCKET int
    #define SOCKET_ERROR_CODE errno
    #define CLOSE_SOCKET(s) ::close(s)
    #define INVALID_SOCKET_VAL (-1)
#endif

#include <openssl/ssl.h>
#include <openssl/err.h>

namespace Chimera {

// Callback for received data
using FIXRxCallback = std::function<void(const std::string&)>;

class FIXSSLTransport {
public:
    FIXSSLTransport()
        : sock_(INVALID_SOCKET_VAL)
        , sslCtx_(nullptr)
        , ssl_(nullptr)
        , connected_(false)
        , running_(false)
    {
        initSSL();
    }
    
    ~FIXSSLTransport() {
        disconnect();
        cleanupSSL();
    }
    
    // Connect to host:port with SSL
    bool connect(const std::string& host, int port) {
        if (connected_.load()) {
            return true;
        }
        
        // Create socket
        sock_ = ::socket(AF_INET, SOCK_STREAM, IPPROTO_TCP);
        if (sock_ == INVALID_SOCKET_VAL) {
            std::cerr << "[FIXTransport] Socket creation failed\n";
            return false;
        }
        
        // Resolve hostname
        struct addrinfo hints{}, *result = nullptr;
        hints.ai_family = AF_INET;
        hints.ai_socktype = SOCK_STREAM;
        
        std::string portStr = std::to_string(port);
        if (getaddrinfo(host.c_str(), portStr.c_str(), &hints, &result) != 0) {
            std::cerr << "[FIXTransport] DNS resolution failed\n";
            CLOSE_SOCKET(sock_);
            return false;
        }
        
        // Connect
        if (::connect(sock_, result->ai_addr, static_cast<socklen_t>(result->ai_addrlen)) < 0) {
            std::cerr << "[FIXTransport] Connection failed\n";
            freeaddrinfo(result);
            CLOSE_SOCKET(sock_);
            return false;
        }
        
        freeaddrinfo(result);
        
        // Setup SSL
        ssl_ = SSL_new(sslCtx_);
        SSL_set_fd(ssl_, static_cast<int>(sock_));
        
        if (SSL_connect(ssl_) <= 0) {
            std::cerr << "[FIXTransport] SSL handshake failed\n";
            SSL_free(ssl_);
            ssl_ = nullptr;
            CLOSE_SOCKET(sock_);
            return false;
        }
        
        connected_.store(true);
        return true;
    }
    
    void disconnect() {
        if (!connected_.load()) {
            return;
        }
        
        connected_.store(false);
        
        if (ssl_) {
            SSL_shutdown(ssl_);
            SSL_free(ssl_);
            ssl_ = nullptr;
        }
        
        if (sock_ != INVALID_SOCKET_VAL) {
            CLOSE_SOCKET(sock_);
            sock_ = INVALID_SOCKET_VAL;
        }
    }
    
    bool sendRaw(const std::string& data) {
        if (!connected_.load()) {
            return false;
        }
        
        int sent = SSL_write(ssl_, data.c_str(), static_cast<int>(data.size()));
        return sent == static_cast<int>(data.size());
    }
    
    void setReceiveCallback(FIXRxCallback cb) {
        rxCallback_ = std::move(cb);
    }
    
    bool isConnected() const {
        return connected_.load();
    }
    
private:
    void initSSL() {
        SSL_library_init();
        OpenSSL_add_all_algorithms();
        SSL_load_error_strings();
        
        sslCtx_ = SSL_CTX_new(TLS_client_method());
        if (!sslCtx_) {
            std::cerr << "[FIXTransport] SSL context creation failed\n";
        }
    }
    
    void cleanupSSL() {
        if (sslCtx_) {
            SSL_CTX_free(sslCtx_);
            sslCtx_ = nullptr;
        }
    }
    
    SOCKET sock_;
    SSL_CTX* sslCtx_;
    SSL* ssl_;
    std::atomic<bool> connected_;
    std::atomic<bool> running_;
    FIXRxCallback rxCallback_;
};

} // namespace Chimera
