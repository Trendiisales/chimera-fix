#pragma once

#include <string>
#include <functional>
#include <atomic>
#include <thread>
#include <chrono>
#include <mutex>
#include "FIXConfig.hpp"
#include "FIXSSLTransport.hpp"
#include "FIXMessage.hpp"

namespace Chimera {

// Callback types
using FIXLogonCallback = std::function<void()>;
using FIXLogoutCallback = std::function<void(const std::string&)>;
using FIXMessageCallback = std::function<void(const FIXMessage&)>;

enum class FIXSessionState {
    DISCONNECTED,
    CONNECTED,
    LOGGED_ON,
    LOGGING_OUT
};

class FIXSession {
public:
    // Constructor takes session name (for dual session support)
    explicit FIXSession(const std::string& sessionName)
        : sessionName_(sessionName)
        , state_(FIXSessionState::DISCONNECTED)
        , outSeqNum_(1)
        , inSeqNum_(1)
    {}
    
    ~FIXSession() {
        stop();
    }
    
    // Configuration
    void setConfig(const FIXConfig& cfg) {
        config_ = cfg;
    }
    
    void setSenderSubID(const std::string& subID) {
        senderSubID_ = subID;
    }
    
    // Callbacks
    void setOnLogon(FIXLogonCallback cb) {
        onLogon_ = std::move(cb);
    }
    
    void setOnLogout(FIXLogoutCallback cb) {
        onLogout_ = std::move(cb);
    }
    
    void setOnMessage(FIXMessageCallback cb) {
        onMessage_ = std::move(cb);
    }
    
    // Intent flags (for governance - stored but not enforced here)
    void setIntentLive(bool live) noexcept {
        intentLive_.store(live);
    }
    
    bool isIntentLive() const noexcept {
        return intentLive_.load();
    }
    
    void setNYExpansion(bool active) noexcept {
        nyExpansion_.store(active);
    }
    
    bool isNYExpansion() const noexcept {
        return nyExpansion_.load();
    }
    
    // Connection - takes host and port as specified in audit
    bool start(const std::string& host, int port) {
        if (state_.load() != FIXSessionState::DISCONNECTED) {
            return false;
        }
        
        if (!transport_.connect(host, port)) {
            return false;
        }
        
        state_.store(FIXSessionState::CONNECTED);
        
        // Send logon
        sendLogon();
        
        return true;
    }
    
    void stop() {
        if (state_.load() == FIXSessionState::DISCONNECTED) {
            return;
        }
        
        sendLogout("");
        transport_.disconnect();
        state_.store(FIXSessionState::DISCONNECTED);
    }
    
    bool isConnected() const {
        return state_.load() == FIXSessionState::LOGGED_ON;
    }
    
    // RTT tracking (simplified - no atomic double issues)
    double rttLastMs() const noexcept {
        return rttLast_.load();
    }
    
    double rttMinMs() const noexcept {
        return rttMin_.load();
    }
    
    double rttMaxMs() const noexcept {
        return rttMax_.load();
    }
    
    double rttAvgMs() const noexcept {
        uint64_t count = rttCount_.load();
        if (count == 0) return 0.0;
        // Unscale from microseconds
        return (rttSumScaled_.load() / 1000.0) / count;
    }
    
    uint64_t rttSamples() const noexcept {
        return rttCount_.load();
    }
    
    // Message sending helpers
    bool sendNewOrder(const std::string& clOrdID, const std::string& symbol,
                      char side, double qty, char ordType = '1', double price = 0.0) {
        FIXMessage msg;
        msg.setMsgType('D');  // NewOrderSingle
        msg.setField(11, clOrdID);  // ClOrdID
        msg.setField(55, symbol);
        msg.setField(54, std::string(1, side));
        msg.setField(38, qty);
        msg.setField(40, std::string(1, ordType));
        
        if (ordType == '2' && price > 0.0) {  // Limit
            msg.setField(44, price);
        }
        
        msg.setField(59, "1");  // TimeInForce = Day
        msg.setSendingTime();
        
        return sendMessage(msg);
    }
    
    bool sendMarketDataRequest(const std::string& reqID, char subscriptionType,
                                int depth, const std::vector<std::string>& symbols) {
        FIXMessage msg;
        msg.setMsgType('V');  // MarketDataRequest
        msg.setField(262, reqID);
        msg.setField(263, std::string(1, subscriptionType));
        msg.setField(264, depth);
        
        // Entry types: Bid and Offer
        msg.setField(267, "2");  // NoMDEntryTypes
        
        // Symbols
        msg.setField(146, static_cast<int>(symbols.size()));
        for (const auto& sym : symbols) {
            msg.setField(55, sym);
        }
        
        return sendMessage(msg);
    }
    
    bool sendSecurityListRequest(const std::string& reqID) {
        FIXMessage msg;
        msg.setMsgType('x');  // SecurityListRequest
        msg.setField(320, reqID);
        msg.setField(559, "0");  // All securities
        
        return sendMessage(msg);
    }
    
    // Transport access
    const FIXSSLTransport& getTransport() const {
        return transport_;
    }
    
private:
    void sendLogon() {
        FIXMessage msg;
        msg.setMsgType('A');
        msg.setField(98, "0");  // EncryptMethod = None
        msg.setField(108, config_.heartbeatIntervalSec);
        msg.setField(553, config_.username);
        msg.setField(554, config_.password);
        msg.setField(141, "Y");  // ResetSeqNumFlag
        
        sendMessage(msg);
        
        state_.store(FIXSessionState::LOGGED_ON);
        if (onLogon_) {
            onLogon_();
        }
    }
    
    void sendLogout(const std::string& text) {
        FIXMessage msg;
        msg.setMsgType('5');
        if (!text.empty()) {
            msg.setField(58, text);
        }
        
        sendMessage(msg);
        state_.store(FIXSessionState::LOGGING_OUT);
    }
    
    bool sendMessage(FIXMessage& msg) {
        msg.setField(34, static_cast<int>(outSeqNum_));
        msg.setSendingTime();
        
        std::string raw = msg.encode(config_.senderCompID, config_.targetCompID,
                                       outSeqNum_, senderSubID_);
        
        outSeqNum_++;
        
        return transport_.sendRaw(raw);
    }
    
    void updateRTT(double rtt_ms) {
        rttLast_.store(rtt_ms);
        
        double min = rttMin_.load();
        if (rtt_ms < min || min == 0.0) {
            rttMin_.store(rtt_ms);
        }
        
        double max = rttMax_.load();
        if (rtt_ms > max) {
            rttMax_.store(rtt_ms);
        }
        
        // Scale to avoid atomic double issue
        uint64_t scaled = static_cast<uint64_t>(rtt_ms * 1000.0);
        uint64_t oldSum = rttSumScaled_.load();
        rttSumScaled_.store(oldSum + scaled);
        
        rttCount_.fetch_add(1);
    }
    
    std::string sessionName_;
    FIXConfig config_;
    std::string senderSubID_;
    FIXSSLTransport transport_;
    
    std::atomic<FIXSessionState> state_;
    std::atomic<uint32_t> outSeqNum_;
    std::atomic<uint32_t> inSeqNum_;
    
    std::atomic<bool> intentLive_{false};
    std::atomic<bool> nyExpansion_{false};
    
    // RTT tracking - using int64 to avoid atomic double
    std::atomic<double> rttLast_{0.0};
    std::atomic<double> rttMin_{0.0};
    std::atomic<double> rttMax_{0.0};
    std::atomic<uint64_t> rttSumScaled_{0};  // Scaled by 1000
    std::atomic<uint64_t> rttCount_{0};
    
    FIXLogonCallback onLogon_;
    FIXLogoutCallback onLogout_;
    FIXMessageCallback onMessage_;
};

} // namespace Chimera
