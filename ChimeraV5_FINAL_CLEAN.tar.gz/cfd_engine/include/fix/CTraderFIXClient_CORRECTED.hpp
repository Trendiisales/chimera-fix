#pragma once

#include <string>
#include <functional>
#include <atomic>
#include <mutex>
#include "FIXConfig.hpp"
#include "FIXSession.hpp"
#include "FIXMessage.hpp"

namespace Chimera {

// Tick data structure
struct CTraderTick {
    std::string symbol;
    double bid;
    double ask;
    double bidSize;
    double askSize;
    uint64_t timestamp;
};

// Execution report structure
struct CTraderExecReport {
    std::string symbol;
    std::string clOrdID;
    std::string orderID;
    char execType;
    char ordStatus;
    char side;
    double cumQty;
    double avgPx;
    std::string text;
};

// Callback types
using CTraderTickCallback = std::function<void(const CTraderTick&)>;
using CTraderExecCallback = std::function<void(const CTraderExecReport&)>;
using CTraderStateCallback = std::function<void(bool quoteConnected, bool tradeConnected)>;

class CTraderFIXClient {
public:
    CTraderFIXClient()
        : quoteSession_("QUOTE")
        , tradeSession_("TRADE")
        , quoteConnected_(false)
        , tradeConnected_(false)
    {}
    
    ~CTraderFIXClient() {
        disconnect();
    }
    
    // Configuration
    void setConfig(const FIXConfig& cfg) {
        config_ = cfg;
        
        // Configure both sessions
        quoteSession_.setConfig(cfg);
        quoteSession_.setSenderSubID(cfg.senderSubID_Quote);
        
        tradeSession_.setConfig(cfg);
        tradeSession_.setSenderSubID(cfg.senderSubID_Trade);
    }
    
    // Callbacks
    void setOnTick(CTraderTickCallback cb) {
        onTick_ = std::move(cb);
    }
    
    void setOnExec(CTraderExecCallback cb) {
        onExec_ = std::move(cb);
    }
    
    void setOnState(CTraderStateCallback cb) {
        onState_ = std::move(cb);
    }
    
    // Intent state
    void setIntentLive(bool live) noexcept {
        tradeSession_.setIntentLive(live);
    }
    
    bool isIntentLive() const noexcept {
        return tradeSession_.isIntentLive();
    }
    
    void setNYExpansion(bool active) noexcept {
        tradeSession_.setNYExpansion(active);
    }
    
    // Connection - TRADE first, then QUOTE (cTrader requirement)
    bool connect() {
        std::cout << "[CTraderFIX] Connecting to cTrader FIX\n";
        std::cout << "[CTraderFIX] Host: " << config_.host << "\n";
        std::cout << "[CTraderFIX] TRADE port: " << config_.tradePort << "\n";
        std::cout << "[CTraderFIX] QUOTE port: " << config_.pricePort << "\n";
        
        // Setup callbacks
        tradeSession_.setOnLogon([this]() {
            std::cout << "[CTraderFIX] TRADE session logged on\n";
            tradeConnected_.store(true);
            notifyState();
        });
        
        tradeSession_.setOnLogout([this](const std::string& reason) {
            std::cout << "[CTraderFIX] TRADE session logged out: " << reason << "\n";
            tradeConnected_.store(false);
            // Force QUOTE down if TRADE drops
            if (quoteConnected_.load()) {
                quoteSession_.stop();
                quoteConnected_.store(false);
            }
            notifyState();
        });
        
        quoteSession_.setOnLogon([this]() {
            std::cout << "[CTraderFIX] QUOTE session logged on\n";
            quoteConnected_.store(true);
            notifyState();
        });
        
        quoteSession_.setOnLogout([this](const std::string& reason) {
            std::cout << "[CTraderFIX] QUOTE session logged out: " << reason << "\n";
            quoteConnected_.store(false);
            notifyState();
        });
        
        // STEP 1: Connect TRADE session first (required by cTrader)
        std::cout << "[CTraderFIX] Connecting TRADE session...\n";
        if (!tradeSession_.start(config_.host, config_.tradePort)) {
            std::cerr << "[CTraderFIX] TRADE connection failed\n";
            return false;
        }
        
        // Wait for TRADE logon
        std::this_thread::sleep_for(std::chrono::seconds(2));
        
        if (!tradeConnected_.load()) {
            std::cerr << "[CTraderFIX] TRADE logon timeout\n";
            return false;
        }
        
        // STEP 2: Connect QUOTE session (subordinate)
        std::cout << "[CTraderFIX] Connecting QUOTE session...\n";
        if (!quoteSession_.start(config_.host, config_.pricePort)) {
            std::cerr << "[CTraderFIX] QUOTE connection failed\n";
            tradeSession_.stop();
            return false;
        }
        
        // Wait for QUOTE logon
        std::this_thread::sleep_for(std::chrono::seconds(2));
        
        std::cout << "[CTraderFIX] Connection complete\n";
        return true;
    }
    
    void disconnect() {
        std::cout << "[CTraderFIX] Disconnecting...\n";
        quoteSession_.stop();
        tradeSession_.stop();
        quoteConnected_.store(false);
        tradeConnected_.store(false);
    }
    
    bool isConnected() const {
        return tradeConnected_.load() && quoteConnected_.load();
    }
    
    // Order submission
    bool submitOrder(const std::string& clOrdID, const std::string& symbol,
                     char side, double qty, char ordType = '1', double price = 0.0) {
        if (!tradeConnected_.load()) {
            return false;
        }
        
        return tradeSession_.sendNewOrder(clOrdID, symbol, side, qty, ordType, price);
    }
    
    // Market data subscription
    bool subscribeMarketData(const std::vector<std::string>& symbols) {
        if (!quoteConnected_.load()) {
            return false;
        }
        
        std::string reqID = "MD_" + std::to_string(std::chrono::system_clock::now().time_since_epoch().count());
        return quoteSession_.sendMarketDataRequest(reqID, '1', 1, symbols);
    }
    
    // Security list request
    bool requestSecurityList() {
        if (!tradeConnected_.load()) {
            return false;
        }
        
        std::string reqID = "SEC_" + std::to_string(std::chrono::system_clock::now().time_since_epoch().count());
        return tradeSession_.sendSecurityListRequest(reqID);
    }
    
private:
    void notifyState() {
        if (onState_) {
            onState_(quoteConnected_.load(), tradeConnected_.load());
        }
    }
    
    FIXConfig config_;
    
    FIXSession quoteSession_;
    FIXSession tradeSession_;
    
    std::atomic<bool> quoteConnected_;
    std::atomic<bool> tradeConnected_;
    
    CTraderTickCallback onTick_;
    CTraderExecCallback onExec_;
    CTraderStateCallback onState_;
};

} // namespace Chimera
