#pragma once

#include "FIXSession.hpp"
#include "FIXConfig.hpp"
#include <memory>
#include <atomic>

namespace Chimera {

class CTraderFIXClient {
public:
    explicit CTraderFIXClient(const FIXConfig& config)
        : config_(config),
          priceConnected_(false),
          tradeConnected_(false)
    {
        // Create price session config
        FIXConfig priceConfig = config;
        priceConfig.senderCompID = config.senderCompID;
        priceConfig.senderSubID_Quote = "QUOTE";
        
        // Create trade session config  
        FIXConfig tradeConfig = config;
        tradeConfig.senderCompID = config.senderCompID;
        tradeConfig.senderSubID_Trade = "TRADE";
        
        priceSession_ = std::make_unique<FIXSession>(priceConfig);
        tradeSession_ = std::make_unique<FIXSession>(tradeConfig);
        
        // Setup callbacks
        priceSession_->setOnLogon([this]() {
            priceConnected_.store(true);
        });
        
        priceSession_->setOnLogout([this]() {
            priceConnected_.store(false);
        });
        
        tradeSession_->setOnLogon([this]() {
            tradeConnected_.store(true);
        });
        
        tradeSession_->setOnLogout([this]() {
            tradeConnected_.store(false);
        });
    }

    bool connect() {
        // Connect TRADE session first (cTrader requirement)
        if (!tradeSession_->connect())
            return false;

        // Then connect PRICE session
        if (!priceSession_->connect())
            return false;

        return true;
    }

    void disconnect() {
        if (priceSession_) {
            priceSession_->disconnect();
        }
        if (tradeSession_) {
            tradeSession_->disconnect();
        }
    }

    void start() {
        if (tradeSession_) {
            tradeSession_->start();
        }
        if (priceSession_) {
            priceSession_->start();
        }
    }

    void stop() {
        if (priceSession_) {
            priceSession_->stop();
        }
        if (tradeSession_) {
            tradeSession_->stop();
        }
    }

    void poll() {
        // Heartbeat/polling logic if needed
    }

    bool isConnected() const {
        return priceConnected_.load() && tradeConnected_.load();
    }

    // Order submission
    void submitOrder(const std::string& clOrdID, const std::string& symbol,
                     char side, double qty, char ordType = '1', double price = 0.0) {
        if (tradeSession_ && tradeConnected_.load()) {
            tradeSession_->sendNewOrder(clOrdID, symbol, side, qty, ordType, price);
        }
    }

    // Market data subscription
    void subscribeMarketData(const std::string& symbol) {
        if (priceSession_ && priceConnected_.load()) {
            std::string reqID = "MD_" + symbol;
            priceSession_->sendMarketDataRequest(reqID, symbol);
        }
    }

    // Security list
    void requestSecurityList() {
        if (tradeSession_ && tradeConnected_.load()) {
            std::string reqID = "SECLIST";
            tradeSession_->sendSecurityListRequest(reqID);
        }
    }

private:
    FIXConfig config_;
    std::unique_ptr<FIXSession> priceSession_;
    std::unique_ptr<FIXSession> tradeSession_;
    std::atomic<bool> priceConnected_;
    std::atomic<bool> tradeConnected_;
};

} // namespace Chimera
