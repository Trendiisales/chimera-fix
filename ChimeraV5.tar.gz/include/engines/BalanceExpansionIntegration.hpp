// =============================================================================
// BalanceExpansionIntegration.hpp - Chimera v4.15.0
// =============================================================================
// BALANCE → EXPANSION ENGINE
// Validated: +5,016 pts over 18 months (NAS100 + US30)
//   - NAS100: 86 trades, 46.5% WR, +1,583 pts
//   - US30:   297 trades, 41.4% WR, +3,433 pts
//
// THESIS: Narrow OR = compression. Expansion = the trade. Trade WITH the break.
//
// DO NOT MODIFY PARAMETERS WITHOUT RE-VALIDATION
// =============================================================================
#pragma once

#include <string>
#include <vector>
#include <deque>
#include <cstdint>
#include <cmath>
#include <ctime>
#include <cstdio>
#include <functional>
#include <atomic>
#include <chrono>
#include <algorithm>

namespace balance_expansion {

// =============================================================================
// DIRECTION ENUM
// =============================================================================

enum class Direction {
    NONE = 0,
    LONG = 1,
    SHORT = -1
};

inline const char* directionStr(Direction d) {
    switch (d) {
        case Direction::LONG:  return "LONG";
        case Direction::SHORT: return "SHORT";
        default:               return "NONE";
    }
}

// =============================================================================
// TIMESTAMP HELPERS
// =============================================================================

struct Timestamp {
    int64_t epoch_ms = 0;  // Unix milliseconds UTC

    Timestamp() = default;
    explicit Timestamp(int64_t ms) : epoch_ms(ms) {}

    int minuteOfDay() const {
        time_t secs = epoch_ms / 1000;
        struct tm* t = gmtime(&secs);
        if (!t) return 0;
        return t->tm_hour * 60 + t->tm_min;
    }

    int dateInt() const {
        time_t secs = epoch_ms / 1000;
        struct tm* t = gmtime(&secs);
        if (!t) return 0;
        return (t->tm_year + 1900) * 10000 + (t->tm_mon + 1) * 100 + t->tm_mday;
    }

    int hour() const {
        time_t secs = epoch_ms / 1000;
        struct tm* t = gmtime(&secs);
        return t ? t->tm_hour : 0;
    }

    bool operator<(const Timestamp& o) const { return epoch_ms < o.epoch_ms; }
    bool operator==(const Timestamp& o) const { return epoch_ms == o.epoch_ms; }
};

inline int64_t now_ms_utc() {
    auto now = std::chrono::system_clock::now();
    return std::chrono::duration_cast<std::chrono::milliseconds>(
        now.time_since_epoch()).count();
}

// =============================================================================
// BAR STRUCTURE
// =============================================================================

struct Bar {
    std::string symbol;
    Timestamp timestamp;
    double open = 0.0;
    double high = 0.0;
    double low = 0.0;
    double close = 0.0;
    int64_t volume = 0;

    Bar() = default;

    Bar(const std::string& sym, const Timestamp& ts,
        double o, double h, double l, double c, int64_t vol = 0)
        : symbol(sym), timestamp(ts), open(o), high(h), low(l), close(c), volume(vol) {}

    double range() const { return high - low; }
    double midpoint() const { return (high + low) / 2.0; }
    bool isBullish() const { return close > open; }
    bool isBearish() const { return close < open; }
};

// =============================================================================
// M1 BAR AGGREGATOR (from ticks)
// =============================================================================

class M1BarAggregator {
public:
    explicit M1BarAggregator(const std::string& symbol)
        : symbol_(symbol) {}

    using BarCallback = std::function<void(const Bar&)>;

    void setCallback(BarCallback cb) { callback_ = cb; }

    void onTick(double price, int64_t ts_ms) {
        Timestamp ts(ts_ms);
        int current_minute = ts.minuteOfDay();
        int current_day = ts.dateInt();

        // New day - reset
        if (current_day != current_day_) {
            if (bar_open_ > 0 && callback_) {
                emitBar(ts);
            }
            reset();
            current_day_ = current_day;
        }

        // New minute - emit previous bar, start new
        if (current_minute != current_minute_) {
            if (bar_open_ > 0 && callback_) {
                // Create timestamp for the completed minute
                Timestamp bar_ts(ts_ms - 60000);  // Previous minute
                emitBar(bar_ts);
            }

            // Start new bar
            current_minute_ = current_minute;
            bar_open_ = price;
            bar_high_ = price;
            bar_low_ = price;
            bar_close_ = price;
            bar_volume_ = 1;
            return;
        }

        // Same minute - update OHLC
        bar_high_ = std::max(bar_high_, price);
        bar_low_ = std::min(bar_low_, price);
        bar_close_ = price;
        bar_volume_++;
    }

    void reset() {
        current_minute_ = -1;
        current_day_ = 0;
        bar_open_ = bar_high_ = bar_low_ = bar_close_ = 0.0;
        bar_volume_ = 0;
    }

private:
    std::string symbol_;
    BarCallback callback_;

    int current_minute_ = -1;
    int current_day_ = 0;
    double bar_open_ = 0.0;
    double bar_high_ = 0.0;
    double bar_low_ = 0.0;
    double bar_close_ = 0.0;
    int64_t bar_volume_ = 0;

    void emitBar(const Timestamp& ts) {
        if (bar_open_ <= 0) return;

        Bar bar(symbol_, ts, bar_open_, bar_high_, bar_low_, bar_close_, bar_volume_);
        if (callback_) {
            callback_(bar);
        }
    }
};

// =============================================================================
// TRADE INTENT
// =============================================================================

enum class TradeReason {
    NONE = 0,
    BALANCE_EXPANSION = 1
};

inline const char* tradeReasonStr(TradeReason r) {
    return (r == TradeReason::BALANCE_EXPANSION) ? "BALANCE_EXPANSION" : "NONE";
}

struct TradeIntent {
    std::string symbol;
    Direction direction = Direction::NONE;
    double entry_price = 0.0;
    double stop_price = 0.0;
    double tp_price = 0.0;
    TradeReason reason = TradeReason::NONE;
    Timestamp generated_at;

    double riskPoints() const {
        if (direction == Direction::LONG)
            return entry_price - stop_price;
        else if (direction == Direction::SHORT)
            return stop_price - entry_price;
        return 0.0;
    }

    double rewardPoints() const {
        if (direction == Direction::LONG)
            return tp_price - entry_price;
        else if (direction == Direction::SHORT)
            return entry_price - tp_price;
        return 0.0;
    }

    bool isValid() const {
        return direction != Direction::NONE &&
               entry_price > 0 &&
               stop_price > 0 &&
               tp_price > 0 &&
               riskPoints() > 0;
    }
};

// =============================================================================
// BALANCE EXPANSION ENGINE
// =============================================================================

class BalanceExpansionEngine {
public:
    explicit BalanceExpansionEngine(const std::string& symbol)
        : symbol_(symbol) {
        recent_bars_.reserve(256);
        or_max_ = (symbol == "NAS100") ? NAS_OR_MAX : US_OR_MAX;
    }

    void onNewDay(const Timestamp& /* ts */) {
        state_ = State{};
        recent_bars_.clear();
        intent_ready_ = false;
        pending_intent_ = TradeIntent{};
        last_impulse_ok_ = false;
    }

    void onBar(const Bar& bar) {
        recent_bars_.push_back(bar);

        const int minute = bar.timestamp.minuteOfDay();

        buildOpeningRange(bar);
        checkORCompletion(bar);

        if (!state_.or_complete) return;
        if (!state_.balance_valid) return;
        if (state_.traded_today) return;
        if (minute > NY_OPEN_MIN + TRADE_WINDOW_MIN) return;

        detectExpansion(bar, recent_bars_.size() - 1);
    }

    bool hasTradeIntent() const { return intent_ready_; }

    TradeIntent consumeTradeIntent() {
        intent_ready_ = false;
        return pending_intent_;
    }

    struct Telemetry {
        std::string symbol;
        bool or_complete = false;
        bool balance_valid = false;
        bool traded_today = false;
        double or_high = 0.0;
        double or_low = 0.0;
        double or_range = 0.0;
        Direction expansion_dir = Direction::NONE;
        bool impulse_ok = false;
        bool intent_fired = false;
        Timestamp ts;
    };

    Telemetry getTelemetry() const {
        Telemetry t;
        t.symbol = symbol_;
        t.or_complete = state_.or_complete;
        t.balance_valid = state_.balance_valid;
        t.traded_today = state_.traded_today;
        t.or_high = state_.or_high;
        t.or_low = state_.or_low;
        t.or_range = state_.or_range;
        t.expansion_dir = state_.expansion_dir;
        t.impulse_ok = last_impulse_ok_;
        t.intent_fired = state_.traded_today;
        if (!recent_bars_.empty()) {
            t.ts = recent_bars_.back().timestamp;
        }
        return t;
    }

private:
    struct State {
        bool or_complete = false;
        bool balance_valid = false;
        bool traded_today = false;
        double or_high = 0.0;
        double or_low = 0.0;
        double or_range = 0.0;
        Direction expansion_dir = Direction::NONE;
        Timestamp or_complete_time;
    };

    std::string symbol_;
    State state_;
    std::vector<Bar> recent_bars_;
    bool intent_ready_ = false;
    TradeIntent pending_intent_;
    mutable bool last_impulse_ok_ = false;
    double or_max_;

    // =========================================================================
    // CONFIG — LOCKED FROM BACKTEST — DO NOT OPTIMISE
    // =========================================================================
    static constexpr int NY_OPEN_MIN = 14 * 60 + 30;   // 14:30 UTC = 09:30 NY
    static constexpr int OR_WINDOW_MIN = 15;           // 15-minute Opening Range
    static constexpr int TRADE_WINDOW_MIN = 90;        // Trade within 90 min of NY open
    static constexpr int MAX_TRADES_PER_DAY = 1;

    static constexpr int IMPULSE_LOOKBACK = 10;
    static constexpr double IMPULSE_MULT = 1.5;

    static constexpr double ENTRY_BUFFER = 5.0;        // 5 points beyond OR
    static constexpr double R_MULT = 1.5;              // TP = 1.5R

    static constexpr double NAS_OR_MAX = 120.0;        // NAS100 OR ≤ 120 pts
    static constexpr double US_OR_MAX = 200.0;         // US30 OR ≤ 200 pts

    void buildOpeningRange(const Bar& bar) {
        const int minute = bar.timestamp.minuteOfDay();

        if (minute < NY_OPEN_MIN || minute >= NY_OPEN_MIN + OR_WINDOW_MIN)
            return;

        if (state_.or_high == 0.0 && state_.or_low == 0.0) {
            state_.or_high = bar.high;
            state_.or_low = bar.low;
        } else {
            state_.or_high = std::max(state_.or_high, bar.high);
            state_.or_low = std::min(state_.or_low, bar.low);
        }
    }

    void checkORCompletion(const Bar& bar) {
        const int minute = bar.timestamp.minuteOfDay();

        if (state_.or_complete) return;
        if (state_.or_high == 0.0) return;

        if (minute >= NY_OPEN_MIN + OR_WINDOW_MIN) {
            state_.or_complete = true;
            state_.or_complete_time = bar.timestamp;
            state_.or_range = state_.or_high - state_.or_low;
            state_.balance_valid = state_.or_range <= or_max_;

            std::printf("[%s][OR] range=%.1f valid=%s high=%.2f low=%.2f\n",
                   symbol_.c_str(),
                   state_.or_range,
                   state_.balance_valid ? "YES" : "NO",
                   state_.or_high, state_.or_low);
        }
    }

    void detectExpansion(const Bar& bar, std::size_t index) {
        if (index < IMPULSE_LOOKBACK) return;

        if (!impulseConfirmed(index)) return;

        if (state_.expansion_dir == Direction::NONE) {
            if (bar.close > state_.or_high + ENTRY_BUFFER) {
                state_.expansion_dir = Direction::LONG;
            } else if (bar.close < state_.or_low - ENTRY_BUFFER) {
                state_.expansion_dir = Direction::SHORT;
            } else {
                return;
            }
        }

        const double entry = bar.close;
        double stop = 0.0;
        double tp = 0.0;

        if (state_.expansion_dir == Direction::LONG) {
            stop = state_.or_low;
            const double risk = entry - stop;
            tp = entry + risk * R_MULT;
        } else {
            stop = state_.or_high;
            const double risk = stop - entry;
            tp = entry - risk * R_MULT;
        }

        pending_intent_ = TradeIntent{
            symbol_,
            state_.expansion_dir,
            entry,
            stop,
            tp,
            TradeReason::BALANCE_EXPANSION,
            bar.timestamp
        };

        intent_ready_ = true;
        state_.traded_today = true;

        std::printf("[%s][SIGNAL] %s entry=%.2f stop=%.2f tp=%.2f risk=%.2f\n",
               symbol_.c_str(),
               directionStr(state_.expansion_dir),
               entry, stop, tp, pending_intent_.riskPoints());
    }

    bool impulseConfirmed(std::size_t index) const {
        if (index < IMPULSE_LOOKBACK) {
            last_impulse_ok_ = false;
            return false;
        }

        double avg_range = 0.0;
        for (std::size_t i = index - IMPULSE_LOOKBACK; i < index; ++i) {
            avg_range += recent_bars_[i].range();
        }
        avg_range /= IMPULSE_LOOKBACK;

        const double bar_range = recent_bars_[index].range();
        last_impulse_ok_ = (bar_range >= avg_range * IMPULSE_MULT);
        return last_impulse_ok_;
    }
};

// =============================================================================
// PRE-MARKET COMPRESSION FILTER (US30 ONLY)
// =============================================================================

class PreMarketCompressionFilter {
public:
    explicit PreMarketCompressionFilter(const std::string& symbol)
        : symbol_(symbol)
        , enabled_(symbol == "US30") {}  // ONLY for US30 per backtest

    // Feed pre-market bars to build range
    void onPreMarketBar(const Bar& bar) {
        if (!enabled_) return;

        const int minute = bar.timestamp.minuteOfDay();

        // Pre-market window: 12:30 - 14:30 UTC (2 hours before NY open)
        if (minute < PREMARKET_START || minute >= NY_OPEN_MIN) return;

        if (premarket_high_ == 0.0) {
            premarket_high_ = bar.high;
            premarket_low_ = bar.low;
        } else {
            premarket_high_ = std::max(premarket_high_, bar.high);
            premarket_low_ = std::min(premarket_low_, bar.low);
        }
    }

    // Check if compression valid (range in 40th percentile)
    bool isCompressionValid() const {
        if (!enabled_) return true;  // Always pass for NAS100

        double pm_range = premarket_high_ - premarket_low_;
        if (pm_range <= 0) return false;

        // Update history
        updateHistory(pm_range);

        // Need at least 10 days of history
        if (range_history_.size() < 10) return true;  // Permissive until we have data

        // Calculate 40th percentile
        std::vector<double> sorted(range_history_.begin(), range_history_.end());
        std::sort(sorted.begin(), sorted.end());
        size_t p40_idx = static_cast<size_t>(sorted.size() * 0.40);
        double threshold = sorted[p40_idx];

        bool valid = (pm_range <= threshold);

        std::printf("[%s][PREMARKET] range=%.1f threshold=%.1f valid=%s\n",
               symbol_.c_str(), pm_range, threshold, valid ? "YES" : "NO");

        return valid;
    }

    void onNewDay() {
        premarket_high_ = 0.0;
        premarket_low_ = 0.0;
    }

private:
    std::string symbol_;
    bool enabled_;

    double premarket_high_ = 0.0;
    double premarket_low_ = 0.0;

    mutable std::deque<double> range_history_;

    static constexpr int PREMARKET_START = 12 * 60 + 30;  // 12:30 UTC
    static constexpr int NY_OPEN_MIN = 14 * 60 + 30;      // 14:30 UTC

    void updateHistory(double range) const {
        range_history_.push_back(range);
        if (range_history_.size() > 20) {
            range_history_.pop_front();
        }
    }
};

// =============================================================================
// POSITION SIZER
// =============================================================================

class PositionSizer {
public:
    enum class Mode {
        SHADOW = 0,      // 0.00% - telemetry only
        PILOT = 1,       // 0.25% - validation
        NORMAL = 2,      // 0.50% - standard
        AGGRESSIVE = 3   // 0.75% - after 50+ profitable trades
    };

    explicit PositionSizer(Mode mode = Mode::SHADOW)
        : mode_(mode) {}

    void setMode(Mode m) { mode_ = m; }
    Mode getMode() const { return mode_; }

    double calculateSize(const TradeIntent& intent, double account_equity) const {
        if (mode_ == Mode::SHADOW) return 0.0;
        if (!intent.isValid()) return 0.0;

        const double risk_pct = getRiskPercent();
        const double risk_cash = account_equity * risk_pct;
        const double risk_points = intent.riskPoints();

        double size = risk_cash / risk_points;
        return applySymbolCaps(intent.symbol, size);
    }

    double getRiskPercent() const {
        switch (mode_) {
            case Mode::SHADOW:     return 0.0000;
            case Mode::PILOT:      return 0.0025;
            case Mode::NORMAL:     return 0.0050;
            case Mode::AGGRESSIVE: return 0.0075;
        }
        return 0.0;
    }

    const char* modeName() const {
        switch (mode_) {
            case Mode::SHADOW:     return "SHADOW";
            case Mode::PILOT:      return "PILOT";
            case Mode::NORMAL:     return "NORMAL";
            case Mode::AGGRESSIVE: return "AGGRESSIVE";
        }
        return "UNKNOWN";
    }

private:
    Mode mode_;

    double applySymbolCaps(const std::string& symbol, double size) const {
        double min_size = 0.01;
        double max_size = 0.5;

        if (symbol == "NAS100") {
            min_size = 0.25;
            max_size = 2.0;
        } else if (symbol == "US30") {
            min_size = 0.10;
            max_size = 1.0;
        }

        if (size < min_size) return 0.0;
        return std::min(size, max_size);
    }
};

// =============================================================================
// EXECUTION ORDER
// =============================================================================

struct ExecutionOrder {
    std::string symbol;
    Direction direction;
    double entry_price;
    double stop_price;
    double tp_price;
    double position_size;
    TradeReason reason;
    Timestamp generated_at;

    bool isValid() const {
        return direction != Direction::NONE &&
               position_size > 0 &&
               entry_price > 0;
    }
};

// =============================================================================
// BALANCE EXPANSION SYSTEM (per symbol)
// =============================================================================

class BalanceExpansionSystem {
public:
    using OrderCallback = std::function<void(const ExecutionOrder&)>;

    explicit BalanceExpansionSystem(const std::string& symbol,
                                     double account_equity = 100000.0)
        : symbol_(symbol)
        , engine_(symbol)
        , premarket_filter_(symbol)
        , bar_aggregator_(symbol)
        , account_equity_(account_equity) {

        // Wire up bar aggregator to engine
        bar_aggregator_.setCallback([this](const Bar& bar) {
            onBarInternal(bar);
        });

        sizer_.setMode(PositionSizer::Mode::SHADOW);
    }

    void setOrderCallback(OrderCallback cb) { order_callback_ = cb; }
    void setAccountEquity(double equity) { account_equity_ = equity; }
    void setSizingMode(PositionSizer::Mode mode) { sizer_.setMode(mode); }
    PositionSizer::Mode getSizingMode() const { return sizer_.getMode(); }

    // Main interface: feed ticks
    void onTick(double price, int64_t ts_ms) {
        Timestamp ts(ts_ms);

        // Check for new day
        int today = ts.dateInt();
        if (today != current_day_) {
            onNewDay(ts);
            current_day_ = today;
        }

        // Feed to bar aggregator
        bar_aggregator_.onTick(price, ts_ms);
    }

    // Get telemetry
    BalanceExpansionEngine::Telemetry getTelemetry() const {
        return engine_.getTelemetry();
    }

    // Stats
    std::atomic<uint64_t> signals_generated{0};
    std::atomic<uint64_t> signals_blocked{0};
    std::atomic<uint64_t> orders_sent{0};

    void reset() {
        engine_.onNewDay(Timestamp(now_ms_utc()));
        premarket_filter_.onNewDay();
        bar_aggregator_.reset();
        current_day_ = 0;
    }

private:
    std::string symbol_;
    BalanceExpansionEngine engine_;
    PreMarketCompressionFilter premarket_filter_;
    M1BarAggregator bar_aggregator_;
    PositionSizer sizer_;

    OrderCallback order_callback_;
    double account_equity_;
    int current_day_ = 0;

    void onNewDay(const Timestamp& ts) {
        std::printf("[%s][BE] New day reset\n", symbol_.c_str());
        engine_.onNewDay(ts);
        premarket_filter_.onNewDay();
    }

    void onBarInternal(const Bar& bar) {
        const int minute = bar.timestamp.minuteOfDay();

        // Pre-market phase: feed to compression filter
        if (minute >= 12 * 60 + 30 && minute < 14 * 60 + 30) {
            premarket_filter_.onPreMarketBar(bar);
        }

        // Feed to engine
        engine_.onBar(bar);

        // Check for intent
        if (engine_.hasTradeIntent()) {
            processIntent();
        }
    }

    void processIntent() {
        TradeIntent intent = engine_.consumeTradeIntent();
        signals_generated.fetch_add(1);

        // US30: Apply pre-market compression filter
        if (symbol_ == "US30") {
            if (!premarket_filter_.isCompressionValid()) {
                std::printf("[%s][BE] BLOCKED: premarket_too_wide\n", symbol_.c_str());
                signals_blocked.fetch_add(1);
                return;
            }
        }

        // Calculate position size
        double size = sizer_.calculateSize(intent, account_equity_);

        // Shadow mode - log only
        if (sizer_.getMode() == PositionSizer::Mode::SHADOW) {
            std::printf("[%s][BE] SHADOW: %s entry=%.2f stop=%.2f tp=%.2f\n",
                   symbol_.c_str(),
                   directionStr(intent.direction),
                   intent.entry_price, intent.stop_price, intent.tp_price);
            return;
        }

        // Size too small
        if (size <= 0) {
            std::printf("[%s][BE] SIZE_ZERO - skipping\n", symbol_.c_str());
            return;
        }

        // Create execution order
        ExecutionOrder order{
            intent.symbol,
            intent.direction,
            intent.entry_price,
            intent.stop_price,
            intent.tp_price,
            size,
            intent.reason,
            intent.generated_at
        };

        std::printf("[%s][BE] ORDER: %s size=%.4f entry=%.2f stop=%.2f tp=%.2f\n",
               symbol_.c_str(),
               directionStr(order.direction),
               order.position_size,
               order.entry_price, order.stop_price, order.tp_price);

        orders_sent.fetch_add(1);

        if (order_callback_) {
            order_callback_(order);
        }
    }
};

} // namespace balance_expansion
