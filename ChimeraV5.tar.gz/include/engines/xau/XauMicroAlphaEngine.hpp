// =============================================================================
// XauMicroAlphaEngine.hpp - TICK-BASED IMPULSE FADE
// =============================================================================
//
// VALIDATED EDGE:
//   - PF 1.80 baseline, 1.50 under stress
//   - 45 trades over 10 months
//   - LONG ONLY
//
// MECHANISM:
//   - Detect impulse (6.916+ pts in 5 seconds)
//   - Wait for stall (2 seconds)
//   - Enter LONG near bottom of impulse (15% entry zone)
//   - Stop: impulse_low - 1.383
//   - Target: 40% retracement
//   - Max hold: 20 seconds
//
// PARAMETERS ARE FIXED - DO NOT OPTIMIZE
// =============================================================================
#pragma once

#include <cmath>
#include <cstdint>
#include <cstdio>
#include <algorithm>
#include <functional>
#include <chrono>
#include <deque>
#include <atomic>
#include <cstring>

namespace xau {

// =============================================================================
// TRADE RECORD
// =============================================================================
struct MicroAlphaTradeRecord {
    double entry_price      = 0.0;
    double exit_price       = 0.0;
    double size             = 0.0;
    double pnl_dollars      = 0.0;
    double pnl_points       = 0.0;
    char   exit_reason[32]  = {0};
    uint64_t entry_ts       = 0;
    uint64_t exit_ts        = 0;
};

// =============================================================================
// XAU MICRO ALPHA ENGINE
// =============================================================================
class XauMicroAlphaEngine {
public:
    // =========================================================================
    // FIXED PARAMETERS - DO NOT CHANGE (VALIDATED)
    // =========================================================================
    static constexpr double IMPULSE_POINTS   = 6.916;      // Points for impulse detection
    static constexpr uint64_t IMPULSE_MS     = 5000;       // Time window (5 seconds)
    static constexpr uint64_t STALL_MS       = 2000;       // Wait after impulse (2 seconds)
    static constexpr double STOP_BUFFER      = 1.383;      // Points beyond impulse low
    static constexpr double TARGET_FRAC      = 0.40;       // 40% retracement
    static constexpr uint64_t MAX_HOLD_MS    = 20000;      // Max hold time (20 seconds)
    static constexpr double SPREAD_MULT      = 1.62;       // Spread expansion trigger
    static constexpr double ENTRY_ZONE       = 0.15;       // Within 15% of impulse range
    static constexpr size_t TICK_BUFFER_SIZE = 500;

    // =========================================================================
    // CALLBACK TYPES
    // =========================================================================
    using OrderCallback = std::function<void(const char* symbol, bool is_buy, double qty)>;
    using TradeCallback = std::function<void(const MicroAlphaTradeRecord& trade)>;

    // =========================================================================
    // CONSTRUCTOR
    // =========================================================================
    XauMicroAlphaEngine() {
        reset();
    }

    // =========================================================================
    // CONFIGURATION
    // =========================================================================
    void setOrderCallback(OrderCallback cb) { order_callback_ = std::move(cb); }
    void setTradeCallback(TradeCallback cb) { trade_callback_ = std::move(cb); }
    void setEquity(double equity) { equity_ = equity; }
    void setRiskPercent(double pct) { risk_pct_ = pct; }
    void setMaxSpread(double spread) { max_spread_ = spread; }
    void setDefaultSize(double size) { default_size_ = size; }
    void enable(bool e) { enabled_ = e; }

    // =========================================================================
    // KILL SWITCH (ENGINE-SPECIFIC)
    // =========================================================================
    void kill() { 
        killed_.store(true); 
        if (in_position_) {
            forceExit("KILLED");
        }
    }
    void unkill() { killed_.store(false); }
    bool isKilled() const { return killed_.load(); }
    bool isEnabled() const { return enabled_ && !killed_.load(); }

    // =========================================================================
    // STATE QUERIES
    // =========================================================================
    bool hasPosition() const { return in_position_; }
    double getEntryPrice() const { return entry_price_; }
    double getPositionSize() const { return position_size_; }
    double getUnrealizedPnL() const { 
        if (!in_position_) return 0.0;
        return (last_mid_ - entry_price_) * position_size_ * 100.0;  // $100/pt/lot
    }
    
    // Stats
    int getTotalTrades() const { return total_trades_; }
    int getWins() const { return wins_; }
    double getTotalPnL() const { return total_pnl_; }
    double getWinRate() const { 
        return total_trades_ > 0 ? 100.0 * wins_ / total_trades_ : 0.0; 
    }

    // =========================================================================
    // TICK FEED
    // =========================================================================
    void onTick(double bid, double ask, uint64_t ts_ns = 0) {
        if (!isEnabled()) return;

        uint64_t now = ts_ns > 0 ? ns_to_ms(ts_ns) : nowMs();
        double mid = (bid + ask) * 0.5;
        double spread = ask - bid;

        // Update tick buffer for impulse detection
        tick_times_.push_back(now);
        tick_mids_.push_back(mid);
        tick_spreads_.push_back(spread);

        // Keep last N ticks
        while (tick_times_.size() > TICK_BUFFER_SIZE) {
            tick_times_.pop_front();
            tick_mids_.pop_front();
            tick_spreads_.pop_front();
        }

        // Update median spread (EMA)
        median_spread_ = 0.98 * median_spread_ + 0.02 * spread;

        last_mid_ = mid;
        last_spread_ = spread;
        last_ts_ = now;

        // Manage existing position
        if (in_position_) {
            managePosition(mid, now);
            return;
        }

        // Skip if spread too wide
        if (spread > max_spread_) {
            return;
        }

        // Impulse detection
        detectImpulse(mid, now);

        // Entry logic
        if (impulse_detected_) {
            tryEntry(mid, now);
        }
    }

    // =========================================================================
    // RESET
    // =========================================================================
    void reset() {
        tick_times_.clear();
        tick_mids_.clear();
        tick_spreads_.clear();
        
        median_spread_ = 0.5;
        impulse_detected_ = false;
        impulse_high_ = 0.0;
        impulse_low_ = 0.0;
        impulse_ts_ = 0;
        
        in_position_ = false;
        entry_price_ = 0.0;
        stop_price_ = 0.0;
        target_price_ = 0.0;
        position_size_ = 0.0;
        entry_ts_ = 0;
        
        last_mid_ = 0.0;
        last_spread_ = 0.0;
        last_ts_ = 0;
    }

    void resetStats() {
        total_trades_ = 0;
        wins_ = 0;
        total_pnl_ = 0.0;
    }

    // =========================================================================
    // DEBUG
    // =========================================================================
    void printState() const {
        printf("[MICRO_ALPHA] killed=%d enabled=%d in_pos=%d entry=%.2f stop=%.2f target=%.2f\n",
               killed_.load(), enabled_, in_position_, entry_price_, stop_price_, target_price_);
        printf("[MICRO_ALPHA] impulse_detected=%d impulse_high=%.2f impulse_low=%.2f\n",
               impulse_detected_, impulse_high_, impulse_low_);
        printf("[MICRO_ALPHA] trades=%d wins=%d WR=%.1f%% PnL=%.2f\n",
               total_trades_, wins_, getWinRate(), total_pnl_);
    }

private:
    // =========================================================================
    // IMPULSE DETECTION
    // =========================================================================
    void detectImpulse(double mid, uint64_t now) {
        if (tick_times_.size() < 100) return;

        // Find tick at start of impulse window
        size_t start_idx = 0;
        for (size_t i = tick_times_.size() - 1; i > 0; i--) {
            if (now - tick_times_[i] >= IMPULSE_MS) {
                start_idx = i;
                break;
            }
        }

        if (start_idx == 0 || start_idx >= tick_times_.size() - 3) return;

        double move = mid - tick_mids_[start_idx];
        uint64_t dt = now - tick_times_[start_idx];

        // Check impulse conditions (detect BOTH directions, but only trade LONG)
        if (std::abs(move) >= IMPULSE_POINTS && dt <= IMPULSE_MS) {
            bool spread_expanded = last_spread_ >= SPREAD_MULT * median_spread_;
            bool large_move = std::abs(move) >= IMPULSE_POINTS * 1.5;

            if (spread_expanded || large_move) {
                impulse_detected_ = true;
                impulse_high_ = std::max(tick_mids_[start_idx], mid);
                impulse_low_ = std::min(tick_mids_[start_idx], mid);
                impulse_ts_ = now;

                printf("[MICRO_ALPHA] IMPULSE detected: %.3f pts in %lu ms | Range: %.2f - %.2f\n",
                       std::abs(move), dt, impulse_low_, impulse_high_);
            }
        }
    }

    // =========================================================================
    // ENTRY LOGIC - LONG ONLY
    // =========================================================================
    void tryEntry(double mid, uint64_t now) {
        uint64_t since_stall = now - impulse_ts_;

        // Wait for stall
        if (since_stall < STALL_MS) return;

        double range = impulse_high_ - impulse_low_;
        double entry_zone_price = impulse_low_ + range * ENTRY_ZONE;

        // LONG ONLY: enter near bottom of impulse
        if (mid <= entry_zone_price) {
            double stop = impulse_low_ - STOP_BUFFER;
            double target = mid + range * TARGET_FRAC;

            enterLong(mid, stop, target, now);
            impulse_detected_ = false;
        }
        // Impulse expired (price moved away)
        else if (since_stall > STALL_MS * 3) {
            impulse_detected_ = false;
        }
    }

    // =========================================================================
    // POSITION MANAGEMENT
    // =========================================================================
    void managePosition(double mid, uint64_t now) {
        uint64_t held_ms = now - entry_ts_;

        // Stop hit
        if (mid <= stop_price_) {
            exitPosition(mid, "STOP");
            return;
        }

        // Target hit
        if (target_price_ > 0 && mid >= target_price_) {
            exitPosition(mid, "TARGET");
            return;
        }

        // Time exit
        if (held_ms >= MAX_HOLD_MS) {
            exitPosition(mid, "TIME");
            return;
        }
    }

    // =========================================================================
    // ENTRY/EXIT
    // =========================================================================
    void enterLong(double price, double stop, double target, uint64_t now) {
        if (in_position_) return;

        double size = calculateSize(stop, price);

        in_position_ = true;
        entry_price_ = price;
        stop_price_ = stop;
        target_price_ = target;
        position_size_ = size;
        entry_ts_ = now;

        if (order_callback_) {
            order_callback_("XAUUSD", true, size);
        }

        printf("[MICRO_ALPHA] ENTRY LONG @ %.2f | Stop: %.2f | Target: %.2f | Size: %.3f\n",
               price, stop, target, size);
    }

    void exitPosition(double price, const char* reason) {
        if (!in_position_) return;

        double pnl_points = price - entry_price_;
        double pnl_dollars = pnl_points * position_size_ * 100.0;  // $100/pt/lot

        // Record trade
        MicroAlphaTradeRecord record;
        record.entry_price = entry_price_;
        record.exit_price = price;
        record.size = position_size_;
        record.pnl_dollars = pnl_dollars;
        record.pnl_points = pnl_points;
        std::strncpy(record.exit_reason, reason, sizeof(record.exit_reason) - 1);
        record.entry_ts = entry_ts_;
        record.exit_ts = last_ts_;

        if (trade_callback_) {
            trade_callback_(record);
        }

        if (order_callback_) {
            order_callback_("XAUUSD", false, position_size_);  // SELL to close
        }

        printf("[MICRO_ALPHA] EXIT %s @ %.2f | PnL: %.2f pts ($%.2f)\n",
               reason, price, pnl_points, pnl_dollars);

        // Update stats
        total_trades_++;
        total_pnl_ += pnl_dollars;
        if (pnl_dollars > 0) wins_++;

        // Reset position
        in_position_ = false;
        entry_price_ = 0.0;
        stop_price_ = 0.0;
        target_price_ = 0.0;
        position_size_ = 0.0;
        entry_ts_ = 0;
    }

    void forceExit(const char* reason) {
        if (in_position_ && last_mid_ > 0) {
            exitPosition(last_mid_, reason);
        }
    }

    // =========================================================================
    // SIZING
    // =========================================================================
    double calculateSize(double stop, double entry) const {
        if (default_size_ > 0) return default_size_;
        
        double stop_dist = entry - stop;
        if (stop_dist <= 0) return 0.01;
        
        double risk_dollars = equity_ * risk_pct_;
        double size = risk_dollars / (stop_dist * 100.0);  // $100/pt/lot
        return std::max(0.01, std::min(1.0, size));  // Clamp 0.01 - 1.0 lots
    }

    // =========================================================================
    // TIME HELPERS
    // =========================================================================
    static uint64_t nowMs() {
        return static_cast<uint64_t>(
            std::chrono::duration_cast<std::chrono::milliseconds>(
                std::chrono::steady_clock::now().time_since_epoch()).count());
    }

    static uint64_t ns_to_ms(uint64_t ns) {
        return ns / 1'000'000ULL;
    }

    // =========================================================================
    // STATE
    // =========================================================================
    
    // Callbacks
    OrderCallback order_callback_;
    TradeCallback trade_callback_;

    // Config
    double equity_ = 10000.0;
    double risk_pct_ = 0.01;
    double max_spread_ = 5.0;
    double default_size_ = 0.0;  // If > 0, use fixed size
    bool enabled_ = true;
    std::atomic<bool> killed_{false};

    // Tick buffer
    std::deque<uint64_t> tick_times_;
    std::deque<double> tick_mids_;
    std::deque<double> tick_spreads_;
    double median_spread_ = 0.5;

    // Impulse state
    bool impulse_detected_ = false;
    double impulse_high_ = 0.0;
    double impulse_low_ = 0.0;
    uint64_t impulse_ts_ = 0;

    // Position state
    bool in_position_ = false;
    double entry_price_ = 0.0;
    double stop_price_ = 0.0;
    double target_price_ = 0.0;
    double position_size_ = 0.0;
    uint64_t entry_ts_ = 0;

    // Last tick
    double last_mid_ = 0.0;
    double last_spread_ = 0.0;
    uint64_t last_ts_ = 0;

    // Stats
    int total_trades_ = 0;
    int wins_ = 0;
    double total_pnl_ = 0.0;
};

} // namespace xau
