#pragma once
#include <algorithm>
#include "ExecutionMode.hpp"
#include "LatencyGovernor.hpp"
#include "VolatilityGovernor.hpp"
#include "PositionGovernor.hpp"
#include "CorrelationGovernor.hpp"
#include "EngineId.hpp"

namespace Chimera {

class ExecutionAuthority {
public:
    ExecutionAuthority()
        : min_trade_size_(0.01)
    {}

    void updateLatency(double rtt) {
        latency_.update(rtt);
    }

    void updateVolatility(double vol) {
        volatility_.update(vol);
    }

    void setPosition(EngineId id, double pos) {
        positions_.setPosition(id, pos);
    }

    void setMinTradeSize(double min_size) {
        min_trade_size_ = min_size;
    }

    ExecutionMode evaluate(EngineId id, double requested_size) {
        // Hard blocks first
        if (latency_.shouldBlock()) return ExecutionMode::BLOCK;
        if (volatility_.shouldBlock()) return ExecutionMode::BLOCK;

        if (!positions_.withinLimit(id, requested_size))
            return ExecutionMode::BLOCK;

        // Calculate combined scale
        double scale = 1.0;
        scale *= latency_.scale();
        scale *= volatility_.scale();

        // Tiered execution modes
        if (scale >= 0.9) return ExecutionMode::FULL;
        if (scale >= 0.6) return ExecutionMode::DEGRADED;
        return ExecutionMode::DEFENSIVE;
    }

    double adjustSize(EngineId id, double requested_size, double xau_pos, double xag_pos) {
        // Get all scaling factors
        double scale = 1.0;
        scale *= latency_.scale();
        scale *= volatility_.scale();
        scale *= correlation_.scale(id, xau_pos, xag_pos);

        double final_size = requested_size * scale;

        // CRITICAL: Clamp to minimum economic size to prevent analysis paralysis
        if (final_size < min_trade_size_) {
            final_size = min_trade_size_;
        }

        return final_size;
    }

    bool shouldSend(EngineId id, double requested_size) {
        ExecutionMode mode = evaluate(id, requested_size);
        return mode != ExecutionMode::BLOCK;
    }

private:
    double min_trade_size_;
    LatencyGovernor latency_;
    VolatilityGovernor volatility_;
    PositionGovernor positions_;
    CorrelationGovernor correlation_;
};

} // namespace Chimera
