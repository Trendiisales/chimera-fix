//==============================================================================
// main.cpp - Chimera FIX Client (Metals Only)
//==============================================================================
// Clean architecture: Strategy → ExecutionAuthority → FIX
// NO governance inside FIX layer
// XAU/XAG only
//==============================================================================

#include <iostream>
#include <thread>
#include <chrono>
#include <csignal>
#include <atomic>

#include "shared/TradingConfig.hpp"
#include "governance/ExecutionAuthority.hpp"
#include "governance/EngineId.hpp"
#include "cfd_engine/include/fix/CTraderFIXClient.hpp"

std::atomic<bool> g_running{true};

void signalHandler(int sig) {
    std::cout << "\n[MAIN] Shutting down...\n";
    g_running.store(false);
}

int main() {
    std::signal(SIGINT, signalHandler);
    std::signal(SIGTERM, signalHandler);

    std::cout << "================================================================\n";
    std::cout << "CHIMERA FIX CLIENT - METALS ONLY (XAU/XAG)\n";
    std::cout << "================================================================\n\n";

    // Load configuration
    Chimera::TradingConfig config;
    if (!config.load("config.ini")) {
        std::cerr << "[ERROR] Failed to load config.ini\n";
        return 1;
    }

    config.print();
    std::cout << "\n";

    // Create governance layer
    Chimera::ExecutionAuthority authority;
    authority.setMinTradeSize(config.min_trade_size);

    // Create FIX config from TradingConfig
    Chimera::FIXConfig fix_config;
    fix_config.host = config.fix_host;
    fix_config.tradePort = config.fix_port;
    fix_config.senderCompID = config.sender_comp_id;
    fix_config.targetCompID = config.target_comp_id;
    fix_config.username = config.username;
    fix_config.password = config.password;

    // Create FIX client
    Chimera::CTraderFIXClient fix_client(fix_config);

    // Set execution callback
    fix_client.setExecutionCallback([](const std::string& clOrdID,
                                       const std::string& symbol,
                                       char side,
                                       double qty,
                                       double price) {
        std::cout << "[FILL] " << symbol << " "
                  << (side == '1' ? "BUY" : "SELL") << " "
                  << qty << " @ " << price << "\n";
    });

    // Connect
    std::cout << "[FIX] Connecting to " << config.fix_host << "...\n";
    if (!fix_client.connect()) {
        std::cerr << "[ERROR] Connection failed\n";
        return 1;
    }

    std::cout << "[FIX] Connected!\n\n";
    std::cout << "================================================================\n";
    std::cout << "FIX SESSION ACTIVE\n";
    std::cout << "================================================================\n";
    std::cout << "Governance: ExecutionAuthority (tiered degradation)\n";
    std::cout << "Assets: XAUUSD + XAGUSD only\n";
    std::cout << "Press Ctrl+C to exit\n";
    std::cout << "================================================================\n\n";

    // Main loop
    while (g_running.load()) {
        // Poll for incoming FIX messages
        fix_client.poll();

        // Example: Update governance with market conditions
        // In production, these would come from market data
        authority.updateLatency(3.5);  // ms
        authority.updateVolatility(0.8);  // ATR

        // Simulate position tracking
        authority.setPosition(Chimera::EngineId::XAUUSD, 0.0);
        authority.setPosition(Chimera::EngineId::XAGUSD, 0.0);

        std::this_thread::sleep_for(std::chrono::milliseconds(100));
    }

    // Disconnect
    std::cout << "\n[FIX] Disconnecting...\n";
    fix_client.disconnect();
    std::cout << "[FIX] Disconnected\n";

    return 0;
}
