# Chimera v4.17.0 - XAU Quad Engine Architecture

**Date:** January 11, 2026

## Overview

Major architectural change: Split unified XAU engine into **4 separate independent engines**, each with own position, kill switch, and statistics. This eliminates shared state and allows granular control over each validated strategy.

## Validated Edges (Unchanged Parameters)

All parameters remain **FIXED** as validated through 10-month stress testing on 63M ticks:

| Engine | Timeframe | Stress PF | Trades | Mechanism |
|--------|-----------|-----------|--------|-----------|
| MICRO_ALPHA | Tick | 1.50 | 45 | Impulse fade after liquidity sweep |
| FADE_LOW | 4H | 1.94 | 41 | Buy failed breakdowns |
| RANGE_BREAK | 4H | 1.49 | 161 | Buy breakout continuation |
| VOL_BREAK | 1H | 1.43 | 52 | Buy volatility expansion |

**TOTAL**: 299 trades / 10 months across 4 strategies

## New Architecture

### Files Added

```
include/engines/xau/
├── XauMicroAlphaEngine.hpp   (Tick-based impulse fade)
├── XauFadeLowEngine.hpp      (4H failed breakdown)
├── XauRangeBreakEngine.hpp   (4H breakout continuation)
├── XauVolBreakEngine.hpp     (1H volatility expansion)
└── XauQuadEngine.hpp         (Orchestrator)
```

### Engine Independence

Each engine now has:
- **Own position state** - No shared positions
- **Own kill switch** - `engine.kill()` / `engine.unkill()`
- **Own statistics** - Trades, wins, PnL tracked separately
- **Own callbacks** - Trade records per-engine

### XauQuadEngine Orchestrator

The `XauQuadEngine` class manages all 4 engines:

```cpp
#include "engines/xau/XauQuadEngine.hpp"

xau::XauQuadEngine quad;

// Configuration
quad.setEquity(10000.0);
quad.setRiskPercent(0.01);
quad.setDefaultSize(0.01);  // 0.01 lots per engine

// Enable/disable individual engines
quad.enableMicroAlpha(true);
quad.enableFadeLow(true);
quad.enableRangeBreak(true);
quad.enableVolBreak(true);

// Kill switches
quad.killAll();          // Master kill
quad.killMicroAlpha();   // Individual kill
quad.unkillAll();        // Restore all

// Feed data
quad.onTick(bid, ask, ts_ns);  // Routes to all + aggregates bars

// Or direct bar feeds if available externally
quad.on1HBar(o, h, l, c, ts);
quad.on4HBar(o, h, l, c, ts);

// Status
auto status = quad.getStatus();
printf("Positions: %d, Trades: %d, PnL: $%.2f\n",
       status.total_positions, status.total_trades, status.total_pnl);
```

### Bar Aggregation

XauQuadEngine automatically aggregates bars from tick feed:
- **1H bars**: Tracked by UTC hour transitions
- **4H bars**: Tracked by 4-hour UTC slots (0-3, 4-7, 8-11, etc.)

No external bar source required, but direct bar feeds supported.

## Fixed Parameters (DO NOT CHANGE)

### MICRO_ALPHA (Tick)
```
Impulse: 6.916 pts in 5000ms window
Stall: 2000ms wait
Entry zone: 15% from impulse low
Stop buffer: 1.383 pts below impulse low
Target: 40% retracement
Max hold: 20000ms
Spread multiplier: 1.62x median
```

### FADE_LOW (4H)
```
Lookback: 20 bars
Hold: 3 bars (12 hours)
Signal: Close below 20-bar low = BUY
```

### RANGE_BREAK (4H)
```
Lookback: 10 bars
Hold: 3 bars (12 hours)
Signal: Close above 10-bar high = BUY
```

### VOL_BREAK (1H)
```
Lookback: 5 bars
Expansion: 2.0x average range
Hold: 5 bars (5 hours)
Signal: Range > 2x avg + Bullish = BUY
```

## Migration Guide

### From Unified Engine (v4.16.0)

**Old code:**
```cpp
#include "engines/XauValidatedEngine.hpp"

xau_validated::XauValidatedEngine engine;
engine.onTick(bid, ask, ts);
engine.on4HBar(o, h, l, c, ts);
```

**New code:**
```cpp
#include "engines/xau/XauQuadEngine.hpp"

xau::XauQuadEngine quad;
quad.onTick(bid, ask, ts);  // Handles all timeframes
```

### Backward Compatibility

The old `xau_validated::XauValidatedEngine` is preserved but **deprecated**. It now includes the XauQuadEngine header and recommends migration.

## Risk Management

With 4 independent engines, maximum concurrent positions is **4** (one per engine). Size accordingly:

**Recommended sizing:**
- `0.01 lots` per engine (micro testing)
- `0.0025 lots` per engine if combined exposure concern
- Use `setDefaultSize()` to control

**Kill switch ladder:**
```cpp
// Loss thresholds
if (quad.getTotalPnL() < -50) quad.killVolBreak();    // Weakest edge first
if (quad.getTotalPnL() < -100) quad.killRangeBreak(); // Then medium
if (quad.getTotalPnL() < -150) quad.killFadeLow();    // Then strong
if (quad.getTotalPnL() < -200) quad.killAll();        // Full stop
```

## What NOT To Do

❌ Change parameters  
❌ Add regime filters  
❌ Combine signals  
❌ Auto-calibrate  
❌ Trade shorts  

## Next Steps

1. Deploy with micro size (0.01 lots per engine)
2. Monitor for 1 week minimum
3. Scale only after positive validation
4. Consider staggered sizing by edge strength:
   - FADE_LOW: 1.5x (strongest edge)
   - MICRO_ALPHA: 1.0x
   - RANGE_BREAK: 0.8x (highest frequency, lower edge)
   - VOL_BREAK: 0.8x

## Core Insight

**Gold is structurally long-biased.** Every surviving edge exploits this asymmetry. The quad architecture allows surgical control while preserving the validated edge.
