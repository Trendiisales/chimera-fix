#pragma once
#include <cstdint>
#include <cinttypes>

namespace Chimera {

class LatencyGovernor {
public:
    LatencyGovernor()
        : avg_rtt_ms_(0.0)
        , smoothing_(0.2)
    {}

    void update(double rtt_ms) {
        avg_rtt_ms_ = (smoothing_ * rtt_ms) + (1.0 - smoothing_) * avg_rtt_ms_;
    }

    double scale() const {
        if (avg_rtt_ms_ < 5.0) return 1.0;    // Perfect
        if (avg_rtt_ms_ < 10.0) return 0.75;  // Slightly degraded
        if (avg_rtt_ms_ < 20.0) return 0.5;   // Degraded
        return 0.25;                          // Defensive
    }

    bool shouldBlock() const {
        return avg_rtt_ms_ > 50.0;  // Only block if connection unstable
    }

private:
    double avg_rtt_ms_;
    double smoothing_;
};

} // namespace Chimera
