#pragma once
#include <cmath>

namespace Chimera {

class VolatilityGovernor {
public:
    VolatilityGovernor()
        : smoothed_vol_(0.0)
        , smoothing_(0.1)
        , max_allowed_(2.5)
    {}

    void update(double raw_vol) {
        smoothed_vol_ = smoothing_ * raw_vol + (1.0 - smoothing_) * smoothed_vol_;
    }

    double scale() const {
        if (smoothed_vol_ < 1.0) return 1.0;           // Normal
        if (smoothed_vol_ < max_allowed_) return 0.7;  // Elevated
        return 0.4;                                     // High
    }

    bool shouldBlock() const {
        return smoothed_vol_ > 4.0;  // Only block if extreme
    }

private:
    double smoothed_vol_;
    double smoothing_;
    double max_allowed_;
};

} // namespace Chimera
