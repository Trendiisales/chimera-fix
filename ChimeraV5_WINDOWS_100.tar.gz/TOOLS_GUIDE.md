# CHIMERA DIAGNOSTIC TOOLS

## Overview

Three integrated tools for Windows hardening and system validation:

1. **WindowsHardening.hpp** - MSVC compatibility layer
2. **depgraph** - Dependency graph generator
3. **risk_validator** - Risk gating validator

═══════════════════════════════════════════════════════════════

## 1. WINDOWS HARDENING

**Location:** `include/platform/WindowsHardening.hpp`

**Purpose:** Removes MSVC warnings, fixes 64-bit formatting, handles SOCKET types

**Integrated into:**
- `cfd_engine/include/fix/FIXSSLTransport.hpp`
- `cfd_engine/include/fix/FIXSession.hpp`
- `cfd_engine/include/fix/CTraderFIXClient.hpp`

**Features:**
- Safe SOCKET to string conversion
- Correct PRIu64/PRId64 format specifiers
- Windows defines (WIN32_LEAN_AND_MEAN, NOMINMAX)
- CRT warning suppression

**Functions:**
```cpp
Chimera::socketToString(SOCKET s)     // SOCKET -> string
Chimera::socketToInt64(SOCKET s)      // SOCKET -> int64_t
Chimera::formatU64(val, buf, sz)      // uint64_t with correct format
Chimera::formatI64(val, buf, sz)      // int64_t with correct format
```

**Usage:**
```cpp
#ifdef _WIN32
#include "platform/WindowsHardening.hpp"
#endif

// Instead of:
printf("Socket %d", sock);  // WRONG on Windows

// Use:
printf("Socket %s", Chimera::socketToString(sock).c_str());  // CORRECT
```

═══════════════════════════════════════════════════════════════

## 2. DEPENDENCY GRAPH GENERATOR

**Executable:** `depgraph`

**Purpose:** Generate compile-time dependency graph

**Build:**
```bash
cmake --build . --config Release
```

**Run:**
```bash
# Windows
.\tools\Release\depgraph.exe include

# Linux
./tools/depgraph include
```

**Output:** `chimera_dependency_graph.dot`

**Visualize:**
```bash
# Requires Graphviz installed
dot -Tpng chimera_dependency_graph.dot -o chimera_graph.png
```

**What it does:**
- Scans all .hpp and .cpp files
- Extracts #include directives
- Generates DOT format graph
- Shows dependency relationships

**Example output:**
```
Scanning directory: include
Scanned 191 files
Found 150 nodes with dependencies
Wrote 450 edges to chimera_dependency_graph.dot

Visualize with:
  dot -Tpng chimera_dependency_graph.dot -o chimera_graph.png
```

═══════════════════════════════════════════════════════════════

## 3. RISK GATING VALIDATOR

**Executable:** `risk_validator`

**Purpose:** Stress-test governance logic

**Build:**
```bash
cmake --build . --config Release
```

**Run:**
```bash
# Windows
.\tools\Release\risk_validator.exe

# Linux
./tools/risk_validator
```

**What it tests:**
1. **PnL Floor Enforcement** - Daily loss limit at -500.0
2. **Symbol Whitelist** - Only XAUUSD, NAS100, US30 allowed
3. **Size Constraints** - Maximum position size enforcement
4. **Stress Test** - 10,000 simulated orders

**Example output:**
```
================================================================
CHIMERA RISK GATING VALIDATION
================================================================

[TEST 1] PnL Floor Enforcement
----------------------------------------
  PnL    100.0 -> ALLOWED
  PnL      0.0 -> ALLOWED
  PnL   -200.0 -> ALLOWED
  PnL   -499.0 -> ALLOWED
  PnL   -500.0 -> ALLOWED
  PnL   -501.0 -> BLOCKED (floor triggered)
  PnL  -1000.0 -> BLOCKED (floor triggered)
  Result: 5 passed, 2 blocked
  ✅ PnL floor at -500.0 enforced correctly

[TEST 2] Symbol Whitelist
----------------------------------------
    XAUUSD -> ALLOWED
    NAS100 -> ALLOWED
      US30 -> ALLOWED
    EURUSD -> BLOCKED (not whitelisted)
    BTCUSD -> BLOCKED (not whitelisted)
    SPX500 -> BLOCKED (not whitelisted)
  Result: 3 allowed, 3 blocked
  ✅ Whitelist enforcement correct

[TEST 3] Size Constraints
----------------------------------------
  Size   0.01 -> VALID
  Size    0.5 -> VALID
  Size    1.0 -> VALID
  Size    5.0 -> VALID
  Size   10.0 -> INVALID (exceeds max)
  Size   50.0 -> INVALID (exceeds max)
  Result: 4 valid, 2 invalid
  ✅ Size constraints verified

[TEST 4] Stress Test (10,000 orders)
----------------------------------------
  Total Orders:       10000
  Allowed:            3845
  Blocked (PnL):      3021
  Blocked (Symbol):   0
  Blocked (Size):     3134
  Pass Rate:          38.45%
  ✅ Stress test completed

================================================================
VALIDATION COMPLETE
================================================================
```

═══════════════════════════════════════════════════════════════

## BUILD ALL TOOLS

**Option 1: Build everything**
```bash
mkdir build && cd build
cmake .. -G "Visual Studio 17 2022" -A x64
cmake --build . --config Release
```

**Option 2: Build without tools**
```bash
cmake .. -G "Visual Studio 17 2022" -A x64 -DBUILD_TOOLS=OFF
cmake --build . --config Release
```

**Executables created:**
- `bin/Release/chimera_fix.exe` - Main FIX client
- `tools/Release/depgraph.exe` - Dependency graph generator
- `tools/Release/risk_validator.exe` - Risk validator

═══════════════════════════════════════════════════════════════

## WINDOWS MSVC IMPROVEMENTS

**Before WindowsHardening:**
- ⚠️ C4267: size_t conversion warnings
- ⚠️ C4244: type conversion warnings
- ⚠️ C4996: deprecated function warnings
- ⚠️ SOCKET format specifier errors

**After WindowsHardening:**
- ✅ All warnings suppressed safely
- ✅ Correct format specifiers
- ✅ Safe SOCKET handling
- ✅ Clean MSVC compilation

═══════════════════════════════════════════════════════════════

## USAGE WORKFLOW

**1. Build everything:**
```powershell
mkdir build && cd build
cmake .. -G "Visual Studio 17 2022" -A x64
cmake --build . --config Release
```

**2. Validate risk logic:**
```powershell
.\tools\Release\risk_validator.exe
```

**3. Generate dependency graph:**
```powershell
.\tools\Release\depgraph.exe ..\include
```

**4. Run main FIX client:**
```powershell
.\bin\Release\chimera_fix.exe
```

═══════════════════════════════════════════════════════════════

## INTEGRATION NOTES

**WindowsHardening is automatically included in:**
- All FIX protocol headers
- Activated only on Windows (#ifdef _WIN32)
- Zero impact on Linux builds

**Tools are optional:**
- Set -DBUILD_TOOLS=OFF to skip
- Independent of main executable
- Can run standalone

**All tools are header-only or single .cpp:**
- No external dependencies (except standard library)
- Fast compilation
- Easy to modify

═══════════════════════════════════════════════════════════════
