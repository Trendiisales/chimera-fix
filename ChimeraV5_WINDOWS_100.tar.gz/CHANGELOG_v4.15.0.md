# CHANGELOG v4.15.0 - Balance → Expansion Engine

## Release Date: 2025-01-09

## Summary
Replaced losing SweepReversion engines for NAS100/US30 with validated Balance→Expansion engine.

## Performance Improvement (18-month backtest)

| Metric        | Old (Sweep Fade v4) | New (Balance→Expansion v1) |
|---------------|---------------------|----------------------------|
| NAS100        | -19,920 pts (13.5% WR) | +1,583 pts (46.5% WR)   |
| US30          | -17,000 pts (25.8% WR) | +3,433 pts (41.4% WR)   |
| **Combined**  | **-36,920 pts**        | **+5,016 pts**          |

With regime filter v2: **+6,133 pts** (+22% improvement over base)

## Engine Rules (LOCKED - DO NOT MODIFY)

```
1. OR ≤ 120 NAS / ≤ 200 US30 (narrow = compression)
2. Close beyond OR ± 5 pts (acceptance)
3. Bar range ≥ 1.5× avg 10 bars (impulse)
4. Stop = opposite OR side
5. TP = 1.5R
6. 1 trade/day, within 90 min of NY open
```

## Symbol-Specific Filtering

| Filter                  | NAS100            | US30               |
|-------------------------|-------------------|--------------------|
| Pre-market compression  | ❌ INVERTS edge   | ✅ Saves +1,117 pts |

**CRITICAL**: Pre-market filter is DISABLED for NAS100 (inverts edge) and ENABLED for US30 only.

## Files Changed

### New Files
- `include/engines/BalanceExpansionIntegration.hpp` - Complete Balance Expansion system

### Modified Files
- `include/engines/ChimeraUnifiedEngine.hpp` - Integrated Balance Expansion for NAS100/US30
- `src/main.cpp` - Version bump to v4.15.0

## Sizing Modes (SHADOW by default)

```cpp
// Available modes
balance_expansion::PositionSizer::Mode::SHADOW     // 0.00% - telemetry only
balance_expansion::PositionSizer::Mode::PILOT      // 0.25% - validation
balance_expansion::PositionSizer::Mode::NORMAL     // 0.50% - standard
balance_expansion::PositionSizer::Mode::AGGRESSIVE // 0.75% - after 50+ profitable trades

// Control via engine
engine.setNAS100Mode(balance_expansion::PositionSizer::Mode::PILOT);
engine.setUS30Mode(balance_expansion::PositionSizer::Mode::PILOT);
engine.setAllIndexMode(balance_expansion::PositionSizer::Mode::SHADOW);
```

## Deployment Steps

1. **SHADOW MODE (1 week)**
   - Deploy with default SHADOW mode
   - Validate telemetry matches backtest OR/expansion patterns
   - Confirm no unexpected signals

2. **PILOT MODE (50+ trades)**
   - Set to PILOT (0.25% risk per trade)
   - Track fill quality and slippage
   - Compare live vs backtest win rate

3. **NORMAL MODE (after validation)**
   - Set to NORMAL (0.50% risk per trade)
   - Full production deployment

## XAUUSD Engine (Unchanged)

The XAUUSD engines (Mean Revert, Stop Fade, Acceptance BO) are unchanged in this release.

## Key Discovery (Bug Fixed from Backtest)

cTrader CSV timezone issue: Datetime column = NZ time (UTC+13), epoch timestamp was wrong.
Engine now uses UTC timestamps correctly via system_clock.

---

**DO NOT MODIFY ENGINE PARAMETERS WITHOUT RE-VALIDATION**
