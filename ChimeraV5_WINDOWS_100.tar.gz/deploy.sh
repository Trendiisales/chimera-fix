#!/bin/bash
# =============================================================================
# CHIMERA CLEAN DEPLOY SCRIPT
# =============================================================================
# NUKES EVERYTHING. NO OLD FILES. CLEAN SLATE.
# =============================================================================

set -e

VERSION="v4.16.0"
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

echo "═══════════════════════════════════════════════════════════════"
echo "  CHIMERA ${VERSION} - NUCLEAR CLEAN DEPLOY"
echo "═══════════════════════════════════════════════════════════════"

# Kill any running chimera
echo "[1/6] Killing any running chimera..."
pkill -f "./chimera" 2>/dev/null || true
pkill -f "chimera" 2>/dev/null || true
sleep 1

# NUKE EVERYTHING - no mercy
echo "[2/6] NUKING all old Chimera installations..."
rm -rf ~/Chimera
rm -rf ~/Chimera_v*
rm -rf ~/Chimera_archive_*
rm -f ~/Chimera*.zip
echo "       All old files DESTROYED"

# Copy fresh
echo "[3/6] Installing fresh to ~/Chimera..."
cp -r "$SCRIPT_DIR" ~/Chimera

# Verify no contamination
echo "[4/6] Verifying clean install..."
if [ -f ~/Chimera/cfd_engine/include/CTraderTypes.hpp ]; then
    echo "ERROR: CTraderTypes.hpp found - contaminated!"
    exit 1
fi
echo "       Clean install verified"

# Build
echo "[5/6] Building..."
cd ~/Chimera
rm -rf build
mkdir -p build
cd build
cmake .. 2>&1 | tail -15
make -j4

# Done
echo "[6/6] Build complete!"
echo ""
echo "═══════════════════════════════════════════════════════════════"
echo "  READY: cd ~/Chimera/build && ./chimera"
echo "═══════════════════════════════════════════════════════════════"
