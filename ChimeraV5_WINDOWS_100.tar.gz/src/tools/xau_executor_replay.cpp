#include <iostream>
#include <fstream>
#include <sstream>
#include <string>
#include <vector>
#include <unordered_map>
#include <algorithm>
#include <cstdint>
#include <cinttypes>
#include <cstdlib>

#include "engines/xau/XauQuadEngine.hpp"
#include "execution/SymbolExecutor.hpp"

// ============================================================
// SIMPLE CSV PARSER (STREAMED)
// ============================================================

struct CsvRow {
    std::unordered_map<std::string, std::string> cols;
};

static bool parse_csv_line(const std::string& line, CsvRow& out) {
    std::stringstream ss(line);
    std::string cell;
    std::vector<std::string> values;

    while (std::getline(ss, cell, ',')) {
        values.push_back(cell);
    }

    if (values.empty())
        return false;

    return true;
}

// ============================================================
// COLUMN DETECTION
// ============================================================

struct ColumnMap {
    int ts = -1;
    int bid = -1;
    int ask = -1;
    int vol = -1;
};

static ColumnMap detect_columns(const std::vector<std::string>& header) {
    ColumnMap m;

    for (size_t i = 0; i < header.size(); ++i) {
        const std::string& h = header[i];

        if (h == "timestamp" || h == "time" || h == "ts")
            m.ts = i;
        else if (h == "bid" || h == "Bid")
            m.bid = i;
        else if (h == "ask" || h == "Ask")
            m.ask = i;
        else if (h == "volume" || h == "vol")
            m.vol = i;
    }

    return m;
}

// ============================================================
// TRADE ATTRIBUTION RECORD
// ============================================================

struct TradeRecord {
    uint64_t entry_ts;
    uint64_t exit_ts;
    std::string tag;
    int direction;
    double entry_price;
    double exit_price;
    std::string exit_reason;
    double mfe;
    double mae;
};

int main(int argc, char** argv) {
    if (argc < 3) {
        std::cerr << "Usage: xau_executor_replay <tick_csv> <output_csv>\n";
        return 1;
    }

    std::ifstream in(argv[1]);
    if (!in) {
        std::cerr << "Failed to open tick CSV\n";
        return 1;
    }

    std::ofstream out(argv[2]);
    out << "entry_ts,exit_ts,engine_tag,direction,entry_price,exit_price,"
           "exit_reason,mfe,mae,hold_seconds,pnl_points\n";

    // ============================================================
    // SETUP QUAD + EXECUTOR (SIM MODE)
    // ============================================================

    XauQuadEngine quad;
    SymbolExecutor executor("XAUUSD", 1e9, 100000); // disable risk limits

    std::vector<TradeRecord> trades;
    TradeRecord current{};
    bool in_trade = false;

    double best_fav = 0.0;
    double worst_adv = 0.0;

    quad.setSignalCallback(
        [&](const XauQuadEngine::SignalIntent& sig) {
            if (in_trade || sig.direction == 0)
                return;

            current.entry_ts = sig.timestamp_ns;
            current.direction = sig.direction;
            current.entry_price = sig.entry_price;
            current.tag = sig.tag;
            current.mfe = 0.0;
            current.mae = 0.0;

            best_fav = 0.0;
            worst_adv = 0.0;

            executor.onSignal(
                sig.direction,
                sig.confidence,
                sig.suggested_size,
                sig.suggested_stop_dist,
                sig.tag
            );

            in_trade = true;
        }
    );

    executor.setExitCallback(
        [&](uint64_t ts, double price, const std::string& reason) {
            current.exit_ts = ts;
            current.exit_price = price;
            current.exit_reason = reason;
            current.mfe = best_fav;
            current.mae = worst_adv;

            trades.push_back(current);
            in_trade = false;
        }
    );

    // ============================================================
    // READ HEADER
    // ============================================================

    std::string line;
    if (!std::getline(in, line)) {
        std::cerr << "Empty CSV\n";
        return 1;
    }

    std::vector<std::string> header;
    {
        std::stringstream ss(line);
        std::string cell;
        while (std::getline(ss, cell, ',')) {
            header.push_back(cell);
        }
    }

    ColumnMap cols = detect_columns(header);
    if (cols.ts < 0 || cols.bid < 0 || cols.ask < 0) {
        std::cerr << "CSV missing required columns\n";
        return 1;
    }

    // ============================================================
    // STREAM TICKS
    // ============================================================

    while (std::getline(in, line)) {
        std::stringstream ss(line);
        std::string cell;
        std::vector<std::string> v;

        while (std::getline(ss, cell, ',')) {
            v.push_back(cell);
        }

        if (v.size() <= (size_t)std::max(cols.ask, cols.ts))
            continue;

        uint64_t ts = std::strtoull(v[cols.ts].c_str(), nullptr, 10);
        double bid = std::atof(v[cols.bid].c_str());
        double ask = std::atof(v[cols.ask].c_str());
        double mid = (bid + ask) * 0.5;

        quad.onTick(bid, ask, 0.0, ts);
        executor.onTick(mid, ts);

        if (in_trade) {
            double move = (mid - current.entry_price) * current.direction;
            best_fav = std::max(best_fav, move);
            worst_adv = std::min(worst_adv, move);
        }
    }

    // ============================================================
    // WRITE OUTPUT
    // ============================================================

    for (const auto& t : trades) {
        double hold = (t.exit_ts - t.entry_ts) / 1e9;
        double pnl = (t.exit_price - t.entry_price) * t.direction;

        out << t.entry_ts << ","
            << t.exit_ts << ","
            << t.tag << ","
            << t.direction << ","
            << t.entry_price << ","
            << t.exit_price << ","
            << t.exit_reason << ","
            << t.mfe << ","
            << t.mae << ","
            << hold << ","
            << pnl << "\n";
    }

    std::cout << "Replay complete. Trades: " << trades.size() << "\n";
    return 0;
}
